<?php
session_start();
include 'db.php';
include 'auth.php';
require_login();
dashboard_invalidate();

date_default_timezone_set('Asia/Manila');
if (isset($conn)) {
    $conn->query("SET time_zone = '+08:00'");
}

if (!isset($_SESSION['cart']))             $_SESSION['cart']             = [];
if (!isset($_SESSION['manual_subtotal']))  $_SESSION['manual_subtotal']  = [];
if (!isset($_SESSION['manual_entries']))   $_SESSION['manual_entries']   = [];

// Discount for ONE cart line. $d = ['value'=>x,'type'=>'peso'|'pct'] or null.
function item_disc_amount($gross, $d) {
    if (!is_array($d)) return 0.0;
    $v = floatval($d['value'] ?? 0);
    if ($v <= 0) return 0.0;
    $a = (($d['type'] ?? 'peso') === 'pct') ? $gross * $v / 100 : $v;
    return round(min($a, $gross), 2);
}

// ── Handle payment confirmation ──────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_payment'])) {
    try {
        $cashier = current_user_display(); // sino ang naka-login/nag-cashier ngayon
        if (!empty($_SESSION['cart'])) {

            // ── Pass 1: figure out each line's RAW (pre-discount) amount,
            //    validate stock, and total everything up. Nothing is written
            //    to the database yet — we need the grand total first so the
            //    discount can be applied and spread across the lines.
            $lines    = [];
            $rawTotal = 0.0;
            foreach ($_SESSION['cart'] as $product_id => $quantity) {
                $manualSubtotal = $_SESSION['manual_subtotal'][$product_id] ?? null;
                if (isset($_SESSION['manual_entries'][$product_id])) {
                    $me   = $_SESSION['manual_entries'][$product_id];
                    $name = $me['name'];
                    $price = floatval($me['price']);
                    $raw  = $price * $quantity; // subtotal is no longer editable
                    $lines[] = [
                        'manual'     => true,
                        'product_id' => $product_id,
                        'quantity'   => $quantity,
                        'name'       => $name,
                        'raw'        => $raw,
                    ];
                } else {
                    $res = $conn->query("SELECT price, stock, name FROM products WHERE id = " . intval($product_id));
                    if ($res && $res->num_rows > 0) {
                        $product      = $res->fetch_assoc();
                        $price        = floatval($product['price']);
                        $stock        = intval($product['stock']);
                        $product_name = $product['name'];
                    } else {
                        throw new Exception("Product with ID $product_id not found.");
                    }
                    if ($quantity > $stock) throw new Exception("Insufficient stock for '{$product_name}'. Only {$stock} left.");
                    $raw = $price * $quantity; // subtotal is no longer editable
                    $lines[] = [
                        'manual'     => false,
                        'product_id' => $product_id,
                        'quantity'   => $quantity,
                        'name'       => $product_name,
                        'raw'        => $raw,
                    ];
                }
                $rawTotal += $raw;
            }

            // Mode of payment chosen in the checkout modal.
            $paymentMode = (isset($_POST['payment_mode']) && $_POST['payment_mode'] === 'epay') ? 'epay' : 'cash';

            // ── Each cart line has its OWN discount (set in the cart).
            foreach ($lines as &$line) {
                $d = item_disc_amount($line['raw'], $_SESSION['item_discount'][$line['product_id']] ?? null);
                $line['recorded']   = round($line['raw'] - $d, 2);
                $line['discounted'] = ($d > 0) ? 1 : 0;
            }
            unset($line);

            // ── Pass 2: write each line to `sales` (recorded amount is the
            //    DISCOUNTED amount, per spec) and deduct stock.
            foreach ($lines as $line) {
                $product_id     = $line['product_id'];
                $quantity       = $line['quantity'];
                $total_price    = $line['recorded'];
                $isDiscounted   = $line['discounted'];
                $original_price = $isDiscounted ? $line['raw'] : null;

                if ($line['manual']) {
                    $product_name = $line['name'];
                    $stmt = $conn->prepare("INSERT INTO sales (product_id, quantity, total_price, sale_date, product_name, is_manual, cashier, is_discounted, original_price, payment_mode) VALUES (NULL, ?, ?, NOW(), ?, 1, ?, ?, ?, ?)");
                    if (!$stmt) throw new Exception("Prepare failed for manual entry: " . $conn->error);
                    $stmt->bind_param("idssids", $quantity, $total_price, $product_name, $cashier, $isDiscounted, $original_price, $paymentMode);
                    if (!$stmt->execute()) throw new Exception("Execute failed for manual entry: " . $stmt->error);
                    $stmt->close();
                } else {
                    $stmt = $conn->prepare("INSERT INTO sales (product_id, quantity, total_price, sale_date, cashier, is_discounted, original_price, payment_mode) VALUES (?, ?, ?, NOW(), ?, ?, ?, ?)");
                    if (!$stmt) throw new Exception("Prepare failed: " . $conn->error);
                    $stmt->bind_param("iidsids", $product_id, $quantity, $total_price, $cashier, $isDiscounted, $original_price, $paymentMode);
                    if (!$stmt->execute()) throw new Exception("Execute failed: " . $stmt->error);
                    $stmt->close();
                    // Deduct from the actual product_batches rows (FEFO), not
                    // just the cached products.stock — otherwise a later
                    // "Record Delivery" recomputes stock from the batches and
                    // silently undoes this sale.
                    deduct_stock_fefo($conn, $product_id, $quantity);
                }
            }
        }
        unset($_SESSION['cart'], $_SESSION['manual_subtotal'], $_SESSION['manual_entries'], $_SESSION['item_discount']);
        $_SESSION['success_message'] = "Transaction completed successfully!";
        header("Location: " . $_SERVER['PHP_SELF']);
        exit;
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}

// ── Process barcode scan ─────────────────────────────────
$barcode = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['barcode'])) {
    $barcode = $conn->real_escape_string($_POST['barcode']);
    $res = $conn->query("SELECT * FROM products WHERE barcode = '$barcode'");
    if ($res && $res->num_rows > 0) {
        $product  = $res->fetch_assoc();
        $pid      = $product['id'];
        $stock    = intval($product['stock']);
        $curQty   = $_SESSION['cart'][$pid] ?? 0;
        if ($stock <= 0) {
            $error = "'" . htmlspecialchars($product['name']) . "' is out of stock.";
        } elseif ($curQty + 1 > $stock) {
            $error = "Cannot add more of '" . htmlspecialchars($product['name']) . "'. Only $stock left.";
        } else {
            $_SESSION['cart'][$pid] = $curQty + 1;
            $_SESSION['manual_subtotal'][$pid] = $product['price'] * $_SESSION['cart'][$pid];
        }
    } else {
        $error = "Barcode '" . htmlspecialchars($barcode) . "' not found.";
    }
}

// ── Delete from cart ─────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_action'])) {
    $pid = $_POST['product_id'] ?? null;
    if ($pid) unset($_SESSION['cart'][$pid], $_SESSION['manual_subtotal'][$pid], $_SESSION['manual_entries'][$pid], $_SESSION['item_discount'][$pid]);
}

// ── Clear entire cart ────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['clear_cart'])) {
    $_SESSION['cart'] = [];
    $_SESSION['manual_subtotal'] = [];
    $_SESSION['manual_entries']  = [];
    unset($_SESSION['item_discount']);
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// ── Quantity update ──────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_action'])) {
    $pid    = $_POST['product_id'] ?? null;
    $newQty = intval($_POST['update_qty'] ?? 1);
    if ($pid && $newQty > 0) {
        if (!isset($_SESSION['manual_entries'][$pid])) {
            $res = $conn->query("SELECT stock FROM products WHERE id = " . intval($pid));
            if ($res && $res->num_rows > 0) {
                $s = intval($res->fetch_assoc()['stock']);
                if ($newQty > $s) { $error = "Cannot set quantity to $newQty. Only $s available."; }
                else              { $_SESSION['cart'][$pid] = $newQty; }
            }
        } else {
            $_SESSION['cart'][$pid] = $newQty;
        }
        if (isset($_SESSION['manual_entries'][$pid])) {
            $_SESSION['manual_subtotal'][$pid] = $_SESSION['manual_entries'][$pid]['price'] * $newQty;
        } else {
            $res = $conn->query("SELECT price FROM products WHERE id = " . intval($pid));
            if ($res && $res->num_rows > 0)
                $_SESSION['manual_subtotal'][$pid] = floatval($res->fetch_assoc()['price']) * $newQty;
        }
    }
}

// ── Per-item discount (set / clear) ──────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['item_discount_action'])) {
    $pid = $_POST['product_id'] ?? null;
    $dv  = max(0, floatval($_POST['discount_value'] ?? 0));
    $dt  = (($_POST['discount_type'] ?? 'peso') === 'pct') ? 'pct' : 'peso';
    if ($dt === 'pct') $dv = min($dv, 100);
    if ($pid !== null && isset($_SESSION['cart'][$pid])) {
        if ($dv <= 0) unset($_SESSION['item_discount'][$pid]);
        else          $_SESSION['item_discount'][$pid] = ['value' => $dv, 'type' => $dt];
    }
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// ── AJAX: Search products from inventory ─────────────────
if (isset($_GET['search_product'])) {
    header('Content-Type: application/json');
    $q = '%' . $conn->real_escape_string(trim($_GET['search_product'])) . '%';
    $res = $conn->query("SELECT id, name, price, stock, barcode FROM products WHERE (name LIKE '$q' OR barcode LIKE '$q') AND stock > 0 ORDER BY name ASC LIMIT 3");
    $items = [];
    if ($res) {
        while ($row = $res->fetch_assoc()) {
            $items[] = [
                'id'      => $row['id'],
                'name'    => $row['name'],
                'price'   => floatval($row['price']),
                'stock'   => intval($row['stock']),
                'barcode' => $row['barcode'],
            ];
        }
    }
    echo json_encode($items);
    exit;
}

// ── Add inventory item to cart (by product id) ───────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['inv_add_action'])) {
    $pid = intval($_POST['inv_product_id'] ?? 0);
    if ($pid > 0) {
        $res = $conn->query("SELECT * FROM products WHERE id = $pid");
        if ($res && $res->num_rows > 0) {
            $product = $res->fetch_assoc();
            $stock   = intval($product['stock']);
            $curQty  = $_SESSION['cart'][$pid] ?? 0;
            if ($stock <= 0) {
                $error = "'" . htmlspecialchars($product['name']) . "' is out of stock.";
            } elseif ($curQty + 1 > $stock) {
                $error = "Cannot add more of '" . htmlspecialchars($product['name']) . "'. Only $stock left.";
            } else {
                $_SESSION['cart'][$pid] = $curQty + 1;
                $_SESSION['manual_subtotal'][$pid] = $product['price'] * $_SESSION['cart'][$pid];
            }
        } else {
            $error = "Product not found.";
        }
    }
}

// ── Manual product add ───────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['manual_add_action'])) {
    $mn = trim($_POST['manual_name'] ?? '');
    $mp = floatval($_POST['manual_price'] ?? 0);
    if ($mn !== '' && $mp > 0) {
        $mid = 'm_' . md5($mn . $mp . microtime(true));
        $_SESSION['cart'][$mid] = 1;
        $_SESSION['manual_entries'][$mid] = ['name' => $mn, 'price' => $mp];
        $_SESSION['manual_subtotal'][$mid] = $mp;
    }
}

$cart           = $_SESSION['cart'] ?? [];
$manual_entries = $_SESSION['manual_entries'] ?? [];
$total          = 0;   // NET total (after item discounts)
$totalGross     = 0;   // before discounts
$totalDisc      = 0;   // sum of item discounts

$success_message = '';
if (isset($_SESSION['success_message'])) {
    $success_message = $_SESSION['success_message'];
    unset($_SESSION['success_message']);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>POS — Sari-Link</title>
    <link href="assets/css/fonts.css" rel="stylesheet">
    <link href="assets/css/fontawesome.min.css" rel="stylesheet">
    <link rel="shortcut icon" href="Sari-Link.ico" type="image/x-icon">
    <script src="assets/js/JsBarcode.all.min.js"></script>
    <script src="assets/js/jspdf.umd.min.js"></script>
    <style>
    /* ── Tokens ─────────────────────────────────────────── */
    :root {
        --c-bg:          #eef2f8;
        --c-surface:     #ffffff;
        --c-surface-2:   #f6f8fb;
        --c-border:      #e2e8f2;
        --c-border-soft: #edf1f7;
        --c-primary:     #2563eb;
        --c-primary-dk:  #1e40af;
        --c-primary-lt:  #dbeafe;
        --c-primary-hv:  #1d4ed8;
        --c-success:     #059669;
        --c-success-lt:  #d1fae5;
        --c-warning:     #d97706;
        --c-warning-lt:  #fef3c7;
        --c-danger:      #dc2626;
        --c-danger-lt:   #fee2e2;
        --c-text:        #0f172a;
        --c-muted:       #57647c;
        --c-faint:       #8695ab;
        --r-sm:8px; --r-md:12px; --r-lg:18px; --r-xl:24px;
        --sh-xs:0 1px 2px rgba(15,23,42,.05);
        --sh-sm:0 2px 6px rgba(15,23,42,.06),0 1px 2px rgba(15,23,42,.04);
        --sh-md:0 8px 24px rgba(15,23,42,.08),0 2px 6px rgba(15,23,42,.04);
        --sh-lg:0 20px 48px rgba(15,23,42,.14),0 4px 12px rgba(15,23,42,.06);
        --font:'DM Sans',sans-serif;
        --disp:'Playfair Display',serif;
        --t:180ms ease;
    }
    *,*::before,*::after{margin:0;padding:0;box-sizing:border-box;}
    body{font-family:var(--font);background:var(--c-bg);color:var(--c-text);line-height:1.6;min-height:100vh;}
    a{text-decoration:none;color:inherit;}
    button{font-family:inherit;cursor:pointer;}
    input,select,textarea{font-family:inherit;}
    ::-webkit-scrollbar{width:5px;height:5px;}
    ::-webkit-scrollbar-thumb{background:var(--c-border);border-radius:99px;}

    /* ── Splash ─────────────────────────────────────────── */
    #splash{
        position:fixed;inset:0;z-index:99999;
        display:flex;align-items:center;justify-content:center;
        background:url('splash.jpg') center/cover no-repeat,
                   linear-gradient(135deg,#0f172a 0%,#1e3a5f 100%);
        transition:opacity .5s ease,visibility .5s ease;
        cursor:pointer;
    }
    #splash.hide{opacity:0;visibility:hidden;pointer-events:none;}
    .splash-inner{text-align:center;color:#fff;padding:24px;}
    .splash-brand{font-family:var(--disp);font-size:32px;margin-bottom:5px;}
    .splash-store{font-size:16px;font-weight:700;margin-bottom:3px;opacity:.95;}
    .splash-addr{font-size:12px;opacity:.6;margin-bottom:22px;}
    .splash-spinner{display:flex;align-items:center;justify-content:center;gap:10px;font-size:13px;font-weight:600;opacity:.85;}
    .spin-ring{width:18px;height:18px;border:3px solid rgba(255,255,255,.25);border-top-color:#fff;border-radius:50%;animation:spin 1s linear infinite;}
    @keyframes spin{to{transform:rotate(360deg);}}
    .splash-hint{position:absolute;bottom:18px;left:50%;transform:translateX(-50%);font-size:12px;opacity:.5;color:#fff;white-space:nowrap;}

    /* ── Page ───────────────────────────────────────────── */
    .page-wrap{display:flex;flex-direction:column;min-height:100vh;}

    /* ── Header ─────────────────────────────────────────── */
    .header{
        background:var(--c-surface);
        border-bottom:1px solid var(--c-border);
        padding:0 28px;height:72px;
        display:flex;align-items:center;justify-content:space-between;gap:16px;
        position:sticky;top:0;z-index:200;
        box-shadow:var(--sh-xs);
    }
    .header-left{display:flex;align-items:center;gap:13px;min-width:0;flex:1;}
    .logo-mark{width:42px;height:42px;flex-shrink:0;background:linear-gradient(135deg,#eef4ff,#dce9fb);border-radius:var(--r-md);display:flex;align-items:center;justify-content:center;color:#fff;font-size:16px;padding:7px;box-shadow:inset 0 0 0 1px rgba(37,99,235,.10);}
    .logo-mark img{width:100%;height:100%;object-fit:contain;}
    .logo-text{min-width:0;}
    .logo-name{font-family:var(--disp);font-size:20px;line-height:1.15;white-space:nowrap;}
    .logo-name span{color:var(--c-primary);}
    .logo-store{font-size:11px;color:var(--c-muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:260px;}

    .shortcuts-bar{display:flex;align-items:center;gap:5px;flex-wrap:wrap;}
    .kbd-tag{display:inline-flex;align-items:center;gap:4px;background:var(--c-surface-2);border:1px solid var(--c-border);border-radius:var(--r-sm);padding:2px 7px;font-size:10.5px;color:var(--c-muted);white-space:nowrap;}
    .kbd-tag kbd{background:var(--c-border);border-radius:3px;padding:1px 5px;font-family:var(--font);font-size:10.5px;font-weight:700;color:var(--c-text);}

    /* Live clock */
    .live-clock{display:flex;align-items:center;gap:7px;flex-shrink:0;background:var(--c-surface-2);border:1px solid var(--c-border);border-radius:var(--r-md);padding:6px 12px;font-size:13px;font-weight:700;color:var(--c-text);white-space:nowrap;}
    .live-clock i{color:var(--c-primary);font-size:12px;}
    .clock-date{font-size:10px;font-weight:500;color:var(--c-muted);border-left:1px solid var(--c-border);padding-left:7px;margin-left:3px;}

    .header-nav{display:flex;align-items:center;gap:8px;flex-shrink:0;}
    .nav-btn{display:inline-flex;align-items:center;gap:6px;padding:8px 14px;border-radius:var(--r-md);font-size:13px;font-weight:600;border:1px solid var(--c-border);background:var(--c-surface-2);color:var(--c-muted);transition:all var(--t);}
    .nav-btn:hover{background:var(--c-primary-lt);color:var(--c-primary);border-color:var(--c-primary);}
    .nav-btn.settings-btn:hover{background:var(--c-warning-lt);color:var(--c-warning);border-color:var(--c-warning);}

    /* Burger + Profile dropdowns */
    .burger-menu-wrap,.profile-menu-wrap{position:relative;}
    .burger-btn{font-size:13px;padding:7px 12px;}
    .profile-chip{display:inline-flex;align-items:center;gap:8px;background:var(--c-surface-2);border:1px solid var(--c-border);border-radius:var(--r-md);padding:7px 14px;font-size:13px;font-weight:700;color:var(--c-text);cursor:pointer;transition:all var(--t);}
    .profile-chip:hover{background:var(--c-primary-lt);border-color:var(--c-primary);color:var(--c-primary);}
    .profile-chip i.fa-user-circle{color:var(--c-primary);font-size:15px;}
    .profile-chip .caret{font-size:9px;color:var(--c-muted);transition:transform var(--t);margin-left:1px;}
    .profile-menu-wrap.open .caret{transform:rotate(180deg);}

    .dropdown-panel{
        display:none;position:absolute;top:calc(100% + 8px);right:0;
        background:var(--c-surface);border:1px solid var(--c-border);border-radius:var(--r-md);
        box-shadow:var(--sh-md);min-width:200px;z-index:300;padding:6px;
        animation:popIn .18s ease;
    }
    .dropdown-panel.open{display:block;}
    .dropdown-item{display:flex;align-items:center;gap:10px;width:100%;padding:9px 12px;border:none;background:none;
        border-radius:var(--r-sm);font-size:13px;font-weight:600;color:var(--c-text);cursor:pointer;text-align:left;transition:all var(--t);}
    .dropdown-item:hover{background:var(--c-primary-lt);color:var(--c-primary);}
    .dropdown-item.danger{color:var(--c-danger);}
    .dropdown-item.danger:hover{background:var(--c-danger-lt);color:var(--c-danger);}
    .dropdown-divider{height:1px;background:var(--c-border-soft);margin:5px 2px;}
    .dropdown-user-label{padding:8px 12px 6px;font-size:10.5px;font-weight:700;text-transform:uppercase;letter-spacing:.05em;color:var(--c-muted);}

    /* ── Grid ───────────────────────────────────────────── */
    .pos-grid{display:grid;grid-template-columns:368px 1fr;gap:22px;padding:22px 28px;flex:1;align-items:start;}
    .scanner-left{position:sticky;top:90px;display:flex;flex-direction:column;gap:16px;}

    /* ── Panel ──────────────────────────────────────────── */
    .panel{background:var(--c-surface);border:1px solid var(--c-border);border-radius:var(--r-lg);box-shadow:var(--sh-xs);overflow:hidden;}
    .panel-header{padding:18px 22px 16px;border-bottom:1px solid var(--c-border-soft);display:flex;align-items:center;gap:11px;}
    .panel-icon{width:38px;height:38px;border-radius:var(--r-md);display:flex;align-items:center;justify-content:center;color:#fff;font-size:14px;flex-shrink:0;}
    .pi-green{background:linear-gradient(135deg,#10b981,#059669);}
    .pi-amber{background:linear-gradient(135deg,#f59e0b,#d97706);}
    .pi-blue {background:linear-gradient(135deg,#3b82f6,#1d4ed8);}
    .pi-slate{background:linear-gradient(135deg,#64748b,#475569);}
    .panel-title{font-size:14.5px;font-weight:700;color:var(--c-text);letter-spacing:.01em;}
    .panel-body{padding:24px 22px;}

    /* ── Inputs ─────────────────────────────────────────── */
    .field-label{display:block;font-size:10.5px;font-weight:700;color:var(--c-muted);text-transform:uppercase;letter-spacing:.07em;margin-bottom:6px;}
    .field-input{width:100%;padding:12px 14px;border:1px solid var(--c-border);border-radius:var(--r-md);font-size:14px;font-weight:500;color:var(--c-text);background:var(--c-surface-2);transition:border-color var(--t),box-shadow var(--t);}
    .field-input:focus{outline:none;border-color:var(--c-primary);box-shadow:0 0 0 3px rgba(37,99,235,.12);background:#fff;}
    .field-input::placeholder{color:var(--c-faint);font-weight:400;}
    .field-input.sm{padding:8px 11px;font-size:13px;}

    .barcode-field{width:100%;padding:13px 15px;border:2px solid var(--c-border);border-radius:var(--r-md);font-size:15px;font-weight:600;color:var(--c-text);background:var(--c-surface-2);letter-spacing:.04em;transition:all var(--t);}
    .barcode-field:focus{outline:none;border-color:var(--c-success);box-shadow:0 0 0 3px rgba(5,150,105,.12);background:#fff;}
    .barcode-field::placeholder{color:var(--c-faint);font-weight:400;letter-spacing:0;}

    /* Search Item Cards */
    .search-item-card{padding:9px 12px;border:1px solid var(--c-border);border-radius:var(--r-md);background:var(--c-surface-2);cursor:pointer;transition:all var(--t);}
    .search-item-card:hover,.search-item-card.active{background:var(--c-primary-lt);border-color:var(--c-primary);}
    .search-item-card.active{box-shadow:0 0 0 2px rgba(37,99,235,.2);}

    /* ── Buttons ────────────────────────────────────────── */
    .btn{display:inline-flex;align-items:center;justify-content:center;gap:7px;border:none;border-radius:var(--r-md);font-family:inherit;font-weight:600;cursor:pointer;transition:all var(--t);}
    .btn-block{width:100%;}
    .btn-xs{padding:5px 10px;font-size:12px;}
    .btn-sm{padding:8px 14px;font-size:13px;}
    .btn-md{padding:11px 19px;font-size:14px;}
    .btn-lg{padding:13px 24px;font-size:15px;}
    .btn-primary{background:var(--c-primary);color:#fff;box-shadow:0 2px 6px rgba(37,99,235,.28);}
    .btn-primary:hover{background:var(--c-primary-hv);}
    .btn-success{background:var(--c-success);color:#fff;box-shadow:0 2px 6px rgba(5,150,105,.28);}
    .btn-success:hover{background:#047857;}
    .btn-amber{background:var(--c-warning);color:#fff;box-shadow:0 2px 6px rgba(217,119,6,.28);}
    .btn-amber:hover{background:#b45309;}
    .btn-danger{background:var(--c-danger-lt);color:var(--c-danger);border:1px solid #fca5a5;}
    .btn-danger:hover{background:#fecaca;}
    .btn-danger-solid{background:var(--c-danger);color:#fff;}
    .btn-danger-solid:hover{background:#b91c1c;}
    .btn-ghost{background:var(--c-surface-2);color:var(--c-muted);border:1px solid var(--c-border);}
    .btn-ghost:hover{background:var(--c-border);color:var(--c-text);}
    .btn-outline-blue{background:var(--c-primary-lt);color:var(--c-primary);border:1px solid #93c5fd;}
    .btn-outline-blue:hover{background:#bfdbfe;}

    /* Quick-pay chips */
    .quick-amounts{display:flex;gap:6px;flex-wrap:wrap;margin-top:8px;margin-bottom:4px;}
    .qa-chip{padding:5px 12px;border-radius:99px;font-size:12px;font-weight:700;background:var(--c-surface-2);border:1px solid var(--c-border);color:var(--c-muted);cursor:pointer;transition:all var(--t);}
    .qa-chip:hover{background:var(--c-primary-lt);color:var(--c-primary);border-color:#93c5fd;}
    .qa-chip.exact{background:var(--c-success-lt);color:var(--c-success);border-color:#6ee7b7;}

    /* ── Cart ───────────────────────────────────────────── */
    .cart-panel{display:flex;flex-direction:column;}
    .cart-table-wrap{overflow-y:auto;max-height:calc(100vh - 290px);}
    table{width:100%;border-collapse:collapse;}
    thead th{padding:12px 16px;background:var(--c-surface-2);border-bottom:1px solid var(--c-border);font-size:10.5px;font-weight:700;text-transform:uppercase;letter-spacing:.07em;color:var(--c-muted);text-align:left;white-space:nowrap;position:sticky;top:0;z-index:5;}
    tbody tr{border-bottom:1px solid var(--c-border-soft);transition:background var(--t);}
    tbody tr:last-child{border-bottom:none;}
    tbody tr:hover{background:var(--c-surface-2);}
    tbody td{padding:13px 16px;font-size:14px;vertical-align:middle;}
    .prod-name{font-weight:600;color:var(--c-text);}
    .manual-pill{display:inline-block;margin-left:6px;background:var(--c-warning-lt);color:var(--c-warning);font-size:9.5px;font-weight:700;padding:2px 7px;border-radius:99px;vertical-align:middle;}
    .price-cell{font-weight:700;color:var(--c-success);}
    .qty-input,.sub-input{padding:6px 7px;border:1px solid var(--c-border);border-radius:var(--r-sm);background:var(--c-surface-2);font-size:13px;font-weight:700;text-align:center;color:var(--c-text);transition:border-color var(--t),box-shadow var(--t);}
    .qty-input{width:60px;}
    .sub-input{width:86px;}
    .qty-input:focus,.sub-input:focus{outline:none;border-color:var(--c-primary);box-shadow:0 0 0 2px rgba(37,99,235,.12);background:#fff;}

    /* Cart footer */
    .cart-footer{border-top:1px solid var(--c-border);padding:14px 18px;display:flex;align-items:center;justify-content:space-between;gap:14px;flex-wrap:wrap;}
    .cart-total-label{font-size:10.5px;color:var(--c-muted);font-weight:700;text-transform:uppercase;letter-spacing:.05em;}
    .cart-total-amt{font-size:26px;font-weight:800;color:var(--c-text);line-height:1.1;}
    .cart-total-amt span{color:var(--c-success);}

    /* Empty */
    .empty-cart-cell{padding:235px 20px !important;text-align:center;}
    .empty-icon{width:62px;height:62px;background:var(--c-surface-2);border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 14px;font-size:24px;color:var(--c-faint);}
    .empty-cart-cell h3{font-size:15px;color:var(--c-text);margin-bottom:4px;}
    .empty-cart-cell p{font-size:13px;color:var(--c-muted);}

    /* ── Modals ─────────────────────────────────────────── */
    .modal-overlay{display:none;position:fixed;inset:0;background:rgba(15,23,42,.42);backdrop-filter:blur(4px);z-index:500;justify-content:center;align-items:center;}
    .modal-overlay.open{display:flex;}
    .modal-box{background:var(--c-surface);border-radius:var(--r-xl);padding:28px;width:500px;max-width:93%;position:relative;box-shadow:var(--sh-lg);animation:popIn .22s ease;}
    .modal-box.wide{width:580px;}
    .modal-box.narrow{width:380px;}
    @keyframes popIn{from{opacity:0;transform:scale(.95) translateY(10px)}to{opacity:1;transform:scale(1) translateY(0)}}
    .modal-close{position:absolute;top:15px;right:16px;background:var(--c-surface-2);border:none;width:28px;height:28px;border-radius:50%;font-size:14px;color:var(--c-muted);display:flex;align-items:center;justify-content:center;transition:all var(--t);}
    .modal-close:hover{background:var(--c-danger-lt);color:var(--c-danger);}
    .modal-title{font-family:var(--disp);font-size:20px;margin-bottom:20px;color:var(--c-text);display:flex;align-items:center;gap:10px;}
    .modal-title-icon{width:36px;height:36px;border-radius:var(--r-md);display:flex;align-items:center;justify-content:center;font-size:15px;flex-shrink:0;}
    .mti-green{background:var(--c-success-lt);color:var(--c-success);}
    .mti-amber{background:var(--c-warning-lt);color:var(--c-warning);}
    .mti-red{background:var(--c-danger-lt);color:var(--c-danger);}

    /* Checkout */
    .total-box{background:var(--c-surface-2);border:1px solid var(--c-border);border-radius:var(--r-md);padding:16px;text-align:center;margin-bottom:14px;}
    .total-box-label{font-size:10.5px;color:var(--c-muted);font-weight:700;text-transform:uppercase;letter-spacing:.06em;margin-bottom:3px;}
    .total-box-amt{font-size:30px;font-weight:800;color:var(--c-text);}

    .discount-row{display:flex;gap:8px;align-items:flex-end;margin-bottom:8px;}
    .discount-row .fg{flex:1;}
    .disc-toggle{display:flex;border:1px solid var(--c-border);border-radius:var(--r-md);overflow:hidden;height:38px;flex-shrink:0;}
    .disc-btn{flex:1;min-width:36px;border:none;background:var(--c-surface-2);color:var(--c-muted);font-size:14px;font-weight:700;transition:all var(--t);cursor:pointer;}
    .disc-btn.active{background:var(--c-primary);color:#fff;}

    .cart-discount{display:flex;align-items:center;gap:8px;flex-wrap:wrap;padding:12px 18px;border-top:1px solid var(--c-border);background:var(--c-surface-2);}
    .cart-discount .field-input{width:110px;margin:0;}
    .cart-disc-line{font-size:12px;color:var(--c-muted);margin-bottom:2px;}
    .cart-disc-line strong{color:var(--c-success);}
    .sub-input[readonly]{background:transparent;border-color:transparent;box-shadow:none;cursor:default;pointer-events:none;user-select:none;}
    .item-disc-form{display:flex;align-items:center;gap:4px;}
    .disc-input{width:64px;padding:6px 7px;border:1px solid var(--c-border);border-radius:var(--r-sm);background:var(--c-surface-2);font-size:13px;font-weight:700;text-align:center;color:var(--c-text);}
    .disc-select{padding:6px 4px;border:1px solid var(--c-border);border-radius:var(--r-sm);background:var(--c-surface-2);font-size:13px;font-weight:700;color:var(--c-text);}
    .disc-input:focus,.disc-select:focus{outline:none;border-color:var(--c-primary);box-shadow:0 0 0 2px rgba(37,99,235,.12);background:#fff;}
    .net-cell{font-weight:800;white-space:nowrap;}
    .net-was{font-size:11px;font-weight:600;color:var(--c-faint);text-decoration:line-through;}
    .total-box-sub{font-size:12px;color:var(--c-muted);margin-top:4px;}
    .pay-mode{display:flex;gap:8px;margin:4px 0 14px;}
    .pay-btn{flex:1;padding:10px 12px;border:1px solid var(--c-border);border-radius:var(--r-md);background:var(--c-surface-2);color:var(--c-muted);font-size:13.5px;font-weight:700;display:flex;align-items:center;justify-content:center;gap:8px;transition:all var(--t);}
    .pay-btn.active{background:var(--c-primary);border-color:var(--c-primary);color:#fff;box-shadow:0 2px 8px rgba(37,99,235,.25);}
    .after-disc{text-align:center;font-size:13px;color:var(--c-muted);margin-bottom:10px;display:none;}
    .after-disc strong{color:var(--c-text);}

    .change-box{background:var(--c-success-lt);border:1px solid #6ee7b7;border-radius:var(--r-md);padding:12px;text-align:center;margin:10px 0 16px;font-size:20px;font-weight:800;color:var(--c-success);transition:all var(--t);}
    .change-box small{display:block;font-size:10px;font-weight:600;opacity:.7;margin-bottom:1px;text-transform:uppercase;letter-spacing:.06em;}

    .modal-actions{display:flex;gap:10px;}
    .modal-actions .btn{flex:1;}

    /* Settings */
    .settings-grid{display:flex;flex-direction:column;gap:14px;}
    .settings-row{display:grid;grid-template-columns:1fr 1fr;gap:12px;}
    .settings-footer{margin-top:20px;display:flex;gap:10px;justify-content:flex-end;}

    /* Session summary stat */
    .stat-mini{text-align:center;background:var(--c-surface-2);border-radius:var(--r-md);padding:12px 8px;border:1px solid var(--c-border-soft);}
    .stat-mini-val{font-size:20px;font-weight:800;line-height:1;}
    .stat-mini-lbl{font-size:10.5px;color:var(--c-muted);font-weight:600;margin-top:3px;}

    /* ── Toasts ─────────────────────────────────────────── */
    .toast-stack{position:fixed;top:20px;right:20px;z-index:9999;display:flex;flex-direction:column;gap:8px;}
    .toast{display:flex;align-items:center;gap:11px;background:var(--c-surface);border:1px solid var(--c-border);border-radius:var(--r-md);padding:12px 16px;box-shadow:var(--sh-md);font-size:14px;font-weight:500;animation:toastIn .3s ease;min-width:230px;max-width:350px;position:relative;overflow:hidden;}
    @keyframes toastIn{from{opacity:0;transform:translateX(28px)}to{opacity:1;transform:translateX(0)}}
    .toast-icon{font-size:15px;}
    .toast.success .toast-icon{color:var(--c-success);}
    .toast.error   .toast-icon{color:var(--c-danger);}
    .toast-bar{position:absolute;bottom:0;left:0;height:3px;animation:shrink 4s linear forwards;}
    .toast.success .toast-bar{background:var(--c-success);}
    .toast.error   .toast-bar{background:var(--c-danger);}
    @keyframes shrink{from{width:100%}to{width:0}}
    .toast-close{margin-left:auto;background:none;border:none;color:var(--c-faint);font-size:12px;cursor:pointer;padding:0 0 0 4px;}
    .toast-close:hover{color:var(--c-danger);}

    /* ── Barcode Generator ─────────────────────────────── */
    .settings-tabs{display:flex;gap:0;border-bottom:2px solid var(--c-border);margin-bottom:18px;}
    .stab{padding:9px 18px;font-size:13px;font-weight:600;color:var(--c-muted);cursor:pointer;border-bottom:2px solid transparent;margin-bottom:-2px;transition:all var(--t);background:none;border-top:none;border-left:none;border-right:none;}
    .stab.active{color:var(--c-primary);border-bottom-color:var(--c-primary);}
    .stab-panel{display:none;}
    .stab-panel.active{display:block;}
    .bc-gen-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:14px;}
    .bc-count-badge{display:inline-flex;align-items:center;justify-content:center;background:var(--c-primary);color:#fff;border-radius:99px;font-size:10px;font-weight:700;min-width:18px;height:18px;padding:0 5px;margin-left:5px;}

    /* ── Responsive ─────────────────────────────────────── */
    @media(max-width:960px){
        .pos-grid{grid-template-columns:1fr;}
        .scanner-left{position:static;}
        .cart-table-wrap{max-height:400px;}
        .shortcuts-bar{display:none;}
        .settings-row{grid-template-columns:1fr;}
    }
    @media(max-width:600px){
        .pos-grid{padding:12px;gap:12px;}
        .header{padding:0 14px;}
        .header-nav .nav-btn span{display:none;}
        .logo-store{display:none;}
        .live-clock .clock-date{display:none;}
    }
    </style>
</head>
<body>

<!-- ══ SPLASH ══ -->
<div id="splash" role="dialog" aria-label="Loading" tabindex="-1">
</div>

<!-- ══ TOASTS ══ -->
<div class="toast-stack" id="toastStack"></div>

<!-- ══ PAGE ══ -->
<div class="page-wrap">

    <!-- ── Header ── -->
    <header class="header">
        <div class="header-left">
            <div class="logo-mark"><img src="assets/img/logo-mark.png" alt="Sari-Link"></div>
            <div class="logo-text">
                <div class="logo-name">Sari<span>-Link</span></div>
                <div class="logo-store" id="headerStoreName">Point of Sale</div>
            </div>
            <div class="shortcuts-bar">
                <span class="kbd-tag"><kbd>Alt+B</kbd> Barcode</span>
                <span class="kbd-tag"><kbd>Alt+M</kbd> Manual</span>
                <span class="kbd-tag"><kbd>Alt+C</kbd> Checkout</span>
                <span class="kbd-tag"><kbd>Alt+P</kbd> Pay</span>
                <span class="kbd-tag"><kbd>Alt+S</kbd> Settings</span>
            </div>
        </div>

        <div class="live-clock">
            <i class="fas fa-clock"></i>
            <span id="clockTime">--:--</span>
            <span class="clock-date" id="clockDate"></span>
        </div>

<nav class="header-nav">
    <div class="burger-menu-wrap" id="burgerMenuWrap">
        <button class="nav-btn burger-btn" id="burgerBtn" title="Menu" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-bars"></i><span>Menu</span>
        </button>
        <div class="dropdown-panel" id="navDropdown">
            <button class="dropdown-item" onclick="window.location.href='dashboard.php'">
                <i class="fas fa-chart-line"></i> Dashboard
            </button>
            <button class="dropdown-item" onclick="window.location.href='inventory.php'">
                <i class="fas fa-boxes-stacked"></i> Inventory
            </button>
            <button class="dropdown-item" onclick="window.location.href='patient_medication_profile.php'" title="Patient Medication Profile">
                <i class="fas fa-file-medical"></i> Med Profile
            </button>
            <?php $__ucfg = require __DIR__ . '/config.php'; if (in_array(current_user_username(), $__ucfg['update_users'], true)): ?>
            <button class="dropdown-item" onclick="window.location.href='update.php'" title="System Update">
                <i class="fas fa-cloud-arrow-down"></i> System Update
            </button>
            <?php endif; ?>
            <button class="dropdown-item" onclick="openSettings()" title="Alt+S">
                <i class="fas fa-gear"></i> Settings
            </button>
        </div>
    </div>

    <div class="profile-menu-wrap" id="profileMenuWrap">
        <button class="profile-chip" id="profileChipBtn" title="Logged in as (<?= htmlspecialchars(current_user_role()) ?>)" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-user-circle"></i> <?= htmlspecialchars(current_user_display()) ?>
            <i class="fas fa-chevron-down caret"></i>
        </button>
        <div class="dropdown-panel" id="profileDropdown" style="right:0;">
            <div class="dropdown-user-label"><?= htmlspecialchars(current_user_role()) ?></div>
            <div class="dropdown-divider"></div>
            <button class="dropdown-item danger" onclick="window.location.href='logout.php'">
                <i class="fas fa-right-from-bracket"></i> Log Out
            </button>
        </div>
    </div>
</nav>
    </header>

    <!-- ── POS Grid ── -->
    <div class="pos-grid">

        <!-- LEFT: Scanner + Manual + Stats -->
        <div class="scanner-left">

            <!-- Barcode Scanner -->
            <div class="panel">
                <div class="panel-header">
                    <div class="panel-icon pi-green"><i class="fas fa-barcode"></i></div>
                    <div class="panel-title">Scan Barcode</div>
                </div>
                <div class="panel-body">
                    <form method="POST" id="barcodeForm">
                        <label class="field-label" for="barcodeInput">Barcode</label>
                        <input type="text" name="barcode" id="barcodeInput" class="barcode-field" placeholder="Scan or type barcode…" autocomplete="off">
                    </form>
                </div>
            </div>

            <!-- Search Item -->
            <div class="panel">
                <div class="panel-header">
                    <div class="panel-icon pi-amber"><i class="fas fa-magnifying-glass"></i></div>
                    <div class="panel-title">Search Item</div>
                </div>
                <div class="panel-body" style="padding-bottom:16px;">
                    <label class="field-label" for="itemSearchInput">Product Name or Barcode</label>
                    <div style="position:relative;">
                        <input type="text" id="itemSearchInput" class="field-input" placeholder="Type to search inventory…" autocomplete="off" style="padding-right:36px;">
                        <span id="itemSearchSpinner" style="display:none;position:absolute;right:11px;top:50%;transform:translateY(-50%);color:var(--c-muted);font-size:13px;"><i class="fas fa-circle-notch fa-spin"></i></span>
                    </div>
                    <div id="itemSearchResults" style="margin-top:8px;display:none;flex-direction:column;gap:6px;"></div>
                    <p id="itemSearchEmpty" style="display:none;font-size:12px;color:var(--c-muted);text-align:center;margin-top:10px;"><i class="fas fa-box-open" style="margin-right:5px;"></i>No items found</p>
                    <p style="font-size:11px;color:var(--c-faint);margin-top:10px;"><i class="fas fa-info-circle" style="margin-right:4px;"></i>Use <kbd style="background:var(--c-border);border-radius:3px;padding:1px 5px;font-size:10px;">↑↓</kbd> to navigate, <kbd style="background:var(--c-border);border-radius:3px;padding:1px 5px;font-size:10px;">Enter</kbd> to add to cart</p>
                </div>
            </div>

            <!-- Hidden form to add inventory item to cart -->
            <form method="POST" id="invAddForm" style="display:none;">
                <input type="hidden" name="inv_product_id" id="invProductIdField">
                <input type="hidden" name="inv_add_action" value="1">
            </form>

            <!-- Session Stats -->
            <div class="panel">
                <div class="panel-header">
                    <div class="panel-icon pi-slate"><i class="fas fa-receipt"></i></div>
                    <div class="panel-title">Session Summary</div>
                </div>
                <div class="panel-body" style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">
                    <div class="stat-mini">
                        <div class="stat-mini-val" style="color:var(--c-primary);"><?= array_sum($cart) ?></div>
                        <div class="stat-mini-lbl">Items in Cart</div>
                    </div>
                    <div class="stat-mini">
                        <div class="stat-mini-val" style="color:var(--c-success);"><?= count($cart) ?></div>
                        <div class="stat-mini-lbl">Product Lines</div>
                    </div>
                </div>
            </div>

        </div><!-- /scanner-left -->

        <!-- RIGHT: Cart -->
        <div class="panel cart-panel">
            <div class="panel-header" style="justify-content:space-between;">
                <div style="display:flex;align-items:center;gap:10px;">
                    <div class="panel-icon pi-blue"><i class="fas fa-cart-shopping"></i></div>
                    <div class="panel-title">Current Cart</div>
                    <?php $itemCount = array_sum($cart); ?>
                    <?php if ($itemCount > 0): ?>
                    <span style="background:var(--c-primary-lt);color:var(--c-primary);font-size:11px;font-weight:700;padding:3px 10px;border-radius:99px;border:1px solid #93c5fd;">
                        <?= $itemCount ?> item<?= $itemCount !== 1 ? 's' : '' ?>
                    </span>
                    <?php endif; ?>
                </div>
                <?php if (!empty($cart)): ?>
                <form method="POST" id="clearCartForm">
                    <input type="hidden" name="clear_cart" value="1">
                    <button type="button" class="btn btn-ghost btn-xs" onclick="confirmClear()">
                        <i class="fas fa-trash-can"></i> Clear All
                    </button>
                </form>
                <?php endif; ?>
            </div>

            <div class="cart-table-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Product</th>
                            <th>Unit Price</th>
                            <th>Qty</th>
                            <th>Subtotal</th>
                            <th>Discount</th>
                            <th>Total</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                    $rowNum = 0;
                    if (!empty($cart)):
                        foreach ($cart as $product_id => $quantity):
                            $rowNum++;
                            if (isset($manual_entries[$product_id])):
                                $me       = $manual_entries[$product_id];
                                $pname    = $me['name'];
                                $price    = $me['price'];
                                $msub     = $_SESSION['manual_subtotal'][$product_id] ?? null;
                                $subtotal = $price * $quantity; // read-only: always price × qty
                                $idisc = item_disc_amount($subtotal, $_SESSION['item_discount'][$product_id] ?? null);
                                $inet  = $subtotal - $idisc;
                                $total += $inet; $totalGross += $subtotal; $totalDisc += $idisc;
                    ?>
                        <tr data-disc="<?= $idisc ?>">
                            <td style="color:var(--c-faint);font-size:12px;font-weight:700;"><?= $rowNum ?></td>
                            <td><span class="prod-name"><?= htmlspecialchars($pname) ?><span class="manual-pill">MANUAL</span></span></td>
                            <td class="price-cell">₱<?= number_format($price,2) ?></td>
                            <td>
                                <form method="POST" class="auto-submit-form" style="display:inline">
                                    <input type="number" name="update_qty" value="<?= $quantity ?>" min="1" class="qty-input">
                                    <input type="hidden" name="product_id" value="<?= htmlspecialchars($product_id) ?>">
                                    <input type="hidden" name="update_action" value="1">
                                </form>
                            </td>
                            <td>
                                <input type="number" value="<?= number_format($subtotal,2,'.','') ?>" class="sub-input" readonly tabindex="-1" aria-readonly="true">
                            </td>
                            <td>
                                <?php $idv = $_SESSION['item_discount'][$product_id] ?? null; $idType = (($idv['type'] ?? 'peso') === 'pct') ? 'pct' : 'peso'; ?>
                                <form method="POST" class="item-disc-form">
                                    <input type="hidden" name="item_discount_action" value="1">
                                    <input type="hidden" name="product_id" value="<?= htmlspecialchars($product_id) ?>">
                                    <input type="number" name="discount_value" class="disc-input" min="0" step="0.01" placeholder="0" value="<?= $idv ? rtrim(rtrim(number_format(floatval($idv['value']),2,'.',''),'0'),'.') : '' ?>">
                                    <select name="discount_type" class="disc-select">
                                        <option value="peso" <?= $idType === 'peso' ? 'selected' : '' ?>>₱</option>
                                        <option value="pct"  <?= $idType === 'pct'  ? 'selected' : '' ?>>%</option>
                                    </select>
                                </form>
                            </td>
                            <td class="net-cell">
                                <?php if ($idisc > 0): ?><div class="net-was">₱<?= number_format($subtotal,2) ?></div><?php endif; ?>
                                ₱<?= number_format($inet,2) ?>
                            </td>
                            <td>
                                <form method="POST" style="display:inline">
                                    <input type="hidden" name="product_id" value="<?= htmlspecialchars($product_id) ?>">
                                    <button type="submit" name="delete_action" class="btn btn-danger btn-xs"><i class="fas fa-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                    <?php
                            else:
                                $res2 = $conn->query("SELECT * FROM products WHERE id = " . intval($product_id));
                                if ($res2 && $res2->num_rows > 0):
                                    $prod     = $res2->fetch_assoc();
                                    $msub     = $_SESSION['manual_subtotal'][$product_id] ?? null;
                                    $subtotal = floatval($prod['price']) * intval($quantity); // read-only: always price × qty
                                    $idisc = item_disc_amount($subtotal, $_SESSION['item_discount'][$product_id] ?? null);
                                    $inet  = $subtotal - $idisc;
                                    $total += $inet; $totalGross += $subtotal; $totalDisc += $idisc;
                    ?>
                        <tr data-disc="<?= $idisc ?>">
                            <td style="color:var(--c-faint);font-size:12px;font-weight:700;"><?= $rowNum ?></td>
                            <td><span class="prod-name"><?= htmlspecialchars($prod['name']) ?></span></td>
                            <td class="price-cell">₱<?= number_format($prod['price'],2) ?></td>
                            <td>
                                <form method="POST" class="auto-submit-form" style="display:inline">
                                    <input type="number" name="update_qty" value="<?= intval($quantity) ?>" min="1" class="qty-input">
                                    <input type="hidden" name="product_id" value="<?= $product_id ?>">
                                    <input type="hidden" name="update_action" value="1">
                                </form>
                            </td>
                            <td>
                                <input type="number" value="<?= number_format($subtotal,2,'.','') ?>" class="sub-input" readonly tabindex="-1" aria-readonly="true">
                            </td>
                            <td>
                                <?php $idv = $_SESSION['item_discount'][$product_id] ?? null; $idType = (($idv['type'] ?? 'peso') === 'pct') ? 'pct' : 'peso'; ?>
                                <form method="POST" class="item-disc-form">
                                    <input type="hidden" name="item_discount_action" value="1">
                                    <input type="hidden" name="product_id" value="<?= htmlspecialchars($product_id) ?>">
                                    <input type="number" name="discount_value" class="disc-input" min="0" step="0.01" placeholder="0" value="<?= $idv ? rtrim(rtrim(number_format(floatval($idv['value']),2,'.',''),'0'),'.') : '' ?>">
                                    <select name="discount_type" class="disc-select">
                                        <option value="peso" <?= $idType === 'peso' ? 'selected' : '' ?>>₱</option>
                                        <option value="pct"  <?= $idType === 'pct'  ? 'selected' : '' ?>>%</option>
                                    </select>
                                </form>
                            </td>
                            <td class="net-cell">
                                <?php if ($idisc > 0): ?><div class="net-was">₱<?= number_format($subtotal,2) ?></div><?php endif; ?>
                                ₱<?= number_format($inet,2) ?>
                            </td>
                            <td>
                                <form method="POST" style="display:inline">
                                    <input type="hidden" name="product_id" value="<?= $product_id ?>">
                                    <button type="submit" name="delete_action" class="btn btn-danger btn-xs"><i class="fas fa-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                    <?php       endif;
                            endif;
                        endforeach;
                    else: ?>
                        <tr>
                            <td colspan="8" class="empty-cart-cell">
                                <div class="empty-icon"><i class="fas fa-cart-shopping"></i></div>
                                <h3>Cart is empty</h3>
                                <p>Scan a barcode or add a manual entry to get started</p>
                            </td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <?php
            // Item discounts are already folded into $total (net).
            $netTotal = max(0, $total);
            $discAmt  = round($totalDisc, 2);
            ?>

            <!-- Cart footer -->
            <div class="cart-footer">
                <div>
                    <?php if ($discAmt > 0): ?>
                    <div class="cart-disc-line">Subtotal ₱<?= number_format($totalGross,2) ?> &nbsp;·&nbsp; Item discounts <strong>-₱<?= number_format($discAmt,2) ?></strong></div>
                    <?php endif; ?>
                    <div class="cart-total-label">Cart Total</div>
                    <div class="cart-total-amt">₱<span id="totalValue"><?= number_format($netTotal,2) ?></span></div>
                </div>
                <?php if (!empty($cart)): ?>
                <button class="btn btn-success btn-lg" onclick="openCheckout()">
                    <i class="fas fa-cash-register"></i> Checkout
                </button>
                <?php endif; ?>
            </div>
        </div>
    </div><!-- /pos-grid -->
</div><!-- /page-wrap -->

<!-- ══ CHECKOUT MODAL ══ -->
<div class="modal-overlay" id="checkoutModal">
    <div class="modal-box">
        <button class="modal-close" onclick="closeCheckout()"><i class="fas fa-times"></i></button>
        <div class="modal-title">
            <div class="modal-title-icon mti-green"><i class="fas fa-receipt"></i></div>
            Checkout
        </div>

        <div class="total-box">
            <div class="total-box-label">Order Total</div>
            <div class="total-box-amt">₱<span id="totalDisplay"><?= number_format($netTotal,2) ?></span></div>
            <?php if ($discAmt > 0): ?>
            <div class="total-box-sub">Subtotal ₱<?= number_format($totalGross,2) ?> &nbsp;·&nbsp; Discount -₱<?= number_format($discAmt,2) ?></div>
            <?php endif; ?>
        </div>

        <!-- Mode of payment -->
        <label class="field-label">Mode of Payment</label>
        <div class="pay-mode" id="payMode">
            <button type="button" class="pay-btn active" id="payCash" onclick="setPayMode('cash')"><i class="fas fa-money-bill-wave"></i> Cash Pay</button>
            <button type="button" class="pay-btn"        id="payEpay" onclick="setPayMode('epay')"><i class="fas fa-mobile-screen-button"></i> E-Pay</button>
        </div>

        <div id="cashSection">
        <!-- Money received -->
        <label class="field-label" for="moneyReceived">Money Received (₱)</label>
        <input type="number" id="moneyReceived" class="field-input" placeholder="Enter amount received" step="0.01" oninput="calcChange()" style="margin-bottom:6px;">

        <!-- Quick-pay chips -->
        <div class="quick-amounts" id="quickAmounts"></div>

        <div class="change-box" id="changeBox">
            <small>Change</small>
            ₱<span id="changeDisplay">0.00</span>
        </div>
        </div><!-- /cashSection -->

        <div class="modal-actions">
            <form method="POST" style="flex:1;display:flex;" id="confirmPaymentForm">
                <input type="hidden" name="confirm_payment" value="1">
                <input type="hidden" name="payment_mode" id="paymentModeHidden" value="cash">
                <button type="submit" class="btn btn-success btn-md btn-block">
                    <i class="fas fa-check-circle"></i> Confirm Payment
                </button>
            </form>
            <button class="btn btn-outline-blue btn-md" onclick="printReceipt()" style="flex:1;">
                <i class="fas fa-print"></i> Print Receipt
            </button>
        </div>
    </div>
</div>

<!-- ══ CLEAR CART CONFIRM ══ -->
<div class="modal-overlay" id="clearModal">
    <div class="modal-box narrow">
        <button class="modal-close" onclick="closeModal('clearModal')"><i class="fas fa-times"></i></button>
        <div class="modal-title" style="font-size:17px;">
            <div class="modal-title-icon mti-red"><i class="fas fa-trash-can"></i></div>
            Clear Cart?
        </div>
        <p style="font-size:14px;color:var(--c-muted);margin-bottom:20px;">This will remove all items from the current cart and cannot be undone.</p>
        <div style="display:flex;gap:10px;">
            <button class="btn btn-ghost btn-md" style="flex:1;" onclick="closeModal('clearModal')">Cancel</button>
            <button class="btn btn-danger-solid btn-md" style="flex:1;" onclick="document.getElementById('clearCartForm').submit()">
                <i class="fas fa-trash-can"></i> Yes, Clear
            </button>
        </div>
    </div>
</div>

<!-- ══ STORE SETTINGS MODAL ══ -->
<div class="modal-overlay" id="settingsModal">
    <div class="modal-box wide">
        <button class="modal-close" onclick="closeModal('settingsModal')"><i class="fas fa-times"></i></button>
        <div class="modal-title">
            <div class="modal-title-icon mti-amber"><i class="fas fa-store"></i></div>
            Store Settings
        </div>

        <!-- Tabs -->
        <div class="settings-tabs">
            <button class="stab active" onclick="switchSettingsTab('storeTab',this)"><i class="fas fa-store" style="margin-right:5px"></i>Store Info</button>
            <button class="stab" onclick="switchSettingsTab('barcodeTab',this)">
                <i class="fas fa-barcode" style="margin-right:5px"></i>Barcode Generator
                <span class="bc-count-badge" id="bcCountBadge" style="display:none">0</span>
            </button>
        </div>

        <!-- TAB 1: Store Info -->
        <div class="stab-panel active" id="storeTab">
            <p style="font-size:13px;color:var(--c-muted);margin-bottom:18px;">
                These details appear in the header, splash screen, and printed receipts. Saved locally on this device.
            </p>
            <div class="settings-grid">
                <div>
                    <label class="field-label" for="setStoreName">Store Name</label>
                    <input type="text" id="setStoreName" class="field-input" placeholder="e.g. MEYSES SARI-SARI STORE">
                </div>
                <div class="settings-row">
                    <div>
                        <label class="field-label" for="setStoreAddr">Address</label>
                        <input type="text" id="setStoreAddr" class="field-input" placeholder="Street, Barangay, City…">
                    </div>
                    <div>
                        <label class="field-label" for="setStoreContact">Contact Number</label>
                        <input type="text" id="setStoreContact" class="field-input" placeholder="e.g. 0917-xxx-xxxx">
                    </div>
                </div>
                <div>
                    <label class="field-label" for="setReceiptMsg">Receipt Footer Message</label>
                    <input type="text" id="setReceiptMsg" class="field-input" placeholder="e.g. THANK YOU & COME AGAIN!">
                </div>
            </div>
            <div class="settings-footer">
                <button class="btn btn-ghost btn-md" onclick="closeModal('settingsModal')">Cancel</button>
                <button class="btn btn-primary btn-md" onclick="saveSettings()">
                    <i class="fas fa-floppy-disk"></i> Save Settings
                </button>
            </div>
        </div>

        <!-- TAB 2: Barcode Generator -->
        <div class="stab-panel" id="barcodeTab">
            <p style="font-size:13px;color:var(--c-muted);margin-bottom:14px;">
                Generate barcodes manually or auto-generate random ones, then export all to a PDF sheet.
            </p>

            <!-- Input row -->
            <div class="bc-gen-grid">
                <div>
                    <label class="field-label" for="bcInput">Barcode Number</label>
                    <input type="text" id="bcInput" class="field-input" placeholder="e.g. 8251649756" maxlength="20"
                           onkeydown="if(event.key==='Enter'){event.preventDefault();addBarcodeManual();}">
                </div>
                <div>
                    <label class="field-label" for="bcLabel">Label (optional)</label>
                    <input type="text" id="bcLabel" class="field-input" placeholder="Product name…" maxlength="30">
                </div>
            </div>
            <div style="display:flex;gap:8px;margin-bottom:14px;flex-wrap:wrap;">
                <button class="btn btn-primary btn-sm" onclick="addBarcodeManual()">
                    <i class="fas fa-plus"></i> Add Barcode
                </button>
                <button class="btn btn-amber btn-sm" onclick="autoGenerateBarcodes()">
                    <i class="fas fa-wand-magic-sparkles"></i> Auto-Generate
                </button>
                <div style="display:flex;align-items:center;gap:6px;">
                    <label class="field-label" style="margin:0;white-space:nowrap">Count:</label>
                    <input type="number" id="bcAutoCount" class="field-input sm" value="9" min="1" max="50" style="width:60px;">
                </div>
                <button class="btn btn-ghost btn-sm" onclick="clearAllBarcodes()" style="margin-left:auto;">
                    <i class="fas fa-trash"></i> Clear All
                </button>
            </div>

            <!-- Export -->
            <div style="display:flex;gap:10px;justify-content:flex-end;flex-wrap:wrap;">
                <button class="btn btn-ghost btn-md" onclick="closeModal('settingsModal')">Close</button>
                <button class="btn btn-success btn-md" onclick="exportBarcodePDF()" id="bcExportBtn" disabled>
                    <i class="fas fa-file-pdf"></i> Save as PDF
                </button>
            </div>
        </div>
    </div>
</div>

<script>
/* ═══════════════════════════════════════════════════
   STORE SETTINGS  (localStorage)
═══════════════════════════════════════════════════ */
const STORE_KEY = 'sariLink_storeSettings_v2';

function getSettings() {
    try { const r = localStorage.getItem(STORE_KEY); return r ? JSON.parse(r) : {}; }
    catch(e) { return {}; }
}

function applySettings() {
    const s = getSettings();
    const name = s.name || '';

    // Header store name
    const hn = document.getElementById('headerStoreName');
    if (hn) hn.textContent = name || 'Point of Sale';

    // Splash
    const sn = document.getElementById('splashStoreName');
    if (sn) sn.textContent = name || 'Point of Sale System';
    const sa = document.getElementById('splashStoreAddr');
    if (sa) {
        let parts = [];
        if (s.address) parts.push(s.address);
        if (s.contact) parts.push(s.contact);
        sa.textContent = parts.join(' · ');
    }

    // Page title
    document.title = (name ? name + ' — ' : '') + 'POS · Sari-Link';
}

/* ── Burger + Profile dropdown menus ── */
(function() {
    const burgerBtn      = document.getElementById('burgerBtn');
    const navDropdown    = document.getElementById('navDropdown');
    const profileChipBtn = document.getElementById('profileChipBtn');
    const profileDropdown= document.getElementById('profileDropdown');
    const profileWrap    = document.getElementById('profileMenuWrap');

    function closeNav()     { navDropdown.classList.remove('open'); burgerBtn.setAttribute('aria-expanded','false'); }
    function closeProfile() { profileDropdown.classList.remove('open'); profileWrap.classList.remove('open'); profileChipBtn.setAttribute('aria-expanded','false'); }

    burgerBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        const willOpen = !navDropdown.classList.contains('open');
        closeProfile();
        navDropdown.classList.toggle('open', willOpen);
        burgerBtn.setAttribute('aria-expanded', String(willOpen));
    });

    profileChipBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        const willOpen = !profileDropdown.classList.contains('open');
        closeNav();
        profileDropdown.classList.toggle('open', willOpen);
        profileWrap.classList.toggle('open', willOpen);
        profileChipBtn.setAttribute('aria-expanded', String(willOpen));
    });

    document.addEventListener('click', function(e) {
        if (!navDropdown.contains(e.target) && !burgerBtn.contains(e.target)) closeNav();
        if (!profileDropdown.contains(e.target) && !profileChipBtn.contains(e.target)) closeProfile();
    });

    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') { closeNav(); closeProfile(); }
    });
})();

function openSettings() {
    const s = getSettings();
    document.getElementById('setStoreName').value    = s.name       || '';
    document.getElementById('setStoreAddr').value    = s.address    || '';
    document.getElementById('setStoreContact').value = s.contact    || '';
    document.getElementById('setReceiptMsg').value   = s.receiptMsg || '';
    document.getElementById('settingsModal').classList.add('open');
    setTimeout(() => document.getElementById('setStoreName').focus(), 150);
}

function saveSettings() {
    const s = {
        name:       document.getElementById('setStoreName').value.trim(),
        address:    document.getElementById('setStoreAddr').value.trim(),
        contact:    document.getElementById('setStoreContact').value.trim(),
        receiptMsg: document.getElementById('setReceiptMsg').value.trim(),
    };
    try { localStorage.setItem(STORE_KEY, JSON.stringify(s)); } catch(e) {}
    applySettings();
    closeModal('settingsModal');
    showToast('Store settings saved!', 'success');
}

/* ═══════════════════════════════════════════════════
   LIVE CLOCK
═══════════════════════════════════════════════════ */
function tickClock() {
    const now = new Date();
    const tc = document.getElementById('clockTime');
    const dc = document.getElementById('clockDate');
    if (tc) tc.textContent = now.toLocaleTimeString('en-PH', { hour:'2-digit', minute:'2-digit', second:'2-digit' });
    if (dc) dc.textContent = now.toLocaleDateString('en-PH', { month:'short', day:'numeric', year:'numeric' });
}
tickClock();
setInterval(tickClock, 1000);

/* ═══════════════════════════════════════════════════
   SPLASH
═══════════════════════════════════════════════════ */
(function() {
    applySettings();
    const splash = document.getElementById('splash');
    if (!splash) return;
    const KEY = 'sariLink_splash_v3';
    let hidden = false;
    try { if (sessionStorage.getItem(KEY)) { splash.remove(); focusBarcode(); return; } } catch(e) {}
    function hide() {
        if (hidden) return; hidden = true;
        try { sessionStorage.setItem(KEY, '1'); } catch(e) {}
        splash.classList.add('hide');
        setTimeout(() => { try { splash.remove(); } catch(e) {} focusBarcode(); updateCartTotal(); }, 600);
    }
    const t = setTimeout(hide, 5000);
    splash.addEventListener('click', () => { clearTimeout(t); hide(); });
    document.addEventListener('keydown', e => { if (e.key === 'Escape') { clearTimeout(t); hide(); } });
    try { splash.focus(); } catch(e) {}
})();

function focusBarcode() { const b = document.getElementById('barcodeInput'); if (b) b.focus(); }

/* ═══════════════════════════════════════════════════
   TOASTS
═══════════════════════════════════════════════════ */
<?php if (!empty($success_message)): ?>showToast(<?= json_encode($success_message) ?>, 'success');<?php endif; ?>
<?php if (!empty($error)): ?>showToast(<?= json_encode($error) ?>, 'error');<?php endif; ?>

function showToast(msg, type = 'success') {
    const stack = document.getElementById('toastStack');
    const icons = { success:'fa-circle-check', error:'fa-circle-xmark' };
    const t = document.createElement('div');
    t.className = `toast ${type}`;
    t.innerHTML = `<i class="fas ${icons[type] || 'fa-circle-info'} toast-icon"></i><span>${msg}</span><button class="toast-close" onclick="this.parentElement.remove()"><i class="fas fa-times"></i></button><div class="toast-bar"></div>`;
    stack.appendChild(t);
    setTimeout(() => { t.style.transition='opacity .4s,transform .4s'; t.style.opacity='0'; t.style.transform='translateX(20px)'; setTimeout(()=>t.remove(),400); }, 4000);
}

/* ═══════════════════════════════════════════════════
   BARCODE FORM
═══════════════════════════════════════════════════ */
document.getElementById('barcodeInput').addEventListener('keypress', function(e) {
    if (e.key === 'Enter') { e.preventDefault(); document.getElementById('barcodeForm').submit(); }
});
document.getElementById('barcodeForm').addEventListener('submit', function() {
    setTimeout(() => { document.getElementById('barcodeInput').value = ''; }, 100);
});

/* ═══════════════════════════════════════════════════
   AUTO-SUBMIT CART FORMS
═══════════════════════════════════════════════════ */
document.querySelectorAll('.auto-submit-form').forEach(form => {
    form.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); form.submit(); } });
});
document.querySelectorAll('.item-disc-form').forEach(f => {
    f.querySelectorAll('input.disc-input, select.disc-select').forEach(el => el.addEventListener('change', () => f.submit()));
});
document.querySelectorAll("input[name='update_qty']").forEach(inp => {
    inp.addEventListener('change', function() { this.form.submit(); });
});

/* ═══════════════════════════════════════════════════
   MODAL HELPERS
═══════════════════════════════════════════════════ */
function closeModal(id) { document.getElementById(id).classList.remove('open'); }
document.querySelectorAll('.modal-overlay').forEach(o => {
    o.addEventListener('click', e => { if (e.target === o) o.classList.remove('open'); });
});
function confirmClear() { document.getElementById('clearModal').classList.add('open'); }

/* ═══════════════════════════════════════════════════
   CHECKOUT — discount + quick-pay + change
═══════════════════════════════════════════════════ */
const CART_RAW = <?= json_encode(round($totalGross, 2)) ?>;
const CART_NET = <?= json_encode(round($netTotal, 2)) ?>;
let payMode = 'cash';

function setPayMode(m) {
    payMode = m;
    document.getElementById('payCash').classList.toggle('active', m === 'cash');
    document.getElementById('payEpay').classList.toggle('active', m === 'epay');
    document.getElementById('paymentModeHidden').value = m;
    document.getElementById('cashSection').style.display = m === 'cash' ? '' : 'none';
    if (m === 'cash') calcChange();
}

// Discount is already applied server-side in the cart; checkout just reads the totals.
function getDiscountedTotal() {
    return { raw: CART_RAW, disc: CART_NET };
}

function calcChange() {
    const { raw, disc } = getDiscountedTotal();
    const received = parseFloat(document.getElementById('moneyReceived').value) || 0;
    const change   = received - disc;

    document.getElementById('changeDisplay').innerText = change >= 0 ? change.toFixed(2) : '0.00';

    const cb = document.getElementById('changeBox');
    if (change < 0 || received === 0) {
        cb.style.background  = 'var(--c-danger-lt)';
        cb.style.borderColor = '#fca5a5';
        cb.style.color       = 'var(--c-danger)';
    } else {
        cb.style.background  = 'var(--c-success-lt)';
        cb.style.borderColor = '#6ee7b7';
        cb.style.color       = 'var(--c-success)';
    }
    buildQuickAmounts();
}

function buildQuickAmounts() {
    const { disc } = getDiscountedTotal();
    const wrap = document.getElementById('quickAmounts');
    if (!wrap) return;
    wrap.innerHTML = '';

    const amounts = new Set();
    const exact = parseFloat(disc.toFixed(2));
    amounts.add(exact);
    [10,20,50,100,200,500,1000].forEach(r => {
        const rounded = Math.ceil(disc / r) * r;
        if (rounded > disc && rounded <= disc + 1500) amounts.add(rounded);
    });

    [...amounts].sort((a,b)=>a-b).forEach(amt => {
        const chip = document.createElement('button');
        chip.type = 'button';
        const isExact = Math.abs(amt - exact) < 0.001;
        chip.className = 'qa-chip' + (isExact ? ' exact' : '');
        chip.textContent = isExact ? `₱${amt.toFixed(2)} (Exact)` : `₱${amt.toLocaleString('en-PH', {minimumFractionDigits:0})}`;
        chip.onclick = () => {
            document.getElementById('moneyReceived').value = amt.toFixed(2);
            calcChange();
        };
        wrap.appendChild(chip);
    });
}

function openCheckout() {
    setPayMode('cash');
    buildQuickAmounts();
    document.getElementById('checkoutModal').classList.add('open');
    setTimeout(() => document.getElementById('moneyReceived').focus(), 150);
}

document.getElementById('confirmPaymentForm').addEventListener('submit', function() {
    document.getElementById('paymentModeHidden').value = payMode;
});

function closeCheckout() {
    closeModal('checkoutModal');
    document.getElementById('moneyReceived').value = '';
    document.getElementById('changeDisplay').innerText = '0.00';
    setPayMode('cash');
    const cb = document.getElementById('changeBox');
    cb.style.background  = 'var(--c-success-lt)';
    cb.style.borderColor = '#6ee7b7';
    cb.style.color       = 'var(--c-success)';
}

function updateCartTotal() {
    const tv = document.getElementById('totalValue');
    if (tv) tv.innerText = document.getElementById('totalDisplay').innerText;
}

/* ═══════════════════════════════════════════════════
   KEYBOARD SHORTCUTS
═══════════════════════════════════════════════════ */
document.addEventListener('keydown', e => {
    if (e.altKey) {
        switch(e.key.toLowerCase()) {
            case 'b': e.preventDefault(); focusBarcode(); break;
            case 'm': e.preventDefault(); const mn=document.getElementById('manualName'); if(mn)mn.focus(); break;
            case 'c': e.preventDefault(); openCheckout(); break;
            case 's': e.preventDefault(); openSettings(); break;
            case 'p':
                const cm=document.getElementById('checkoutModal');
                if(cm.classList.contains('open')){e.preventDefault();cm.querySelector('form button').click();}
                break;
        }
    }
    if (e.key === 'Escape') {
        if (document.getElementById('checkoutModal').classList.contains('open')) { closeCheckout(); return; }
        document.querySelectorAll('.modal-overlay.open').forEach(m => m.classList.remove('open'));
    }
});

/* ═══════════════════════════════════════════════════
   SETTINGS TABS
═══════════════════════════════════════════════════ */
function switchSettingsTab(tabId, btn) {
    document.querySelectorAll('.stab-panel').forEach(p => p.classList.remove('active'));
    document.querySelectorAll('.stab').forEach(b => b.classList.remove('active'));
    document.getElementById(tabId).classList.add('active');
    btn.classList.add('active');
}

/* ═══════════════════════════════════════════════════
   BARCODE GENERATOR
═══════════════════════════════════════════════════ */
let bcList = []; // [{num, label}]

function bcUpdateUI() {
    const badge  = document.getElementById('bcCountBadge');
    const expBtn = document.getElementById('bcExportBtn');

    if (bcList.length === 0) {
        expBtn.disabled = true;
        badge.style.display = 'none';
    } else {
        expBtn.disabled = false;
        badge.style.display = '';
        badge.textContent = bcList.length;
    }
}

function addBarcodeManual() {
    const num = document.getElementById('bcInput').value.trim();
    const lbl = document.getElementById('bcLabel').value.trim();
    if (!num) { showToast('Please enter a barcode number.', 'error'); return; }
    if (bcList.find(b => b.num === num)) { showToast('Barcode already in the list.', 'error'); return; }
    bcList.push({ num, label: lbl });
    document.getElementById('bcInput').value  = '';
    document.getElementById('bcLabel').value  = '';
    bcUpdateUI();
    document.getElementById('bcInput').focus();
}

function autoGenerateBarcodes() {
    const count = Math.min(Math.max(parseInt(document.getElementById('bcAutoCount').value) || 9, 1), 50);
    for (let i = 0; i < count; i++) {
        let num;
        do { num = String(Math.floor(Math.random() * 9000000000) + 1000000000); }
        while (bcList.find(b => b.num === num));
        bcList.push({ num, label: '' });
    }
    bcUpdateUI();
    showToast(`${count} barcode${count!==1?'s':''} generated!`, 'success');
}

function clearAllBarcodes() {
    if (bcList.length === 0) return;
    if (!confirm('Clear all barcodes from the list?')) return;
    bcList = [];
    bcUpdateUI();
}

async function exportBarcodePDF() {
    if (bcList.length === 0) { showToast('No barcodes to export.', 'error'); return; }
    const { jsPDF } = window.jspdf;

    const doc   = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
    const margin = 12, cols = 3;
    const pageW  = 210, pageH = 297;
    const cellW  = (pageW - margin * 2) / cols;
    const cellH  = 38; // height per barcode cell (mm)
    const padTop = 22; // start Y for first row

    // Title header
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(14);
    doc.text('Barcode Sheet', margin, 14);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(120);
    doc.text('Generated by Sari-Link POS · ' + new Date().toLocaleDateString('en-PH'), margin, 19);
    doc.setTextColor(0);

    let col = 0, row = 0;

    for (let i = 0; i < bcList.length; i++) {
        const item = bcList[i];
        const x    = margin + col * cellW;
        const y    = padTop + row * cellH;

        if (y + cellH > pageH - margin) {
            doc.addPage();
            row = 0; col = 0;
        }

        // Draw barcode via hidden canvas
        const canvas = document.createElement('canvas');
        try {
            JsBarcode(canvas, item.num, {
                format: 'CODE128',
                width: 2,
                height: 60,
                displayValue: true,
                fontSize: 14,
                margin: 6,
            });
            const imgData = canvas.toDataURL('image/png');
            const bcW = cellW - 4;
            const bcH = cellH - 6;
            doc.addImage(imgData, 'PNG', x + 2, y + 1, bcW, bcH);
        } catch(e) {
            doc.setFontSize(8);
            doc.text('Invalid: ' + item.num, x + 2, y + 10);
        }

        if (item.label) {
            doc.setFontSize(7);
            doc.setFont('helvetica', 'bold');
            doc.text(item.label, x + cellW / 2, y + cellH - 1, { align: 'center' });
            doc.setFont('helvetica', 'normal');
        }

        col++;
        if (col >= cols) { col = 0; row++; }
    }

    const s = getSettings();
    const fname = (s.name || 'Sari-Link').replace(/\s+/g, '_') + '_Barcodes_' + Date.now() + '.pdf';
    doc.save(fname);
    showToast('PDF saved!', 'success');
}





/* ==============================================
   SEARCH ITEM  (live inventory lookup)
============================================== */
(function() {
    const input    = document.getElementById('itemSearchInput');
    const results  = document.getElementById('itemSearchResults');
    const empty    = document.getElementById('itemSearchEmpty');
    const spinner  = document.getElementById('itemSearchSpinner');
    const form     = document.getElementById('invAddForm');
    const pidField = document.getElementById('invProductIdField');

    if (!input) return;

    let debounce = null;
    let activeIdx = -1;
    let currentItems = [];

    function renderItems(items) {
        currentItems = items;
        activeIdx = -1;
        results.innerHTML = '';
        empty.style.display = 'none';

        if (items.length === 0) {
            results.style.display = 'none';
            if (input.value.trim().length >= 2) empty.style.display = 'block';
            return;
        }

        results.style.display = 'flex';
        items.forEach((item, i) => {
            const card = document.createElement('div');
            card.className = 'search-item-card';
            card.dataset.idx = i;
            card.innerHTML =
                '<div style="display:flex;align-items:center;justify-content:space-between;gap:8px;">' +
                    '<div style="min-width:0;">' +
                        '<div style="font-size:13px;font-weight:600;color:var(--c-text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;" title="' + item.name.replace(/"/g,'&quot;') + '">' + item.name + '</div>' +
                        '<div style="font-size:11px;color:var(--c-muted);margin-top:1px;">' +
                            '<span style="color:var(--c-success);font-weight:700;">₱' + item.price.toFixed(2) + '</span>' +
                            ' &nbsp;&middot;&nbsp; Stock: ' + item.stock +
                            (item.barcode ? ' &nbsp;&middot;&nbsp; ' + item.barcode : '') +
                        '</div>' +
                    '</div>' +
                    '<button type="button" class="btn btn-primary btn-xs" style="flex-shrink:0;" title="Add to cart"><i class="fas fa-plus"></i></button>' +
                '</div>';

            card.addEventListener('click', () => addItem(i));
            card.addEventListener('mouseenter', () => setActive(i));
            results.appendChild(card);
        });
    }

    function setActive(idx) {
        const cards = results.querySelectorAll('.search-item-card');
        cards.forEach((c, i) => c.classList.toggle('active', i === idx));
        activeIdx = idx;
    }

    function addItem(idx) {
        const item = currentItems[idx];
        if (!item) return;
        pidField.value = item.id;
        form.submit();
    }

    function clearResults() {
        results.style.display = 'none';
        results.innerHTML = '';
        empty.style.display = 'none';
        currentItems = [];
        activeIdx = -1;
    }

    input.addEventListener('input', function() {
        clearTimeout(debounce);
        const q = this.value.trim();
        if (q.length < 2) { clearResults(); return; }
        spinner.style.display = 'block';
        debounce = setTimeout(() => {
            fetch('index.php?search_product=' + encodeURIComponent(q))
                .then(r => r.json())
                .then(items => { spinner.style.display = 'none'; renderItems(items); })
                .catch(() => { spinner.style.display = 'none'; });
        }, 280);
    });

    input.addEventListener('keydown', function(e) {
        const cards = results.querySelectorAll('.search-item-card');
        if (e.key === 'ArrowDown') {
            e.preventDefault();
            setActive(Math.min(activeIdx + 1, currentItems.length - 1));
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            setActive(Math.max(activeIdx - 1, 0));
        } else if (e.key === 'Enter') {
            e.preventDefault();
            if (activeIdx >= 0) {
                addItem(activeIdx);
            } else if (currentItems.length === 1) {
                addItem(0);
            }
        } else if (e.key === 'Escape') {
            clearResults();
            input.blur();
        }
    });

    document.addEventListener('click', function(e) {
        if (!input.contains(e.target) && !results.contains(e.target)) clearResults();
    });
})();

/* ═══════════════════════════════════════════════════
   PRINT RECEIPT  (uses store settings)
═══════════════════════════════════════════════════ */
function printReceipt() {
    const s = getSettings();
    const storeName  = s.name       || 'SARI-SARI STORE';
    const storeAddr  = s.address    || '';
    const contact    = s.contact    || '';
    const footerMsg  = s.receiptMsg || 'THANK YOU & COME AGAIN!';
    const cashierName = <?= json_encode(current_user_display()) ?>;

    const now        = new Date();
    const dateStr    = now.toLocaleDateString('en-PH', { month:'short', day:'numeric', year:'numeric' });
    const timeStr    = now.toLocaleTimeString('en-PH', { hour:'2-digit', minute:'2-digit' });

    const { raw, disc } = getDiscountedTotal();
    const received = parseFloat(document.getElementById('moneyReceived').value) || 0;
    const change   = received - disc > 0 ? received - disc : 0;
    const discAmt  = raw - disc;

    const rows = document.querySelectorAll('table tbody tr');
    let items = '', count = 0;
    rows.forEach(row => {
        if (row.querySelector('.empty-cart-cell')) return;
        const nm  = row.querySelector('.prod-name');
        const qty = row.querySelector('.qty-input');
        const sub = row.querySelector('.sub-input');
        if (!nm||!qty||!sub) return;
        count++;
        const itemDisc = parseFloat(row.dataset.disc) || 0;
        items += `<tr><td width="55%">${count}. ${nm.textContent.replace('MANUAL','').trim()}</td><td width="15%" style="text-align:center">${parseInt(qty.value,10)}</td><td width="30%" style="text-align:right">₱${parseFloat(sub.value).toFixed(2)}</td></tr>` + (itemDisc > 0 ? `<tr><td colspan="3" style="font-size:9px;padding:0 0 3px 8px">Discount -₱${itemDisc.toFixed(2)}</td></tr>` : '');
    });

    const discLine = discAmt > 0
        ? `<div class="row"><span>DISCOUNT</span><span>-₱${discAmt.toFixed(2)}</span></div>` : '';

    const html = `<!DOCTYPE html><html><head><meta charset="utf-8"><style>
        @page{size:58mm auto;margin:0}body{margin:0;padding:0;width:58mm;font-family:Arial,sans-serif;color:#000}
        .w{width:46mm;margin-left:1mm;padding-top:10px}
        .brand{font-size:15px;font-weight:bold;text-align:center;text-transform:uppercase;display:block;margin-bottom:2px}
        .info{font-size:10px;text-align:center;line-height:1.4;margin-bottom:6px}
        .cashier{font-size:10px;text-align:right;margin-bottom:6px}
        .rcpt{font-size:9px;text-align:right;margin-bottom:4px;opacity:.6}
        .div{border-top:1px dashed #000;margin:4px 0}
        .it{width:100%;border-collapse:collapse;table-layout:fixed}
        .it th{font-size:9px;text-align:left;border-bottom:1px solid #000;padding-bottom:3px;font-weight:bold}
        .it td{font-size:11px;padding:3px 0;vertical-align:top;word-wrap:break-word}
        .ts{margin-top:5px;border-top:1px dashed #000;padding-top:4px}
        .row{display:flex;justify-content:space-between;font-size:11px;padding:2px 0}
        .bt{font-size:14px;font-weight:bold;display:flex;justify-content:space-between;margin:4px 0;border-bottom:1px solid #000;padding:4px 0}
        .ft{text-align:center;font-size:10px;margin-top:12px}.feed{height:22mm}
    </style></head><body><div class="w">
        <div class="brand">${storeName}</div>
        <div class="info">${storeAddr?storeAddr+'<br>':''}${contact?'TEL: '+contact+'<br>':''}${dateStr} ${timeStr}</div>
        <div class="cashier">Cashier: ${cashierName}</div>
        <div class="div"></div>
        <table class="it"><thead><tr><th width="55%">ITEM</th><th width="15%" style="text-align:center">QTY</th><th width="30%" style="text-align:right">TOTAL</th></tr></thead>
        <tbody>${items}</tbody></table>
        <div class="ts">
            ${discLine}
            <div class="bt"><span>TOTAL</span><span>₱${disc.toFixed(2)}</span></div>
            ${payMode === 'epay'
                ? `<div class="row"><span>PAYMENT</span><span>E-PAY</span></div>`
                : `<div class="row"><span>CASH</span><span>₱${received.toFixed(2)}</span></div>
            <div class="row" style="font-weight:bold;font-size:12px"><span>CHANGE</span><span>₱${change.toFixed(2)}</span></div>`}
        </div>
        <div class="ft">${footerMsg}<br><span style="font-size:9px">Items: ${count}</span></div>
        <div class="feed"></div>
    </div></body></html>`;

    const iframe = document.createElement('iframe');
    iframe.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0;visibility:hidden';
    document.body.appendChild(iframe);
    const doc = iframe.contentWindow ? iframe.contentWindow.document : iframe.contentDocument;
    doc.open(); doc.write(html); doc.close();
    let printed = false;
    const fb = setTimeout(()=>{if(!printed){printed=true;try{const w=iframe.contentWindow||iframe;w.focus();w.print();}catch(e){}setTimeout(()=>{try{document.body.removeChild(iframe)}catch(e){}},1e3);}},2e3);
    iframe.onload=function(){if(printed)return;printed=true;clearTimeout(fb);try{const w=iframe.contentWindow||iframe;w.focus();w.print();}catch(e){}finally{setTimeout(()=>{try{document.body.removeChild(iframe)}catch(e){}},1e3);}};
}
</script>
</body>
</html>