-- ============================================================
-- posmachin — SAFE STRUCTURE-ONLY UPDATE SCRIPT
-- Generated: schema/columns only, ALL DATA REMOVED.
-- Safe to re-run: uses IF NOT EXISTS everywhere so it will not
-- overwrite or duplicate anything on a database that already
-- has some (or all) of these tables/columns.
-- ============================================================

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

-- --------------------------------------------------------
-- Table structure for table `expenses`
-- --------------------------------------------------------

CREATE TABLE IF NOT EXISTS `expenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `expense_name` varchar(255) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `expense_date` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

ALTER TABLE `expenses`
  ADD COLUMN IF NOT EXISTS `expense_name` varchar(255) NOT NULL AFTER `id`,
  ADD COLUMN IF NOT EXISTS `amount` decimal(10,2) NOT NULL AFTER `expense_name`,
  ADD COLUMN IF NOT EXISTS `expense_date` date NOT NULL AFTER `amount`,
  ADD COLUMN IF NOT EXISTS `created_at` timestamp NOT NULL DEFAULT current_timestamp() AFTER `expense_date`;

-- --------------------------------------------------------
-- Table structure for table `loans`
-- --------------------------------------------------------

CREATE TABLE IF NOT EXISTS `loans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_name` varchar(100) NOT NULL,
  `items` text NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `loan_date` date NOT NULL,
  `contact_number` varchar(20) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

ALTER TABLE `loans`
  ADD COLUMN IF NOT EXISTS `customer_name` varchar(100) NOT NULL AFTER `id`,
  ADD COLUMN IF NOT EXISTS `items` text NOT NULL AFTER `customer_name`,
  ADD COLUMN IF NOT EXISTS `amount` decimal(10,2) NOT NULL AFTER `items`,
  ADD COLUMN IF NOT EXISTS `loan_date` date NOT NULL AFTER `amount`,
  ADD COLUMN IF NOT EXISTS `contact_number` varchar(20) DEFAULT NULL AFTER `loan_date`,
  ADD COLUMN IF NOT EXISTS `notes` text DEFAULT NULL AFTER `contact_number`,
  ADD COLUMN IF NOT EXISTS `created_at` timestamp NOT NULL DEFAULT current_timestamp() AFTER `notes`;

ALTER TABLE `loans`
  ADD KEY IF NOT EXISTS `customer_name` (`customer_name`);

-- --------------------------------------------------------
-- Table structure for table `patient_medication_profiles`
-- --------------------------------------------------------

CREATE TABLE IF NOT EXISTS `patient_medication_profiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `patient_name` varchar(255) NOT NULL,
  `age` int(11) NOT NULL,
  `address` text NOT NULL,
  `contact_no` varchar(50) NOT NULL,
  `gender` enum('Male','Female','Other') NOT NULL,
  `date_of_birth` date NOT NULL,
  `pregnant_lactating` enum('N/A','Pregnant','Lactating') NOT NULL DEFAULT 'N/A',
  `medications` text NOT NULL,
  `dose` varchar(255) NOT NULL,
  `direction` text NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `allergies` text NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

ALTER TABLE `patient_medication_profiles`
  ADD COLUMN IF NOT EXISTS `patient_name` varchar(255) NOT NULL AFTER `id`,
  ADD COLUMN IF NOT EXISTS `age` int(11) NOT NULL AFTER `patient_name`,
  ADD COLUMN IF NOT EXISTS `address` text NOT NULL AFTER `age`,
  ADD COLUMN IF NOT EXISTS `contact_no` varchar(50) NOT NULL AFTER `address`,
  ADD COLUMN IF NOT EXISTS `gender` enum('Male','Female','Other') NOT NULL AFTER `contact_no`,
  ADD COLUMN IF NOT EXISTS `date_of_birth` date NOT NULL AFTER `gender`,
  ADD COLUMN IF NOT EXISTS `pregnant_lactating` enum('N/A','Pregnant','Lactating') NOT NULL DEFAULT 'N/A' AFTER `date_of_birth`,
  ADD COLUMN IF NOT EXISTS `medications` text NOT NULL AFTER `pregnant_lactating`,
  ADD COLUMN IF NOT EXISTS `dose` varchar(255) NOT NULL AFTER `medications`,
  ADD COLUMN IF NOT EXISTS `direction` text NOT NULL AFTER `dose`,
  ADD COLUMN IF NOT EXISTS `created_at` datetime DEFAULT current_timestamp() AFTER `direction`,
  ADD COLUMN IF NOT EXISTS `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp() AFTER `created_at`,
  ADD COLUMN IF NOT EXISTS `allergies` text NOT NULL DEFAULT '' AFTER `updated_at`;

-- --------------------------------------------------------
-- Table structure for table `products`
-- --------------------------------------------------------

CREATE TABLE IF NOT EXISTS `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `cost_price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `stock` int(11) NOT NULL,
  `barcode` varchar(50) DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `original_price` decimal(10,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

ALTER TABLE `products`
  ADD COLUMN IF NOT EXISTS `name` varchar(100) NOT NULL AFTER `id`,
  ADD COLUMN IF NOT EXISTS `price` decimal(10,2) NOT NULL AFTER `name`,
  ADD COLUMN IF NOT EXISTS `cost_price` decimal(10,2) NOT NULL DEFAULT 0.00 AFTER `price`,
  ADD COLUMN IF NOT EXISTS `stock` int(11) NOT NULL AFTER `cost_price`,
  ADD COLUMN IF NOT EXISTS `barcode` varchar(50) DEFAULT NULL AFTER `stock`,
  ADD COLUMN IF NOT EXISTS `expiry_date` date DEFAULT NULL AFTER `barcode`,
  ADD COLUMN IF NOT EXISTS `original_price` decimal(10,2) NOT NULL DEFAULT 0.00 AFTER `expiry_date`;

ALTER TABLE `products`
  ADD UNIQUE KEY IF NOT EXISTS `barcode` (`barcode`);

-- --------------------------------------------------------
-- Table structure for table `product_batches`
-- --------------------------------------------------------

CREATE TABLE IF NOT EXISTS `product_batches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `expiry_date` date DEFAULT NULL,
  `received_date` datetime NOT NULL DEFAULT current_timestamp(),
  `received_by` varchar(100) DEFAULT NULL,
  `notes` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

ALTER TABLE `product_batches`
  ADD COLUMN IF NOT EXISTS `product_id` int(11) NOT NULL AFTER `id`,
  ADD COLUMN IF NOT EXISTS `quantity` int(11) NOT NULL AFTER `product_id`,
  ADD COLUMN IF NOT EXISTS `expiry_date` date DEFAULT NULL AFTER `quantity`,
  ADD COLUMN IF NOT EXISTS `received_date` datetime NOT NULL DEFAULT current_timestamp() AFTER `expiry_date`,
  ADD COLUMN IF NOT EXISTS `received_by` varchar(100) DEFAULT NULL AFTER `received_date`,
  ADD COLUMN IF NOT EXISTS `notes` varchar(255) DEFAULT NULL AFTER `received_by`;

ALTER TABLE `product_batches`
  ADD KEY IF NOT EXISTS `product_id` (`product_id`),
  ADD KEY IF NOT EXISTS `expiry_date` (`expiry_date`);

-- --------------------------------------------------------
-- Table structure for table `sales`
-- --------------------------------------------------------

CREATE TABLE IF NOT EXISTS `sales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) DEFAULT NULL,
  `product_name` varchar(255) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `sale_date` datetime NOT NULL,
  `is_manual` tinyint(1) DEFAULT 0,
  `cashier` varchar(100) DEFAULT NULL,
  `is_discounted` tinyint(1) DEFAULT 0,
  `original_price` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

ALTER TABLE `sales`
  ADD COLUMN IF NOT EXISTS `product_id` int(11) DEFAULT NULL AFTER `id`,
  ADD COLUMN IF NOT EXISTS `product_name` varchar(255) DEFAULT NULL AFTER `product_id`,
  ADD COLUMN IF NOT EXISTS `quantity` int(11) NOT NULL AFTER `product_name`,
  ADD COLUMN IF NOT EXISTS `total_price` decimal(10,2) NOT NULL AFTER `quantity`,
  ADD COLUMN IF NOT EXISTS `sale_date` datetime NOT NULL AFTER `total_price`,
  ADD COLUMN IF NOT EXISTS `is_manual` tinyint(1) DEFAULT 0 AFTER `sale_date`,
  ADD COLUMN IF NOT EXISTS `cashier` varchar(100) DEFAULT NULL AFTER `is_manual`,
  ADD COLUMN IF NOT EXISTS `is_discounted` tinyint(1) DEFAULT 0 AFTER `cashier`,
  ADD COLUMN IF NOT EXISTS `original_price` decimal(10,2) DEFAULT NULL AFTER `is_discounted`;

-- --------------------------------------------------------
-- Table structure for table `stock_deliveries`
-- --------------------------------------------------------

CREATE TABLE IF NOT EXISTS `stock_deliveries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `quantity_added` int(11) NOT NULL,
  `expiry_date` date DEFAULT NULL,
  `previous_stock` int(11) NOT NULL,
  `new_stock` int(11) NOT NULL,
  `received_by` varchar(100) NOT NULL,
  `notes` varchar(255) DEFAULT NULL,
  `delivery_date` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

ALTER TABLE `stock_deliveries`
  ADD COLUMN IF NOT EXISTS `product_id` int(11) NOT NULL AFTER `id`,
  ADD COLUMN IF NOT EXISTS `product_name` varchar(255) NOT NULL AFTER `product_id`,
  ADD COLUMN IF NOT EXISTS `quantity_added` int(11) NOT NULL AFTER `product_name`,
  ADD COLUMN IF NOT EXISTS `expiry_date` date DEFAULT NULL AFTER `quantity_added`,
  ADD COLUMN IF NOT EXISTS `previous_stock` int(11) NOT NULL AFTER `expiry_date`,
  ADD COLUMN IF NOT EXISTS `new_stock` int(11) NOT NULL AFTER `previous_stock`,
  ADD COLUMN IF NOT EXISTS `received_by` varchar(100) NOT NULL AFTER `new_stock`,
  ADD COLUMN IF NOT EXISTS `notes` varchar(255) DEFAULT NULL AFTER `received_by`,
  ADD COLUMN IF NOT EXISTS `delivery_date` datetime NOT NULL DEFAULT current_timestamp() AFTER `notes`;

ALTER TABLE `stock_deliveries`
  ADD KEY IF NOT EXISTS `product_id` (`product_id`);

-- --------------------------------------------------------
-- Table structure for table `stock_pullouts`
-- --------------------------------------------------------

CREATE TABLE IF NOT EXISTS `stock_pullouts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `reason` enum('Expired','Damaged','Defective','Returned to supplier','Other') NOT NULL,
  `pulled_out_by` varchar(100) NOT NULL,
  `pullout_date` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

ALTER TABLE `stock_pullouts`
  ADD COLUMN IF NOT EXISTS `product_id` int(11) NOT NULL AFTER `id`,
  ADD COLUMN IF NOT EXISTS `product_name` varchar(255) NOT NULL AFTER `product_id`,
  ADD COLUMN IF NOT EXISTS `quantity` int(11) NOT NULL AFTER `product_name`,
  ADD COLUMN IF NOT EXISTS `reason` enum('Expired','Damaged','Defective','Returned to supplier','Other') NOT NULL AFTER `quantity`,
  ADD COLUMN IF NOT EXISTS `pulled_out_by` varchar(100) NOT NULL AFTER `reason`,
  ADD COLUMN IF NOT EXISTS `pullout_date` datetime NOT NULL DEFAULT current_timestamp() AFTER `pulled_out_by`;

ALTER TABLE `stock_pullouts`
  ADD KEY IF NOT EXISTS `product_id` (`product_id`);

-- --------------------------------------------------------
-- Foreign key constraints (safe to re-run)
-- --------------------------------------------------------

ALTER TABLE `product_batches`
  ADD CONSTRAINT `fk_batch_product` FOREIGN KEY IF NOT EXISTS (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

ALTER TABLE `stock_pullouts`
  ADD CONSTRAINT `fk_pullout_product` FOREIGN KEY IF NOT EXISTS (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
