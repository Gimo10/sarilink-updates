<?php
session_start();
include 'auth.php';

$allowedRedirects = ['index.php', 'inventory.php', 'dashboard.php', 'patient_medication_profile.php'];

// Already logged in? Skip straight to where they wanted to go.
if (!empty($_SESSION['auth_user'])) {
    $r = $_GET['redirect'] ?? 'index.php';
    if (!in_array($r, $allowedRedirects, true)) $r = 'index.php';
    header("Location: $r");
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $u = trim($_POST['username'] ?? '');
    $p = (string)($_POST['password'] ?? '');
    $u_key = strtolower($u);

    if (isset($SARILINK_USERS[$u_key]) && hash_equals($SARILINK_USERS[$u_key]['password'], $p)) {
        $_SESSION['auth_user'] = [
            'username' => $u_key,
            'display'  => $SARILINK_USERS[$u_key]['display'],
            'role'     => $SARILINK_USERS[$u_key]['role'],
        ];
        $redirect = $_POST['redirect'] ?? 'index.php';
        if (!in_array($redirect, $allowedRedirects, true)) $redirect = 'index.php';
        header("Location: $redirect");
        exit;
    } else {
        $error = 'Incorrect username or password. Please try again.';
    }
}

$redirectField = htmlspecialchars($_GET['redirect'] ?? $_POST['redirect'] ?? 'index.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login — Sari-Link POS</title>
<link href="assets/css/fonts.css" rel="stylesheet">
<link href="assets/css/fontawesome.min.css" rel="stylesheet">
<link rel="shortcut icon" href="Sari-Link.ico" type="image/x-icon">
<style>
  :root{
    --c-bg:#eef2f8; --c-surface:#ffffff; --c-border:#e2e8f2;
    --c-primary:#2563eb; --c-primary-dk:#1e40af; --c-primary-lt:#dbeafe; --c-primary-hv:#1d4ed8;
    --c-danger:#dc2626; --c-danger-lt:#fee2e2;
    --c-text:#0f172a; --c-muted:#57647c; --c-faint:#8695ab;
    --font:'DM Sans',sans-serif; --disp:'Playfair Display',serif;
  }
  *,*::before,*::after{margin:0;padding:0;box-sizing:border-box;}
  body{
    font-family:var(--font); min-height:100vh; display:flex; align-items:center; justify-content:center;
    background:
      radial-gradient(circle at 15% 12%, rgba(59,130,246,.20), transparent 45%),
      radial-gradient(circle at 85% 88%, rgba(37,99,235,.16), transparent 50%),
      linear-gradient(160deg,#0b1526 0%,#132743 55%,#1c3a5e 100%);
    padding:24px;
  }
  .login-card{
    background:var(--c-surface); border-radius:24px; width:410px; max-width:100%;
    padding:44px 40px 38px; box-shadow:0 24px 60px rgba(8,15,30,.35), 0 2px 8px rgba(8,15,30,.12);
    border:1px solid rgba(255,255,255,.06);
  }
  .login-icon{
    width:60px;height:60px;border-radius:17px;
    background:linear-gradient(135deg,#eef4ff,#dbe7fb); color:#fff;
    display:flex;align-items:center;justify-content:center;
    margin:0 auto 20px; padding:9px; box-shadow:inset 0 0 0 1px rgba(37,99,235,.12);
  }
  .login-icon img{width:100%;height:100%;object-fit:contain;}
  .login-title{font-family:var(--disp); font-size:26px; text-align:center; color:var(--c-text); margin-bottom:6px; letter-spacing:.01em;}
  .login-title span{color:var(--c-primary);}
  .login-sub{font-size:13px;color:var(--c-muted);text-align:center;margin-bottom:32px;}
  .field-label{display:block;font-size:10.5px;font-weight:700;color:var(--c-muted);text-transform:uppercase;letter-spacing:.07em;margin-bottom:7px;}
  .field-wrap{margin-bottom:18px;}
  .field-input{width:100%;padding:13px 15px;border:1.5px solid var(--c-border);border-radius:12px;font-size:14px;font-weight:500;color:var(--c-text);background:#f7f9fc;transition:all .18s ease;}
  .field-input:focus{outline:none;border-color:var(--c-primary);box-shadow:0 0 0 4px rgba(37,99,235,.10);background:#fff;}
  .pw-wrap{position:relative;}
  .pw-toggle{position:absolute;right:13px;top:50%;transform:translateY(-50%);background:none;border:none;color:var(--c-faint);cursor:pointer;font-size:14px;padding:4px;}
  .pw-toggle:hover{color:var(--c-muted);}
  .login-error{
    display:flex; align-items:center; gap:9px; background:var(--c-danger-lt); color:var(--c-danger);
    font-size:13px; font-weight:600; padding:12px 14px; border-radius:12px; margin-bottom:18px;
  }
  .login-btn{
    width:100%; padding:14px; border:none; border-radius:12px;
    background:linear-gradient(135deg,var(--c-primary),var(--c-primary-hv)); color:#fff;
    font-family:inherit; font-weight:700; font-size:14.5px; cursor:pointer; transition:all .18s ease;
    display:flex; align-items:center; justify-content:center; gap:9px;
    box-shadow:0 8px 20px rgba(37,99,235,.28);
    margin-top:6px;
  }
  .login-btn:hover{box-shadow:0 10px 26px rgba(37,99,235,.38); transform:translateY(-1px);}
  .login-btn:active{transform:translateY(0);}
  .login-foot{margin-top:22px;text-align:center;font-size:11.5px;color:var(--c-faint);line-height:1.5;}
</style>
</head>
<body>
  <div class="login-card">
    <div class="login-icon"><img src="assets/img/logo-mark.png" alt="Sari-Link"></div>
    <div class="login-title">Sari<span>-Link</span></div>
    <div class="login-sub">Log in before using the POS or Inventory</div>

    <?php if ($error): ?>
      <div class="login-error"><i class="fas fa-triangle-exclamation"></i><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST" autocomplete="off">
      <input type="hidden" name="redirect" value="<?= $redirectField ?>">
      <div class="field-wrap">
        <label class="field-label" for="username">Username</label>
        <input class="field-input" type="text" id="username" name="username" placeholder="" required autofocus>
      </div>
      <div class="field-wrap">
        <label class="field-label" for="password">Password</label>
        <div class="pw-wrap">
          <input class="field-input" type="password" id="password" name="password" placeholder="••••••••" required>
          <button type="button" class="pw-toggle" id="togglePw"><i class="fas fa-eye"></i></button>
        </div>
      </div>
      <button type="submit" class="login-btn"><i class="fas fa-right-to-bracket"></i> Log In</button>
    </form>
    <div class="login-foot">Every action in the system is logged with the name of whoever is logged in.</div>
  </div>

<script>
document.getElementById('togglePw').addEventListener('click', function() {
    const pw = document.getElementById('password');
    const icon = this.querySelector('i');
    if (pw.type === 'password') { pw.type = 'text'; icon.className = 'fas fa-eye-slash'; }
    else { pw.type = 'password'; icon.className = 'fas fa-eye'; }
});
</script>
</body>
</html>