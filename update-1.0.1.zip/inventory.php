<?php
// Start session to hold form data on error
session_start();
include 'db.php';
include 'auth.php';
require_login();
dashboard_invalidate();

// Use prepared statements to prevent SQL injection
function execute_query($conn, $sql, $params = [], $types = "") {
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die('Prepare Error (' . $conn->errno . ') ' . $conn->error);
    }
    if ($params) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    return $stmt;
}

// NOTE: sync_product_totals() and deduct_stock_fefo() now live in db.php
// so both inventory.php and index.php (the POS checkout) share the same
// batch-syncing logic instead of drifting apart.

// Add Product
if (isset($_POST['add'])) {
    if (!empty($_POST['barcode'])) {
        $checkStmt = execute_query($conn, "SELECT id FROM products WHERE barcode = ?", [$_POST['barcode']], "s");
        if ($checkStmt->get_result()->num_rows > 0) {
            $_SESSION['form_data'] = $_POST;
            header("Location: inventory.php?duplicate_barcode=1");
            exit;
        }
    }
    // Product row itself starts with stock 0 / no expiry — the real
    // stock+expiry always come from its batch(es) in product_batches.
    execute_query(
        $conn,
        "INSERT INTO products (name, barcode, price, cost_price, stock, expiry_date) VALUES (?, ?, ?, ?, 0, NULL)",
        [$_POST['name'], $_POST['barcode'], $_POST['price'], $_POST['cost_price'] ?? 0],
        "ssdd"
    );
    $newProductId = $conn->insert_id;

    $initialStock = intval($_POST['stock'] ?? 0);
    if ($initialStock > 0) {
        execute_query(
            $conn,
            "INSERT INTO product_batches (product_id, quantity, expiry_date, received_date, received_by, notes) VALUES (?, ?, ?, NOW(), ?, ?)",
            [$newProductId, $initialStock, !empty($_POST['expiry_date']) ? $_POST['expiry_date'] : null, current_user_display(), 'Starting stock'],
            "iisss"
        );
        sync_product_totals($conn, $newProductId);
    }

    unset($_SESSION['form_data']);
    header("Location: inventory.php?add_success=1");
    exit;
}

// Update Product
// NOTE: stock and expiry_date are intentionally NOT editable here anymore —
// they're derived from product_batches. Use "Record Delivery" to add stock
// (with its own expiry date) and "Manage Batches" to adjust/write off a batch.
if (isset($_POST['update'])) {
    if (!empty($_POST['barcode'])) {
        $checkStmt = execute_query($conn, "SELECT id FROM products WHERE barcode = ? AND id != ?", [$_POST['barcode'], $_POST['id']], "si");
        if ($checkStmt->get_result()->num_rows > 0) {
            header("Location: inventory.php?duplicate_barcode=1&edit_id=" . $_POST['id']);
            exit;
        }
    }
    execute_query(
        $conn,
        "UPDATE products SET name=?, barcode=?, price=?, cost_price=? WHERE id=?",
        [$_POST['name'], $_POST['barcode'], $_POST['price'], $_POST['cost_price'] ?? 0, $_POST['id']],
        "ssddi"
    );
    header("Location: inventory.php?update_success=1");
    exit;
}

// Delete Product
if (isset($_GET['delete'])) {
    execute_query($conn, "DELETE FROM products WHERE id=?", [$_GET['delete']], "i");
    header("Location: inventory.php?delete_success=1");
    exit;
}

// Record Delivery — DOES NOT touch existing product info (name/price/etc.).
// This only adds to the stock of an existing product, and logs which
// currently logged-in user recorded this delivery.
if (isset($_POST['record_delivery'])) {
    $deliveryProductId = intval($_POST['delivery_product_id'] ?? 0);
    $deliveryQty       = intval($_POST['delivery_qty'] ?? 0);
    $deliveryExpiry    = !empty($_POST['delivery_expiry_date']) ? $_POST['delivery_expiry_date'] : null;
    $deliveryNotes     = trim($_POST['delivery_notes'] ?? '');
    $receivedBy        = current_user_display();

    if ($deliveryProductId <= 0 || $deliveryQty <= 0) {
        $_SESSION['delivery_error'] = "Please select a product and enter a valid quantity.";
        header("Location: inventory.php?delivery_error=1");
        exit;
    }

    $prodStmt = execute_query($conn, "SELECT name, stock FROM products WHERE id = ?", [$deliveryProductId], "i");
    $prodRow  = $prodStmt->get_result()->fetch_assoc();

    if (!$prodRow) {
        $_SESSION['delivery_error'] = "Product not found.";
        header("Location: inventory.php?delivery_error=1");
        exit;
    }

    $previousStock = intval($prodRow['stock']);
    $newStock      = $previousStock + $deliveryQty;

    // Each delivery becomes its OWN batch, with its own expiry date — this is
    // the key fix: existing stock with an earlier expiry is untouched, the
    // new stock is tracked separately even though it's the same product.
    execute_query(
        $conn,
        "INSERT INTO product_batches (product_id, quantity, expiry_date, received_date, received_by, notes) VALUES (?, ?, ?, NOW(), ?, ?)",
        [$deliveryProductId, $deliveryQty, $deliveryExpiry, $receivedBy, $deliveryNotes],
        "iisss"
    );
    sync_product_totals($conn, $deliveryProductId);

    execute_query(
        $conn,
        "INSERT INTO stock_deliveries (product_id, product_name, quantity_added, expiry_date, previous_stock, new_stock, received_by, notes, delivery_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())",
        [$deliveryProductId, $prodRow['name'], $deliveryQty, $deliveryExpiry, $previousStock, $newStock, $receivedBy, $deliveryNotes],
        "isisiiss"
    );

    header("Location: inventory.php?delivery_success=1");
    exit;
}

// Record Pullout — automatically decreases stock for the selected product
// and logs it. Reason is restricted to a fixed list; "Pulled Out By" is
// always the currently logged-in user (never a manual field).
$PULLOUT_REASONS = ['Expired', 'Damaged', 'Defective', 'Returned to supplier', 'Other'];
if (isset($_POST['record_pullout'])) {
    $pulloutProductId = intval($_POST['pullout_product_id'] ?? 0);
    $pulloutQty       = intval($_POST['pullout_qty'] ?? 0);
    $pulloutReason    = trim($_POST['pullout_reason'] ?? '');
    $pulledOutBy      = current_user_display();

    if ($pulloutProductId <= 0 || $pulloutQty <= 0) {
        $_SESSION['pullout_error'] = "Please select a product and enter a valid quantity.";
        header("Location: inventory.php?pullout_error=1");
        exit;
    }
    if (!in_array($pulloutReason, $PULLOUT_REASONS, true)) {
        $_SESSION['pullout_error'] = "Please select a valid reason.";
        header("Location: inventory.php?pullout_error=1");
        exit;
    }

    $prodStmt2 = execute_query($conn, "SELECT name, stock FROM products WHERE id = ?", [$pulloutProductId], "i");
    $prodRow2  = $prodStmt2->get_result()->fetch_assoc();

    if (!$prodRow2) {
        $_SESSION['pullout_error'] = "Product not found.";
        header("Location: inventory.php?pullout_error=1");
        exit;
    }

    $currentStock = intval($prodRow2['stock']);
    if ($pulloutQty > $currentStock) {
        $_SESSION['pullout_error'] = "Cannot pull out {$pulloutQty} — only {$currentStock} in stock for \"{$prodRow2['name']}\".";
        header("Location: inventory.php?pullout_error=1");
        exit;
    }

    // Automatic stock deduction (e.g. Initial 20 -> Pullout 5 -> Remaining 15).
    // Deduct from the actual product_batches rows (FEFO), not just the
    // cached products.stock — otherwise a later "Record Delivery" recomputes
    // stock from the batches and silently undoes this pull-out.
    deduct_stock_fefo($conn, $pulloutProductId, $pulloutQty);

    execute_query(
        $conn,
        "INSERT INTO stock_pullouts (product_id, product_name, quantity, reason, pulled_out_by, pullout_date) VALUES (?, ?, ?, ?, ?, NOW())",
        [$pulloutProductId, $prodRow2['name'], $pulloutQty, $pulloutReason, $pulledOutBy],
        "isiss"
    );

    header("Location: inventory.php?pullout_success=1");
    exit;
}

// ── AJAX: list batches for a product (Manage Batches modal), FEFO order ──
if (isset($_GET['fetch_batches'])) {
    header('Content-Type: application/json');
    $pid = intval($_GET['product_id'] ?? 0);
    $stmt = execute_query(
        $conn,
        "SELECT id, quantity, expiry_date, received_date, received_by, notes
         FROM product_batches WHERE product_id = ? AND quantity > 0
         ORDER BY (expiry_date IS NULL), expiry_date ASC, received_date ASC",
        [$pid],
        "i"
    );
    $res = $stmt->get_result();
    $batches = [];
    while ($b = $res->fetch_assoc()) {
        $batches[] = [
            'id'            => (int)$b['id'],
            'quantity'      => (int)$b['quantity'],
            'expiry_date'   => $b['expiry_date'],
            'expiry_label'  => $b['expiry_date'] ? date('M d, Y', strtotime($b['expiry_date'])) : 'No expiry set',
            'received_date' => date('M d, Y', strtotime($b['received_date'])),
            'received_by'   => $b['received_by'],
            'notes'         => $b['notes'],
        ];
    }
    echo json_encode($batches);
    exit;
}

// ── Adjust / write off a batch (e.g. spoiled, expired, miscounted) ──
if (isset($_POST['adjust_batch'])) {
    $batchId    = intval($_POST['batch_id'] ?? 0);
    $newQty     = intval($_POST['new_quantity'] ?? -1);

    if ($batchId > 0 && $newQty >= 0) {
        $bStmt = execute_query($conn, "SELECT product_id FROM product_batches WHERE id = ?", [$batchId], "i");
        $bRow  = $bStmt->get_result()->fetch_assoc();
        if ($bRow) {
            execute_query($conn, "UPDATE product_batches SET quantity = ? WHERE id = ?", [$newQty, $batchId], "ii");
            sync_product_totals($conn, $bRow['product_id']);
        }
    }
    header("Location: inventory.php?batch_updated=1");
    exit;
}

// ── AJAX: search products for the Record Delivery picker ─────────────
if (isset($_GET['search_delivery_product'])) {
    header('Content-Type: application/json');
    $q = '%' . trim($_GET['search_delivery_product']) . '%';
    $stmt = execute_query(
        $conn,
        "SELECT id, name, barcode, stock FROM products WHERE (name LIKE ? OR barcode LIKE ?) ORDER BY name ASC LIMIT 8",
        [$q, $q],
        "ss"
    );
    $res = $stmt->get_result();
    $items = [];
    while ($row = $res->fetch_assoc()) {
        $items[] = [
            'id'      => (int)$row['id'],
            'name'    => $row['name'],
            'barcode' => $row['barcode'],
            'stock'   => (int)$row['stock'],
        ];
    }
    echo json_encode($items);
    exit;
}

// ── AJAX: paginated delivery history (avoids dumping everything at once) ──
if (isset($_GET['fetch_deliveries'])) {
    header('Content-Type: application/json');
    $dhPage  = max(1, intval($_GET['dh_page'] ?? 1));
    $dhLimit = 8;
    $dhOffset = ($dhPage - 1) * $dhLimit;
    $dhSearch = trim($_GET['dh_search'] ?? '');

    $dhWhere  = '';
    $dhParams = [];
    $dhTypes  = '';
    if ($dhSearch !== '') {
        $dhWhere  = "WHERE product_name LIKE ? OR received_by LIKE ?";
        $term     = '%' . $dhSearch . '%';
        $dhParams = [$term, $term];
        $dhTypes  = 'ss';
    }

    $countStmt2 = execute_query($conn, "SELECT COUNT(*) AS total FROM stock_deliveries $dhWhere", $dhParams, $dhTypes);
    $dhTotal    = (int)$countStmt2->get_result()->fetch_assoc()['total'];
    $dhTotalPages = max(1, (int)ceil($dhTotal / $dhLimit));

    $rowParams = array_merge($dhParams, [$dhLimit, $dhOffset]);
    $rowTypes  = $dhTypes . 'ii';
    $rowStmt   = execute_query(
        $conn,
        "SELECT * FROM stock_deliveries $dhWhere ORDER BY delivery_date DESC LIMIT ? OFFSET ?",
        $rowParams,
        $rowTypes
    );
    $rowRes = $rowStmt->get_result();
    $rows = [];
    while ($r = $rowRes->fetch_assoc()) {
        $rows[] = [
            'product_name'   => $r['product_name'],
            'quantity_added' => (int)$r['quantity_added'],
            'expiry_date'    => !empty($r['expiry_date']) ? date('M d, Y', strtotime($r['expiry_date'])) : null,
            'previous_stock' => (int)$r['previous_stock'],
            'new_stock'      => (int)$r['new_stock'],
            'received_by'    => $r['received_by'],
            'notes'          => $r['notes'],
            'delivery_date'  => date('M d, Y g:ia', strtotime($r['delivery_date'])),
        ];
    }

    echo json_encode([
        'rows'       => $rows,
        'page'       => $dhPage,
        'totalPages' => $dhTotalPages,
        'total'      => $dhTotal,
    ]);
    exit;
}

// ── AJAX: paginated pullout history — ONLY the 5 allowed fields ──
if (isset($_GET['fetch_pullouts'])) {
    header('Content-Type: application/json');
    $phPage   = max(1, intval($_GET['ph_page'] ?? 1));
    $phLimit  = 8;
    $phOffset = ($phPage - 1) * $phLimit;
    $phSearch = trim($_GET['ph_search'] ?? '');

    $phWhere  = '';
    $phParams = [];
    $phTypes  = '';
    if ($phSearch !== '') {
        $phWhere  = "WHERE product_name LIKE ? OR pulled_out_by LIKE ? OR reason LIKE ?";
        $term     = '%' . $phSearch . '%';
        $phParams = [$term, $term, $term];
        $phTypes  = 'sss';
    }

    $phCountStmt = execute_query($conn, "SELECT COUNT(*) AS total FROM stock_pullouts $phWhere", $phParams, $phTypes);
    $phTotal       = (int)$phCountStmt->get_result()->fetch_assoc()['total'];
    $phTotalPages  = max(1, (int)ceil($phTotal / $phLimit));

    $phRowParams = array_merge($phParams, [$phLimit, $phOffset]);
    $phRowTypes  = $phTypes . 'ii';
    $phRowStmt   = execute_query(
        $conn,
        "SELECT * FROM stock_pullouts $phWhere ORDER BY pullout_date DESC LIMIT ? OFFSET ?",
        $phRowParams,
        $phRowTypes
    );
    $phRowRes = $phRowStmt->get_result();
    $phRows = [];
    while ($r = $phRowRes->fetch_assoc()) {
        $phRows[] = [
            'product_name'  => $r['product_name'],
            'quantity'      => (int)$r['quantity'],
            'reason'        => $r['reason'],
            'pulled_out_by' => $r['pulled_out_by'],
            'pullout_date'  => date('M d, Y g:ia', strtotime($r['pullout_date'])),
        ];
    }

    echo json_encode([
        'rows'       => $phRows,
        'page'       => $phPage,
        'totalPages' => $phTotalPages,
        'total'      => $phTotal,
    ]);
    exit;
}

// --- Data Fetching ---
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$filter = isset($_GET['filter']) ? $_GET['filter'] : '';
$sort   = isset($_GET['sort'])   ? $_GET['sort']   : 'name';
$order  = isset($_GET['order']) && $_GET['order'] === 'desc' ? 'DESC' : 'ASC';

$allowedSorts = ['name', 'barcode', 'price', 'stock', 'expiry_date'];
if (!in_array($sort, $allowedSorts)) $sort = 'name';

$params = [];
$types  = "";
$whereClauses = [];

if (!empty($search)) {
    $searchTerm = "%{$search}%";
    $whereClauses[] = "(name LIKE ? OR barcode LIKE ?)";
    $params = [$searchTerm, $searchTerm];
    $types  = "ss";
}
if ($filter === 'low_stock') {
    $whereClauses[] = "stock <= 3";
}
if ($filter === 'expired') {
    $whereClauses[] = "expiry_date IS NOT NULL AND expiry_date < CURDATE()";
}
if ($filter === 'ok') {
    $whereClauses[] = "(expiry_date IS NULL OR expiry_date >= CURDATE())";
}
if ($filter === 'expiring_soon') {
    $whereClauses[] = "expiry_date IS NOT NULL AND expiry_date >= CURDATE() AND expiry_date <= DATE_ADD(CURDATE(), INTERVAL 6 MONTH)";
}

$queryConditions = "";
if (!empty($whereClauses)) {
    $queryConditions = " WHERE " . implode(' AND ', $whereClauses);
}

// Pagination
$limit  = 10;
$page   = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

$countStmt = execute_query($conn, "SELECT COUNT(*) as total FROM products" . $queryConditions, $params, $types);
$totalRows  = $countStmt->get_result()->fetch_assoc()['total'];
$totalPages = ceil($totalRows / $limit);

$fetchParams = array_merge($params, [$limit, $offset]);
$fetchTypes  = $types . "ii";
$productsStmt = execute_query(
    $conn,
    "SELECT * FROM products" . $queryConditions . " ORDER BY {$sort} {$order} LIMIT ? OFFSET ?",
    $fetchParams,
    $fetchTypes
);
$productsResult = $productsStmt->get_result();

// Sidebar Stats
$totalProductsResult = $conn->query("SELECT COUNT(*) as total FROM products");
$totalProducts = $totalProductsResult->fetch_assoc()['total'];

$lowStockResult  = $conn->query("SELECT COUNT(*) as total FROM products WHERE stock <= 3");
$lowStockCount   = $lowStockResult->fetch_assoc()['total'];

$totalValueResult = $conn->query("SELECT SUM(price * stock) as total_value FROM products");
$totalValue = $totalValueResult->fetch_assoc()['total_value'] ?? 0;

$profitPotentialResult = $conn->query("SELECT SUM((price - cost_price) * stock) as profit_potential FROM products WHERE cost_price > 0");
$profitPotential = $profitPotentialResult->fetch_assoc()['profit_potential'] ?? 0;

$outOfStockResult = $conn->query("SELECT COUNT(*) as total FROM products WHERE stock = 0");
$outOfStockCount  = $outOfStockResult->fetch_assoc()['total'];

$expiredCountResult   = $conn->query("SELECT COUNT(*) as total FROM products WHERE expiry_date IS NOT NULL AND expiry_date < CURDATE()");
$expiredCount         = $expiredCountResult->fetch_assoc()['total'];

$expiringSoonResult   = $conn->query("SELECT COUNT(*) as total FROM products WHERE expiry_date IS NOT NULL AND expiry_date >= CURDATE() AND expiry_date <= DATE_ADD(CURDATE(), INTERVAL 6 MONTH)");
$expiringSoonCount    = $expiringSoonResult->fetch_assoc()['total'];

// Full product list / delivery log are now loaded via AJAX (see endpoints below)
// instead of preloading everything up-front — keeps this page fast even as
// the product list or delivery history grows.

function get_pagination_link($page, $search, $filter, $sort, $order) {
    return "?page={$page}&search=" . urlencode($search) . "&filter={$filter}&sort={$sort}&order={$order}";
}

function sort_link($col, $currentSort, $currentOrder, $search, $filter) {
    $newOrder = ($currentSort === $col && $currentOrder === 'ASC') ? 'desc' : 'asc';
    return "?sort={$col}&order={$newOrder}&search=" . urlencode($search) . "&filter={$filter}&page=1";
}

function sort_icon($col, $currentSort, $currentOrder) {
    if ($currentSort !== $col) return '<i class="fas fa-sort sort-icon muted"></i>';
    return $currentOrder === 'ASC'
        ? '<i class="fas fa-sort-up sort-icon active"></i>'
        : '<i class="fas fa-sort-down sort-icon active"></i>';
}

$form_data = isset($_SESSION['form_data']) ? $_SESSION['form_data'] : null;
if ($form_data) { unset($_SESSION['form_data']); }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory Management | Sari-Link</title>
    <link href="assets/css/fontawesome.min.css" rel="stylesheet">
    <link href="assets/css/fonts.css" rel="stylesheet">
    <link rel="shortcut icon" href="Sari-Link.ico" type="image/x-icon">
    <style>
        /* ── Design Tokens ─────────────────────────────────── */
        :root {
            --c-bg:          #eef2f8;
            --c-surface:     #ffffff;
            --c-surface-2:   #f6f8fb;
            --c-border:      #e2e8f2;
            --c-border-soft: #edf1f7;

            --c-primary:     #2563eb;
            --c-primary-dk:  #1e40af;
            --c-primary-lt:  #dbeafe;
            --c-primary-hv:  #1d4ed8;

            --c-success:     #059669;
            --c-success-lt:  #d1fae5;
            --c-warning:     #d97706;
            --c-warning-lt:  #fef3c7;
            --c-danger:      #dc2626;
            --c-danger-lt:   #fee2e2;

            --c-text:        #0f172a;
            --c-muted:       #57647c;
            --c-faint:       #8695ab;

            --radius-sm:  8px;
            --radius-md:  12px;
            --radius-lg:  18px;
            --radius-xl:  24px;

            --shadow-xs:  0 1px 2px rgba(15,23,42,.05);
            --shadow-sm:  0 2px 6px rgba(15,23,42,.06), 0 1px 2px rgba(15,23,42,.04);
            --shadow-md:  0 8px 24px rgba(15,23,42,.08), 0 2px 6px rgba(15,23,42,.04);
            --shadow-lg:  0 20px 48px rgba(15,23,42,.14), 0 4px 12px rgba(15,23,42,.06);

            --sidebar-w: 278px;
            --font-body: 'DM Sans', sans-serif;
            --font-disp: 'Playfair Display', serif;

            --transition: 200ms ease;
        }

        /* ── Reset ─────────────────────────────────────────── */
        *, *::before, *::after { margin: 0; padding: 0; box-sizing: border-box; }
        html { scroll-behavior: smooth; }
        body {
            font-family: var(--font-body);
            background: var(--c-bg);
            color: var(--c-text);
            line-height: 1.6;
            display: flex;
            min-height: 100vh;
        }
        a { text-decoration: none; color: inherit; }
        button { font-family: inherit; cursor: pointer; }
        input, select { font-family: inherit; }

        /* ── Scrollbar ─────────────────────────────────────── */
        ::-webkit-scrollbar { width: 6px; height: 6px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: var(--c-border); border-radius: 99px; }
        ::-webkit-scrollbar-thumb:hover { background: var(--c-faint); }

        /* ════════════════════════════════════════════════════
           SIDEBAR
        ════════════════════════════════════════════════════ */
        .sidebar {
            width: var(--sidebar-w);
            background: var(--c-surface);
            border-right: 1px solid var(--c-border);
            height: 100vh;
            position: fixed;
            left: 0; top: 0;
            display: flex;
            flex-direction: column;
            padding: 30px 22px 26px;
            overflow-y: auto;
            z-index: 100;
        }

        /* Logo */
        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 32px;
            padding-bottom: 24px;
            border-bottom: 1px solid var(--c-border-soft);
        }
        .logo-icon {
            width: 44px; height: 44px;
            background: linear-gradient(135deg,#eef4ff,#dce9fb);
            border-radius: var(--radius-md);
            display: flex; align-items: center; justify-content: center;
            color: #fff; font-size: 18px;
            flex-shrink: 0;
            padding: 7px;
            box-shadow: inset 0 0 0 1px rgba(37,99,235,.10);
        }
        .logo-icon img { width: 100%; height: 100%; object-fit: contain; }
        .logo-text { font-family: var(--font-disp); font-size: 21px; color: var(--c-text); letter-spacing: -0.01em; }
        .logo-text span { color: var(--c-primary); }

        /* Stat Cards */
        .stat-grid { display: flex; flex-direction: column; gap: 12px; margin-bottom: 26px; }

        .stat-card {
            background: var(--c-surface-2);
            border: 1px solid var(--c-border-soft);
            border-radius: var(--radius-md);
            padding: 16px 18px;
            display: flex;
            align-items: center;
            gap: 14px;
            transition: transform var(--transition), box-shadow var(--transition), border-color var(--transition);
            text-decoration: none;
            color: inherit;
        }
        .stat-card:hover { transform: translateY(-2px); box-shadow: var(--shadow-sm); }
        .stat-card.active { border-color: var(--c-primary); background: var(--c-primary-lt); box-shadow: 0 0 0 3px rgba(37,99,235,.12); }

        .stat-icon-wrap {
            width: 38px; height: 38px;
            border-radius: var(--radius-sm);
            display: flex; align-items: center; justify-content: center;
            font-size: 15px; color: #fff; flex-shrink: 0;
        }
        .si-blue    { background: linear-gradient(135deg, #3b82f6, #1d4ed8); }
        .si-amber   { background: linear-gradient(135deg, #f59e0b, #d97706); }
        .si-green   { background: linear-gradient(135deg, #10b981, #059669); }
        .si-red     { background: linear-gradient(135deg, #f87171, #dc2626); }

        .stat-info { min-width: 0; }
        .stat-val   { font-size: 20px; font-weight: 700; line-height: 1.1; color: var(--c-text); }
        .stat-label { font-size: 12px; color: var(--c-muted); margin-top: 1px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }

        /* Sidebar nav actions */
        .sidebar-actions { display: flex; flex-direction: column; gap: 8px; margin-top: auto; padding-top: 20px; border-top: 1px solid var(--c-border-soft); }

        .btn-primary {
            display: flex; align-items: center; justify-content: center; gap: 8px;
            background: var(--c-primary); color: #fff;
            border: none; border-radius: var(--radius-md);
            padding: 12px 18px; font-size: 14px; font-weight: 600;
            transition: background var(--transition), box-shadow var(--transition);
            box-shadow: 0 2px 6px rgba(37,99,235,.30);
        }
        .btn-primary:hover { background: var(--c-primary-hv); box-shadow: 0 4px 12px rgba(37,99,235,.35); }

        .btn-ghost {
            display: flex; align-items: center; justify-content: center; gap: 8px;
            background: var(--c-surface-2); color: var(--c-muted);
            border: 1px solid var(--c-border); border-radius: var(--radius-md);
            padding: 10px 18px; font-size: 14px; font-weight: 500;
            transition: all var(--transition);
        }
        .btn-ghost:hover { background: var(--c-border); color: var(--c-text); }

        /* ════════════════════════════════════════════════════
           MAIN CONTENT
        ════════════════════════════════════════════════════ */
        .main {
            margin-left: var(--sidebar-w);
            width: calc(100% - var(--sidebar-w));
            padding: 28px 30px;
            min-height: 100vh;
        }

        /* Top bar */
        .topbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 16px;
            margin-bottom: 28px;
        }
        .topbar-left { display: flex; align-items: center; gap: 14px; flex-wrap: wrap; }
        .page-title {
            font-family: var(--font-disp);
            font-size: 26px;
            color: var(--c-text);
            letter-spacing: -0.02em;
        }
        .filter-badge {
            display: inline-flex; align-items: center; gap: 6px;
            background: var(--c-warning-lt); color: var(--c-warning);
            border: 1px solid #fcd34d; border-radius: 99px;
            font-size: 12px; font-weight: 600; padding: 4px 12px;
        }
        .filter-badge a { color: var(--c-warning); margin-left: 2px; font-size: 11px; }
        .filter-badge a:hover { color: var(--c-text); }

        /* Search */
        .search-wrap {
            position: relative;
            display: flex; align-items: center;
        }
        .search-icon {
            position: absolute; left: 14px;
            color: var(--c-faint); font-size: 14px; pointer-events: none;
        }
        .search-input {
            width: 280px;
            padding: 10px 38px 10px 38px;
            border: 1px solid var(--c-border);
            border-radius: var(--radius-md);
            font-size: 14px;
            background: var(--c-surface);
            color: var(--c-text);
            transition: border-color var(--transition), box-shadow var(--transition);
            box-shadow: var(--shadow-xs);
        }
        .search-input::placeholder { color: var(--c-faint); }
        .search-input:focus { outline: none; border-color: var(--c-primary); box-shadow: 0 0 0 3px rgba(37,99,235,.12); }
        .clear-search {
            position: absolute; right: 12px;
            color: var(--c-faint); cursor: pointer; font-size: 13px;
            display: none; background: none; border: none; padding: 0;
        }
        .clear-search:hover { color: var(--c-danger); }

        /* Toolbar (export / items-per-page) */
        .toolbar {
            display: flex; align-items: center; justify-content: space-between;
            flex-wrap: wrap; gap: 12px;
            margin-bottom: 16px;
        }
        .toolbar-left { display: flex; align-items: center; gap: 10px; }
        .toolbar-label { font-size: 13px; color: var(--c-muted); }
        .results-count { font-size: 13px; color: var(--c-muted); }

        .btn-outline {
            display: inline-flex; align-items: center; gap: 7px;
            border: 1px solid var(--c-border); background: var(--c-surface);
            color: var(--c-muted); border-radius: var(--radius-sm);
            padding: 7px 14px; font-size: 13px; font-weight: 500;
            transition: all var(--transition); box-shadow: var(--shadow-xs);
        }
        .btn-outline:hover { border-color: var(--c-primary); color: var(--c-primary); background: var(--c-primary-lt); }
        .btn-outline.danger:hover { border-color: var(--c-danger); color: var(--c-danger); background: var(--c-danger-lt); }

        /* ── Add Product Panel ─────────────────────────────── */
        .add-panel {
            background: var(--c-surface);
            border: 1px solid var(--c-border);
            border-radius: var(--radius-lg);
            padding: 24px 26px;
            margin-bottom: 24px;
            box-shadow: var(--shadow-xs);
            display: none;
            animation: slideDown .25s ease;
        }
        .add-panel.open { display: block; }
        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-10px); }
            to   { opacity: 1; transform: translateY(0); }
        }
        .panel-title {
            font-size: 16px; font-weight: 600; color: var(--c-text);
            margin-bottom: 20px;
            display: flex; align-items: center; gap: 9px;
        }
        .panel-title i { color: var(--c-primary); }

        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 16px;
            align-items: flex-end;
        }
        .form-group { display: flex; flex-direction: column; gap: 6px; }
        .form-label { font-size: 12px; font-weight: 600; color: var(--c-muted); text-transform: uppercase; letter-spacing: .05em; }
        .form-input {
            padding: 10px 12px;
            border: 1px solid var(--c-border);
            border-radius: var(--radius-md);
            font-size: 14px;
            color: var(--c-text);
            background: var(--c-surface-2);
            transition: border-color var(--transition), box-shadow var(--transition);
        }
        .form-input:focus { outline: none; border-color: var(--c-primary); box-shadow: 0 0 0 3px rgba(37,99,235,.12); background: #fff; }
        .form-input::placeholder { color: var(--c-faint); }
        .form-input.error { border-color: var(--c-danger); }

        .btn-submit {
            display: flex; align-items: center; justify-content: center; gap: 8px;
            background: var(--c-primary); color: #fff;
            border: none; border-radius: var(--radius-md);
            padding: 10px 20px; font-size: 14px; font-weight: 600;
            height: 42px;
            transition: background var(--transition);
            box-shadow: 0 2px 6px rgba(37,99,235,.28);
        }
        .btn-submit:hover { background: var(--c-primary-hv); }

        /* ── Products Table ────────────────────────────────── */
        .table-card {
            background: var(--c-surface);
            border: 1px solid var(--c-border);
            border-radius: var(--radius-lg);
            box-shadow: var(--shadow-xs);
            overflow: hidden;
        }
        .table-wrap { overflow-x: auto; }

        table { width: 100%; border-collapse: collapse; }

        thead th {
            padding: 13px 16px;
            background: var(--c-surface-2);
            border-bottom: 1px solid var(--c-border);
            font-size: 11px; font-weight: 700;
            text-transform: uppercase; letter-spacing: .07em;
            color: var(--c-muted);
            text-align: left;
            white-space: nowrap;
        }
        thead th a {
            color: inherit;
            display: inline-flex; align-items: center; gap: 5px;
        }
        thead th a:hover { color: var(--c-primary); }

        .sort-icon       { font-size: 10px; }
        .sort-icon.muted  { opacity: .35; }
        .sort-icon.active { color: var(--c-primary); opacity: 1; }

        tbody tr { border-bottom: 1px solid var(--c-border-soft); transition: background var(--transition); }
        tbody tr:last-child { border-bottom: none; }
        tbody tr:hover { background: var(--c-surface-2); }

        tbody td { padding: 13px 16px; font-size: 14px; color: var(--c-text); vertical-align: middle; }

        .product-name { font-weight: 600; }
        .barcode-text { font-size: 12px; font-family: 'Courier New', monospace; color: var(--c-muted); background: var(--c-border-soft); padding: 3px 8px; border-radius: 4px; }
        .price-text { font-weight: 700; color: var(--c-success); }

        .stock-pill {
            display: inline-flex; align-items: center; gap: 5px;
            padding: 4px 12px; border-radius: 99px;
            font-size: 12px; font-weight: 700;
        }
        .stock-pill::before { content: ''; width: 6px; height: 6px; border-radius: 50%; }
        .pill-high   { background: var(--c-success-lt); color: var(--c-success);   }  .pill-high::before   { background: var(--c-success); }
        .pill-medium { background: var(--c-warning-lt); color: var(--c-warning);   }  .pill-medium::before { background: var(--c-warning); }
        .pill-low    { background: var(--c-danger-lt);  color: var(--c-danger);    }  .pill-low::before    { background: var(--c-danger); }
        .pill-zero   { background: #f1f5f9; color: var(--c-faint); }                  .pill-zero::before   { background: var(--c-faint); }

        /* ── Expiry Status Badges ──────────────────────────── */
        .expiry-badge {
            display: inline-flex; align-items: center; gap: 5px;
            padding: 4px 10px; border-radius: 99px;
            font-size: 12px; font-weight: 700;
        }
        .expiry-ok       { background: var(--c-success-lt); color: var(--c-success); }
        .expiry-expired  { background: var(--c-danger-lt);  color: var(--c-danger); }
        .expiry-soon     { background: var(--c-warning-lt); color: var(--c-warning); }
        .expiry-none     { color: var(--c-faint); font-size: 13px; }

        .actions-cell { display: flex; gap: 6px; }
        .btn-icon {
            display: inline-flex; align-items: center; gap: 5px;
            border: none; border-radius: var(--radius-sm);
            padding: 6px 12px; font-size: 12px; font-weight: 600;
            transition: all var(--transition);
        }
        .btn-edit   { background: var(--c-primary-lt); color: var(--c-primary); }
        .btn-edit:hover   { background: #bfdbfe; }
        .btn-delete { background: var(--c-danger-lt); color: var(--c-danger); }
        .btn-delete:hover { background: #fecaca; }

        .search-hl { background: #fef08a; border-radius: 3px; padding: 0 2px; }

        /* ── Empty State ───────────────────────────────────── */
        .empty-state {
            text-align: center;
            padding: 64px 20px;
        }
        .empty-icon {
            width: 70px; height: 70px;
            background: var(--c-surface-2);
            border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            margin: 0 auto 18px;
            font-size: 28px; color: var(--c-faint);
        }
        .empty-state h3 { font-size: 17px; color: var(--c-text); margin-bottom: 6px; }
        .empty-state p  { font-size: 14px; color: var(--c-muted); max-width: 380px; margin: 0 auto; }

        /* ── Pagination ────────────────────────────────────── */
        .pag-footer {
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 14px;
            padding: 16px 20px;
            border-top: 1px solid var(--c-border-soft);
        }
        .pag-info { font-size: 13px; color: var(--c-muted); }
        .pag {
            display: flex; gap: 4px;
        }
        .pag a, .pag span {
            display: inline-flex; align-items: center; justify-content: center;
            min-width: 34px; height: 34px;
            border-radius: var(--radius-sm);
            font-size: 13px; font-weight: 500;
        }
        .pag a { background: var(--c-surface-2); color: var(--c-muted); border: 1px solid var(--c-border); transition: all var(--transition); }
        .pag a:hover { background: var(--c-primary-lt); color: var(--c-primary); border-color: var(--c-primary); }
        .pag span.cur { background: var(--c-primary); color: #fff; border: 1px solid var(--c-primary); }
        .pag span.dots { color: var(--c-faint); border: none; background: none; }

        /* ── Modals ────────────────────────────────────────── */
        .modal-overlay {
            display: none;
            position: fixed; inset: 0;
            background: rgba(15,23,42,.40);
            backdrop-filter: blur(4px);
            z-index: 500;
            justify-content: center;
            align-items: center;
            animation: fadeBg .2s ease;
        }
        .modal-overlay.open { display: flex; }
        @keyframes fadeBg { from { opacity: 0; } to { opacity: 1; } }

        .modal-box {
            background: var(--c-surface);
            border-radius: var(--radius-xl);
            padding: 30px;
            width: 480px; max-width: 92%;
            position: relative;
            box-shadow: var(--shadow-lg);
            animation: popIn .22s ease;
        }
        @keyframes popIn {
            from { opacity: 0; transform: scale(.96) translateY(10px); }
            to   { opacity: 1; transform: scale(1) translateY(0); }
        }

        .modal-close {
            position: absolute; top: 16px; right: 18px;
            background: var(--c-surface-2); border: none;
            width: 30px; height: 30px; border-radius: 50%;
            font-size: 16px; color: var(--c-muted);
            display: flex; align-items: center; justify-content: center;
            transition: all var(--transition);
        }
        .modal-close:hover { background: var(--c-danger-lt); color: var(--c-danger); }

        .modal-title { font-size: 18px; font-weight: 700; margin-bottom: 22px; color: var(--c-text); }
        .modal-footer { margin-top: 22px; display: flex; justify-content: flex-end; }
        .btn-ok {
            background: var(--c-primary); color: #fff;
            border: none; border-radius: var(--radius-md);
            padding: 10px 22px; font-size: 14px; font-weight: 600;
            transition: background var(--transition);
        }
        .btn-ok:hover { background: var(--c-primary-hv); }

        /* ── Toast Notifications ───────────────────────────── */
        .toast-stack {
            position: fixed;
            top: 22px; right: 22px;
            z-index: 9999;
            display: flex; flex-direction: column; gap: 10px;
        }
        .toast {
            display: flex; align-items: center; gap: 12px;
            background: var(--c-surface);
            border: 1px solid var(--c-border);
            border-radius: var(--radius-md);
            padding: 13px 18px;
            box-shadow: var(--shadow-md);
            font-size: 14px; font-weight: 500;
            animation: toastIn .3s ease;
            min-width: 240px; max-width: 360px;
        }
        @keyframes toastIn {
            from { opacity: 0; transform: translateX(30px); }
            to   { opacity: 1; transform: translateX(0); }
        }
        .toast.success .toast-icon { color: var(--c-success); }
        .toast.error   .toast-icon { color: var(--c-danger); }
        .toast.warning .toast-icon { color: var(--c-warning); }
        .toast-bar {
            position: absolute; bottom: 0; left: 0; height: 3px;
            border-radius: 0 0 var(--radius-md) var(--radius-md);
            animation: shrink 3s linear forwards;
        }
        .toast.success .toast-bar { background: var(--c-success); }
        .toast.error   .toast-bar { background: var(--c-danger); }
        @keyframes shrink { from { width: 100%; } to { width: 0; } }

        /* ── Delete Confirm Modal ──────────────────────────── */
        .confirm-warning { display: flex; align-items: flex-start; gap: 14px; padding: 16px; background: var(--c-danger-lt); border-radius: var(--radius-md); margin-bottom: 22px; }
        .confirm-warning i { font-size: 22px; color: var(--c-danger); margin-top: 2px; }
        .confirm-warning p { font-size: 14px; color: var(--c-text); line-height: 1.5; }
        .confirm-warning strong { color: var(--c-danger); }
        .confirm-btns { display: flex; gap: 10px; justify-content: flex-end; }
        .btn-cancel { background: var(--c-surface-2); color: var(--c-muted); border: 1px solid var(--c-border); border-radius: var(--radius-md); padding: 9px 18px; font-size: 14px; font-weight: 600; transition: all var(--transition); }
        .btn-cancel:hover { border-color: var(--c-text); color: var(--c-text); }
        .btn-danger { background: var(--c-danger); color: #fff; border: none; border-radius: var(--radius-md); padding: 9px 18px; font-size: 14px; font-weight: 600; transition: background var(--transition); }
        .btn-danger:hover { background: #b91c1c; }

        /* ── Responsive ────────────────────────────────────── */
        @media (max-width: 900px) {
            :root { --sidebar-w: 0px; }
            .sidebar { transform: translateX(-100%); transition: transform .3s; }
            .sidebar.open { transform: translateX(0); width: 260px; }
            .main { margin-left: 0; width: 100%; }
            .mobile-menu-btn { display: flex !important; }
        }
        @media (max-width: 600px) {
            .main { padding: 16px; }
            .search-input { width: 100%; }
            .topbar { flex-direction: column; align-items: stretch; }
        }
        .mobile-menu-btn { display: none; align-items: center; gap: 8px; background: var(--c-surface); border: 1px solid var(--c-border); border-radius: var(--radius-md); padding: 8px 14px; font-size: 14px; color: var(--c-muted); }

        .inv-price-card { cursor: pointer; user-select: none; }
        .inv-price-card:hover { border-color: var(--c-primary); }

        /* ── Password Modal ────────────────────────────────── */
        #passwordModal .modal-box { max-width: 380px; }
        .pw-icon-wrap {
            width: 52px; height: 52px;
            background: var(--c-primary-lt);
            border-radius: var(--radius-lg);
            display: flex; align-items: center; justify-content: center;
            font-size: 22px; color: var(--c-primary);
            margin: 0 auto 16px;
        }
        .pw-heading {
            text-align: center;
            font-size: 18px; font-weight: 700;
            color: var(--c-text);
            margin-bottom: 4px;
        }
        .pw-sub {
            text-align: center;
            font-size: 13px; color: var(--c-muted);
            margin-bottom: 22px;
        }
        .pw-input-wrap {
            position: relative;
            margin-bottom: 8px;
        }
        .pw-input-wrap .form-input {
            width: 100%;
            padding-right: 42px;
        }
        .pw-toggle {
            position: absolute; right: 12px; top: 50%;
            transform: translateY(-50%);
            background: none; border: none;
            color: var(--c-faint); font-size: 15px;
            cursor: pointer; padding: 0;
            transition: color var(--transition);
        }
        .pw-toggle:hover { color: var(--c-muted); }
        .pw-error {
            display: none;
            font-size: 12px; color: var(--c-danger);
            margin-bottom: 14px;
            align-items: center; gap: 5px;
        }
        .pw-error.show { display: flex; }
        .pw-footer {
            display: flex; gap: 10px; margin-top: 16px;
        }
        .pw-footer .btn-cancel { flex: 1; text-align: center; }
        .pw-footer .btn-submit { flex: 2; }
        #passwordModal .form-input.shake {
            animation: shake .4s ease;
            border-color: var(--c-danger);
            box-shadow: 0 0 0 3px rgba(220,38,38,.12);
        }
        @keyframes shake {
            0%,100% { transform: translateX(0); }
            20%      { transform: translateX(-6px); }
            40%      { transform: translateX(6px); }
            60%      { transform: translateX(-4px); }
            80%      { transform: translateX(4px); }
        }
    </style>
</head>
<body>

    <!-- ══════════════ SIDEBAR ══════════════ -->
    <aside class="sidebar" id="sidebar">
        <div class="logo">
            <div class="logo-icon"><img src="assets/img/logo-mark.png" alt="Sari-Link"></div>
            <div class="logo-text">Sari<span>-Link</span></div>
        </div>

        <div class="stat-grid">
            <div class="stat-card">
                <div class="stat-icon-wrap si-blue"><i class="fas fa-box"></i></div>
                <div class="stat-info">
                    <div class="stat-val"><?= $totalProducts ?></div>
                    <div class="stat-label">Total Products</div>
                </div>
            </div>

            <div class="stat-card inv-price-card" id="invPriceCard" role="button" tabindex="0" onclick="toggleInvPrice()" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();toggleInvPrice();}" title="Click to show / hide (password required)">
                <div class="stat-icon-wrap si-green"><i class="fas fa-peso-sign"></i></div>
                <div class="stat-info">
                    <div class="stat-val"><span id="invPriceVal" data-shown="0">₱••••••</span></div>
                    <div class="stat-label">Total Inventory Price</div>
                </div>
            </div>

            <?php if ($lowStockCount > 0): ?>
            <a href="?filter=low_stock" class="stat-card <?= $filter === 'low_stock' ? 'active' : '' ?>">
                <div class="stat-icon-wrap si-amber"><i class="fas fa-triangle-exclamation"></i></div>
                <div class="stat-info">
                    <div class="stat-val"><?= $lowStockCount ?></div>
                    <div class="stat-label">Low Stock Items</div>
                </div>
            </a>
            <?php endif; ?>

            <?php if ($outOfStockCount > 0): ?>
            <div class="stat-card">
                <div class="stat-icon-wrap si-red"><i class="fas fa-ban"></i></div>
                <div class="stat-info">
                    <div class="stat-val"><?= $outOfStockCount ?></div>
                    <div class="stat-label">Out of Stock</div>
                </div>
            </div>
            <?php endif; ?>

            <?php if ($expiredCount > 0): ?>
            <a href="?filter=expired" class="stat-card <?= $filter === 'expired' ? 'active' : '' ?>">
                <div class="stat-icon-wrap" style="background:linear-gradient(135deg,#ef4444,#b91c1c)"><i class="fas fa-circle-xmark"></i></div>
                <div class="stat-info">
                    <div class="stat-val" style="color:var(--c-danger)"><?= $expiredCount ?></div>
                    <div class="stat-label">Expired Products</div>
                </div>
            </a>
            <?php endif; ?>

            <?php if ($expiringSoonCount > 0): ?>
            <a href="?filter=expiring_soon" class="stat-card <?= $filter === 'expiring_soon' ? 'active' : '' ?>">
                <div class="stat-icon-wrap" style="background:linear-gradient(135deg,#f59e0b,#b45309)"><i class="fas fa-clock"></i></div>
                <div class="stat-info">
                    <div class="stat-val" style="color:var(--c-warning)"><?= $expiringSoonCount ?></div>
                    <div class="stat-label">Expiring in 6 Months</div>
                </div>
            </a>
            <?php endif; ?>

        </div>

        <div class="sidebar-actions">
            <button class="btn-primary" id="addProductToggleBtn">
                <i class="fas fa-plus"></i> Add New Product
            </button>
            <button class="btn-primary" style="background:linear-gradient(135deg,#10b981,#059669);" id="openDeliveryModalBtn" type="button">
                <i class="fas fa-truck-loading"></i> Record Delivery
            </button>
            <button class="btn-ghost" id="openDeliveryHistoryBtn" type="button">
                <i class="fas fa-clock-rotate-left"></i> Delivery History
            </button>
            <button class="btn-primary" style="background:linear-gradient(135deg,#dc2626,#b91c1c);" id="openPulloutModalBtn" type="button">
                <i class="fas fa-dolly"></i> Record Pullout
            </button>
            <button class="btn-ghost" id="openPulloutHistoryBtn" type="button">
                <i class="fas fa-clipboard-list"></i> Pullout History
            </button>
            <a href="index.php" class="btn-ghost">
                <i class="fas fa-arrow-left"></i> Main Menu
            </a>
        </div>
    </aside>

    <!-- ══════════════ MAIN ══════════════ -->
    <main class="main">

        <!-- Top bar -->
        <div class="topbar">
            <div class="topbar-left">
                <button class="mobile-menu-btn" id="mobileMenuBtn">
                    <i class="fas fa-bars"></i>
                </button>
                <h1 class="page-title">Product Inventory</h1>
                <?php if ($filter === 'low_stock'): ?>
                    <span class="filter-badge">
                        <i class="fas fa-filter"></i> Low Stock
                        <a href="?search=<?= urlencode($search) ?>"><i class="fas fa-times"></i></a>
                    </span>
                <?php elseif ($filter === 'expired'): ?>
                    <span class="filter-badge" style="background:#fee2e2;color:var(--c-danger);border-color:#fca5a5">
                        <i class="fas fa-circle-xmark"></i> Expired
                        <a href="?search=<?= urlencode($search) ?>" style="color:var(--c-danger)"><i class="fas fa-times"></i></a>
                    </span>
                <?php elseif ($filter === 'ok'): ?>
                    <span class="filter-badge" style="background:var(--c-success-lt);color:var(--c-success);border-color:#6ee7b7">
                        <i class="fas fa-circle-check"></i> OK / Not Expired
                        <a href="?search=<?= urlencode($search) ?>" style="color:var(--c-success)"><i class="fas fa-times"></i></a>
                    </span>
                <?php elseif ($filter === 'expiring_soon'): ?>
                    <span class="filter-badge" style="background:var(--c-warning-lt);color:var(--c-warning);border-color:#fcd34d">
                        <i class="fas fa-clock"></i> Expiring Soon
                        <a href="?search=<?= urlencode($search) ?>" style="color:var(--c-warning)"><i class="fas fa-times"></i></a>
                    </span>
                <?php endif; ?>
            </div>

            <form method="GET" id="searchForm">
                <input type="hidden" name="page" value="1">
                <input type="hidden" name="filter" value="<?= htmlspecialchars($filter) ?>">
                <input type="hidden" name="sort" value="<?= htmlspecialchars($sort) ?>">
                <input type="hidden" name="order" value="<?= htmlspecialchars(strtolower($order)) ?>">
                <div class="search-wrap">
                    <i class="fas fa-magnifying-glass search-icon"></i>
                    <input
                        type="text"
                        name="search"
                        id="searchInput"
                        class="search-input"
                        placeholder="Search by name or barcode…"
                        value="<?= htmlspecialchars($search) ?>"
                        autocomplete="off"
                    >
                    <button type="button" class="clear-search" id="clearSearch"><i class="fas fa-times"></i></button>
                </div>
            </form>
        </div>

        <!-- Add Product Panel -->
        <div class="add-panel" id="addProductSection">
            <div class="panel-title"><i class="fas fa-plus-circle"></i> Add New Product</div>
            <form method="POST" class="form-grid" id="addProductForm">
                <div class="form-group">
                    <label class="form-label" for="name">Product Name</label>
                    <input type="text" id="name" name="name" class="form-input" placeholder="e.g. Biogesic" value="<?= htmlspecialchars($form_data['name'] ?? '') ?>" required>
                </div>
                <div class="form-group">
                    <label class="form-label" for="barcode">Barcode</label>
                    <input type="text" id="barcode" name="barcode" class="form-input" placeholder="Scan or type barcode" value="<?= htmlspecialchars($form_data['barcode'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label class="form-label" for="price">Selling Price (₱)</label>
                    <input type="number" step="0.01" min="0" id="price" name="price" class="form-input" placeholder="0.00" value="<?= htmlspecialchars($form_data['price'] ?? '') ?>" required>
                </div>
                <div class="form-group">
                    <label class="form-label" for="cost_price">Cost Price (₱)</label>
                    <input type="number" step="0.01" min="0" id="cost_price" name="cost_price" class="form-input" placeholder="0.00" value="<?= htmlspecialchars($form_data['cost_price'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label class="form-label" for="stock">Stock Qty</label>
                    <input type="number" min="0" id="stock" name="stock" class="form-input" placeholder="0" value="<?= htmlspecialchars($form_data['stock'] ?? '') ?>" required>
                </div>
                <div class="form-group">
                    <label class="form-label" for="expiry_date">Expiry Date</label>
                    <input type="date" id="expiry_date" name="expiry_date" class="form-input" value="<?= htmlspecialchars($form_data['expiry_date'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <button type="submit" name="add" class="btn-submit">
                        <i class="fas fa-plus-circle"></i> Add Product
                    </button>
                </div>
            </form>
        </div>

        <!-- Toolbar -->
        <div class="toolbar">
            <div class="toolbar-left">
                <span class="results-count">
                    <?= $totalRows ?> product<?= $totalRows !== 1 ? 's' : '' ?>
                    <?= !empty($search) ? '· matching "<strong>' . htmlspecialchars($search) . '</strong>"' : '' ?>
                </span>
            </div>
            <div class="toolbar-left" style="gap:8px;flex-wrap:wrap">
                <!-- Expiry Filter -->
                <form method="GET" id="filterForm" style="display:inline-flex;align-items:center;gap:6px">
                    <input type="hidden" name="search" value="<?= htmlspecialchars($search) ?>">
                    <input type="hidden" name="sort"   value="<?= htmlspecialchars($sort) ?>">
                    <input type="hidden" name="order"  value="<?= htmlspecialchars(strtolower($order)) ?>">
                    <input type="hidden" name="page"   value="1">
                    <select name="filter" class="form-input" style="padding:7px 10px;font-size:13px;height:36px;width:auto;background:var(--c-surface)" onchange="this.form.submit()">
                        <option value=""               <?= $filter === ''              ? 'selected' : '' ?>>All Products</option>
                        <option value="ok"             <?= $filter === 'ok'            ? 'selected' : '' ?>>✅ OK / Not Expired</option>
                        <option value="expired"        <?= $filter === 'expired'       ? 'selected' : '' ?>>❌ Expired</option>
                        <option value="expiring_soon"  <?= $filter === 'expiring_soon' ? 'selected' : '' ?>>⚠️ Expiring Soon (6mo)</option>
                        <option value="low_stock"      <?= $filter === 'low_stock'     ? 'selected' : '' ?>>📦 Low Stock</option>
                    </select>
                </form>
                <button class="btn-outline" id="exportCsvBtn" title="Export current view to CSV">
                    <i class="fas fa-file-csv"></i> Export CSV
                </button>
                <?php if ($filter || !empty($search)): ?>
                    <a href="inventory.php" class="btn-outline danger">
                        <i class="fas fa-filter-circle-xmark"></i> Clear All Filters
                    </a>
                <?php endif; ?>
            </div>
        </div>

        <!-- Table Card -->
        <div class="table-card">
            <div class="table-wrap">
                <table id="productTable">
                    <thead>
                        <tr>
                            <th><a href="<?= sort_link('name', $sort, $order, $search, $filter) ?>">Product Name <?= sort_icon('name', $sort, $order) ?></a></th>
                            <th>Barcode</th>
                            <th><a href="<?= sort_link('price', $sort, $order, $search, $filter) ?>">Selling Price <?= sort_icon('price', $sort, $order) ?></a></th>
                            <th>Cost Price</th>
                            <th>Profit</th>
                            <th><a href="<?= sort_link('stock', $sort, $order, $search, $filter) ?>">Stock <?= sort_icon('stock', $sort, $order) ?></a></th>
                            <th><a href="<?= sort_link('expiry_date', $sort, $order, $search, $filter) ?>">Expiry Date <?= sort_icon('expiry_date', $sort, $order) ?></a></th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($productsResult->num_rows > 0): ?>
                            <?php while ($row = $productsResult->fetch_assoc()):
                                $stock = (int)$row['stock'];
                                $pillClass = $stock === 0 ? 'pill-zero' : ($stock > 20 ? 'pill-high' : ($stock > 3 ? 'pill-medium' : 'pill-low'));
                                $productName = htmlspecialchars($row['name']);
                                $barcode     = htmlspecialchars($row['barcode']);
                                if (!empty($search)) {
                                    $esc = preg_quote(htmlspecialchars($search), '/');
                                    $productName = preg_replace("/({$esc})/i", '<mark class="search-hl">$1</mark>', $productName);
                                    $barcode     = preg_replace("/({$esc})/i", '<mark class="search-hl">$1</mark>', $barcode);
                                }
                            ?>
                            <tr>
                                <td class="product-name"><?= $productName ?></td>
                                <td><?php if ($row['barcode']): ?><span class="barcode-text"><?= $barcode ?></span><?php else: ?><span style="color:var(--c-faint)">—</span><?php endif; ?></td>
                                <td class="price-text">₱<?= number_format($row['price'], 2) ?></td>
                                <td style="color:var(--c-muted)">
                                    <?php if ($row['cost_price'] > 0): ?>
                                        ₱<?= number_format($row['cost_price'], 2) ?>
                                    <?php else: ?>
                                        <span style="color:var(--c-faint)">—</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php
                                    $profit = $row['price'] - $row['cost_price'];
                                    if ($row['cost_price'] > 0):
                                        $color = $profit > 0 ? 'var(--c-success)' : 'var(--c-danger)';
                                    ?>
                                        <strong style="color:<?= $color ?>">₱<?= number_format($profit, 2) ?></strong>
                                    <?php else: ?>
                                        <span style="color:var(--c-faint)">—</span>
                                    <?php endif; ?>
                                </td>
                                <td><span class="stock-pill <?= $pillClass ?>"><?= $stock ?></span></td>
                                <td>
                                    <?php if (!empty($row['expiry_date'])): ?>
                                        <span style="font-size:13px;color:var(--c-muted)"><?= date('M d, Y', strtotime($row['expiry_date'])) ?></span>
                                    <?php else: ?>
                                        <span class="expiry-none">—</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php
                                    if (empty($row['expiry_date'])):
                                    ?>
                                        <span class="expiry-none" style="font-size:12px">No Date</span>
                                    <?php
                                    else:
                                        $today    = new DateTime('today');
                                        $expDate  = new DateTime($row['expiry_date']);
                                        $diff     = (int)$today->diff($expDate)->format('%r%a');
                                        if ($diff < 0):
                                    ?>
                                        <span class="expiry-badge expiry-expired"><i class="fas fa-circle-xmark"></i> Expired</span>
                                    <?php elseif ($diff <= 180): ?>
                                        <span class="expiry-badge expiry-soon"><i class="fas fa-clock"></i> <?= $diff === 0 ? 'Today!' : "In {$diff}d" ?></span>
                                    <?php else: ?>
                                        <span class="expiry-badge expiry-ok"><i class="fas fa-circle-check"></i> OK</span>
                                    <?php endif; endif; ?>
                                </td>
                                <td class="actions-cell">
                                    <button
                                        class="btn-icon btn-edit"
                                        onclick='openEditModal(<?= json_encode($row, JSON_HEX_APOS | JSON_HEX_QUOT) ?>)'
                                        title="Edit"
                                    ><i class="fas fa-pen"></i> Edit</button>
                                    <button
                                        class="btn-icon btn-delete"
                                        onclick='openDeleteConfirm(<?= $row["id"] ?>, <?= json_encode($row["name"], JSON_HEX_APOS | JSON_HEX_QUOT) ?>, "<?= urlencode($search) ?>", <?= $page ?>, "<?= urlencode($filter) ?>")'
                                        title="Delete"
                                    ><i class="fas fa-trash"></i></button>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="9">
                                    <div class="empty-state">
                                        <div class="empty-icon"><i class="fas fa-box-open"></i></div>
                                        <h3>No Products Found</h3>
                                        <p>
                                            <?php
                                            if ($filter === 'low_stock') echo "Great news — no low stock items right now.";
                                            elseif (!empty($search)) echo "No results for '" . htmlspecialchars($search) . "'. Try a different term.";
                                            else echo "Your inventory is empty. Click <strong>Add New Product</strong> to get started.";
                                            ?>
                                        </p>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <?php if ($totalPages > 1): ?>
                <div class="pag-footer">
                    <div class="pag-info">
                        Showing <?= $offset + 1 ?>–<?= min($offset + $limit, $totalRows) ?> of <?= $totalRows ?>
                    </div>
                    <nav class="pag" aria-label="Pagination">
                        <?php if ($page > 1): ?>
                            <a href="<?= get_pagination_link($page - 1, $search, $filter, $sort, strtolower($order)) ?>"><i class="fas fa-chevron-left"></i></a>
                        <?php endif; ?>
                        <?php
                            $s = max(1, $page - 2);
                            $e = min($totalPages, $page + 2);
                            if ($s > 1) {
                                echo "<a href='" . get_pagination_link(1, $search, $filter, $sort, strtolower($order)) . "'>1</a>";
                                if ($s > 2) echo "<span class='dots'>…</span>";
                            }
                            for ($i = $s; $i <= $e; $i++) {
                                if ($i === $page) echo "<span class='cur'>$i</span>";
                                else echo "<a href='" . get_pagination_link($i, $search, $filter, $sort, strtolower($order)) . "'>$i</a>";
                            }
                            if ($e < $totalPages) {
                                if ($e < $totalPages - 1) echo "<span class='dots'>…</span>";
                                echo "<a href='" . get_pagination_link($totalPages, $search, $filter, $sort, strtolower($order)) . "'>$totalPages</a>";
                            }
                        ?>
                        <?php if ($page < $totalPages): ?>
                            <a href="<?= get_pagination_link($page + 1, $search, $filter, $sort, strtolower($order)) ?>"><i class="fas fa-chevron-right"></i></a>
                        <?php endif; ?>
                    </nav>
                </div>
            <?php endif; ?>
        </div>
    </main>

    <!-- ══════════════ PASSWORD MODAL ══════════════ -->
    <div class="modal-overlay" id="passwordModal">
        <div class="modal-box">
            <button class="modal-close" id="pwCancelBtn">&times;</button>
            <div class="pw-icon-wrap"><i class="fas fa-lock"></i></div>
            <div class="pw-heading">Enter Password</div>
            <div class="pw-sub">Password required to edit the product.</div>
            <div class="pw-input-wrap">
                <input type="password" id="pwInput" class="form-input" placeholder="Password" autocomplete="current-password">
                <button type="button" class="pw-toggle" id="pwToggle" tabindex="-1">
                    <i class="fas fa-eye" id="pwToggleIcon"></i>
                </button>
            </div>
            <div class="pw-error" id="pwError">
                <i class="fas fa-circle-xmark"></i> Incorrect password. Please try again.
            </div>
            <div class="pw-footer">
                <button class="btn-cancel" id="pwCancelBtn2">Cancel</button>
                <button class="btn-submit" id="pwSubmitBtn">
                    <i class="fas fa-unlock"></i> Unlock
                </button>
            </div>
        </div>
    </div>

    <!-- ══════════════ EDIT MODAL ══════════════ -->
    <div class="modal-overlay" id="editModal">
        <div class="modal-box">
            <button class="modal-close" onclick="closeModal('editModal')">&times;</button>
            <div class="modal-title"><i class="fas fa-pen" style="color:var(--c-primary);margin-right:8px"></i>Edit Product</div>
            <form method="POST">
                <input type="hidden" id="edit-id" name="id">
                <div class="form-grid" style="grid-template-columns:1fr 1fr">
                    <div class="form-group" style="grid-column:1/-1">
                        <label class="form-label">Product Name</label>
                        <input type="text" id="edit-name" name="name" class="form-input" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Barcode</label>
                        <input type="text" id="edit-barcode" name="barcode" class="form-input">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Selling Price (₱)</label>
                        <input type="number" step="0.01" min="0" id="edit-price" name="price" class="form-input" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Cost Price (₱)</label>
                        <input type="number" step="0.01" min="0" id="edit-cost-price" name="cost_price" class="form-input">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Stock Qty <span style="font-weight:400;color:var(--c-faint)">(auto, from batches)</span></label>
                        <input type="number" id="edit-stock" class="form-input" readonly disabled style="background:var(--c-surface-2);color:var(--c-muted);">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Nearest Expiry <span style="font-weight:400;color:var(--c-faint)">(auto, from batches)</span></label>
                        <input type="text" id="edit-expiry-date" class="form-input" readonly disabled style="background:var(--c-surface-2);color:var(--c-muted);">
                    </div>
                    <div class="form-group" style="grid-column:1/-1">
                        <button type="button" class="btn-ghost" style="width:100%" onclick="openBatchesModal(document.getElementById('edit-id').value, document.getElementById('edit-name').value)">
                            <i class="fas fa-layer-group"></i> Manage Batches / Expiry Dates
                        </button>
                    </div>
                    <div class="form-group" style="grid-column:1/-1">
                        <button type="submit" name="update" class="btn-submit" style="width:100%">
                            <i class="fas fa-floppy-disk"></i> Save Changes
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- ══════════════ MANAGE BATCHES MODAL ══════════════ -->
    <div class="modal-overlay" id="batchesModal">
        <div class="modal-box" style="width:600px;">
            <button class="modal-close" onclick="closeModal('batchesModal')">&times;</button>
            <div class="modal-title"><i class="fas fa-layer-group" style="color:var(--c-primary);margin-right:8px"></i>Batches — <span id="batchesProductName"></span></div>
            <p style="font-size:13px;color:var(--c-muted);margin:-10px 0 16px;">
                A list of every batch/delivery of this product, with the soonest to expire at the top (FEFO order — this is the one that should be sold/used first). Change the quantity to 0 to write off a batch (e.g. expired or damaged).
            </p>
            <div id="batchesList" style="max-height:360px;overflow-y:auto;display:flex;flex-direction:column;gap:10px;"></div>
        </div>
    </div>

    <!-- ══════════════ RECORD DELIVERY MODAL ══════════════ -->
    <div class="modal-overlay" id="deliveryModal">
        <div class="modal-box">
            <button class="modal-close" onclick="closeModal('deliveryModal')">&times;</button>
            <div class="modal-title"><i class="fas fa-truck-loading" style="color:var(--c-success);margin-right:8px"></i>Record Delivery</div>
            <p style="font-size:13px;color:var(--c-muted);margin:-10px 0 18px;">
                This only adds to the stock of an existing product — the name, price, and other details stay unchanged.
                It will also be recorded that <strong><?= htmlspecialchars(current_user_display()) ?></strong> made this delivery entry.
            </p>
            <form method="POST" id="deliveryForm">
                <div class="form-group" style="margin-bottom:14px;position:relative;">
                    <label class="form-label" for="delivery_product_search">Product</label>
                    <input type="text" id="delivery_product_search" class="form-input" placeholder="Search by product name or barcode…" autocomplete="off" required>
                    <input type="hidden" id="delivery_product_id" name="delivery_product_id">
                    <div id="deliveryProductResults" style="display:none;position:absolute;z-index:30;left:0;right:0;background:#fff;border:1px solid var(--c-border);border-radius:10px;margin-top:4px;max-height:230px;overflow-y:auto;box-shadow:0 6px 20px rgba(15,23,42,.10);"></div>
                </div>
                <div class="form-group" style="margin-bottom:14px;">
                    <label class="form-label" for="delivery_qty">Quantity Received</label>
                    <input type="number" min="1" id="delivery_qty" name="delivery_qty" class="form-input" placeholder="e.g. 50" required>
                </div>
                <div class="form-group" style="margin-bottom:14px;">
                    <label class="form-label" for="delivery_expiry_date">Expiry Date of this batch</label>
                    <input type="date" id="delivery_expiry_date" name="delivery_expiry_date" class="form-input">
                    <span style="font-size:12px;color:var(--c-muted);display:block;margin-top:4px;">
                        If the expiry of the new delivery differs from the remaining stock, each batch is tracked separately — this will not overwrite the old stock.
                    </span>
                </div>
                <div class="form-group" style="margin-bottom:14px;">
                    <label class="form-label" for="delivery_notes">Note (optional)</label>
                    <input type="text" id="delivery_notes" name="delivery_notes" class="form-input" placeholder="e.g. supplier, DR number, etc.">
                </div>
                <button type="submit" name="record_delivery" class="btn-submit" style="width:100%;background:var(--c-success, #059669);">
                    <i class="fas fa-plus"></i> Add to Stock
                </button>
            </form>
        </div>
    </div>

    <!-- ══════════════ DELIVERY HISTORY MODAL ══════════════ -->
    <div class="modal-overlay" id="deliveryHistoryModal">
        <div class="modal-box" style="width:720px;">
            <button class="modal-close" onclick="closeModal('deliveryHistoryModal')">&times;</button>
            <div class="modal-title"><i class="fas fa-clock-rotate-left" style="color:var(--c-primary);margin-right:8px"></i>Delivery History</div>

            <div style="margin-bottom:14px;">
                <input type="text" id="dhSearchInput" class="form-input" placeholder="Search by product name or recorded-by…" autocomplete="off">
            </div>

            <div style="max-height:400px;overflow-y:auto;position:relative;">
                <table style="width:100%;border-collapse:collapse;">
                    <thead>
                        <tr style="text-align:left;font-size:11px;text-transform:uppercase;color:var(--c-muted);border-bottom:1px solid var(--c-border);">
                            <th style="padding:8px 6px;">Date</th>
                            <th style="padding:8px 6px;">Product</th>
                            <th style="padding:8px 6px;text-align:center;">Added</th>
                            <th style="padding:8px 6px;text-align:center;">Before → After</th>
                            <th style="padding:8px 6px;">Recorded By</th>
                            <th style="padding:8px 6px;">Note</th>
                        </tr>
                    </thead>
                    <tbody id="dhTbody">
                        <tr><td colspan="6" style="padding:24px 6px;text-align:center;color:var(--c-muted);">Loading…</td></tr>
                    </tbody>
                </table>
            </div>

            <div style="display:flex;align-items:center;justify-content:space-between;margin-top:14px;">
                <span id="dhSummary" style="font-size:12px;color:var(--c-muted);"></span>
                <div style="display:flex;align-items:center;gap:8px;">
                    <button type="button" class="btn-ghost" id="dhPrevBtn" style="padding:6px 12px;font-size:12.5px;"><i class="fas fa-chevron-left"></i></button>
                    <span id="dhPageIndicator" style="font-size:12.5px;font-weight:700;color:var(--c-text);white-space:nowrap;">Page 1</span>
                    <button type="button" class="btn-ghost" id="dhNextBtn" style="padding:6px 12px;font-size:12.5px;"><i class="fas fa-chevron-right"></i></button>
                </div>
            </div>
        </div>
    </div>

    <!-- ══════════════ RECORD PULLOUT MODAL ══════════════ -->
    <div class="modal-overlay" id="pulloutModal">
        <div class="modal-box">
            <button class="modal-close" onclick="closeModal('pulloutModal')">&times;</button>
            <div class="modal-title"><i class="fas fa-dolly" style="color:var(--c-danger, #dc2626);margin-right:8px"></i>Record Pullout</div>
            <p style="font-size:13px;color:var(--c-muted);margin:-10px 0 18px;">
                This removes stock from an existing product — the name, price, and other details stay unchanged.
                It will be recorded that <strong><?= htmlspecialchars(current_user_display()) ?></strong> pulled this stock out.
            </p>
            <form method="POST" id="pulloutForm">
                <div class="form-group" style="margin-bottom:14px;position:relative;">
                    <label class="form-label" for="pullout_product_search">Product</label>
                    <input type="text" id="pullout_product_search" class="form-input" placeholder="Search by product name or barcode…" autocomplete="off" required>
                    <input type="hidden" id="pullout_product_id" name="pullout_product_id">
                    <div id="pulloutProductResults" style="display:none;position:absolute;z-index:30;left:0;right:0;background:#fff;border:1px solid var(--c-border);border-radius:10px;margin-top:4px;max-height:230px;overflow-y:auto;box-shadow:0 6px 20px rgba(15,23,42,.10);"></div>
                </div>
                <div class="form-group" style="margin-bottom:14px;">
                    <label class="form-label" for="pullout_qty">Quantity</label>
                    <input type="number" min="1" id="pullout_qty" name="pullout_qty" class="form-input" placeholder="e.g. 5" required>
                </div>
                <div class="form-group" style="margin-bottom:14px;">
                    <label class="form-label" for="pullout_reason">Reason</label>
                    <select id="pullout_reason" name="pullout_reason" class="form-input" required>
                        <option value="" disabled selected>Select a reason…</option>
                        <option value="Expired">Expired</option>
                        <option value="Damaged">Damaged</option>
                        <option value="Defective">Defective</option>
                        <option value="Returned to supplier">Returned to supplier</option>
                        <option value="Other">Other</option>
                    </select>
                </div>
                <button type="submit" name="record_pullout" class="btn-submit" style="width:100%;background:var(--c-danger, #dc2626);">
                    <i class="fas fa-dolly"></i> Remove from Stock
                </button>
            </form>
        </div>
    </div>

    <!-- ══════════════ PULLOUT HISTORY MODAL ══════════════ -->
    <div class="modal-overlay" id="pulloutHistoryModal">
        <div class="modal-box" style="width:720px;">
            <button class="modal-close" onclick="closeModal('pulloutHistoryModal')">&times;</button>
            <div class="modal-title"><i class="fas fa-clipboard-list" style="color:var(--c-danger, #dc2626);margin-right:8px"></i>Pullout History</div>

            <div style="margin-bottom:14px;">
                <input type="text" id="phSearchInput" class="form-input" placeholder="Search by product, reason, or pulled out by…" autocomplete="off">
            </div>

            <div style="max-height:400px;overflow-y:auto;position:relative;">
                <table style="width:100%;border-collapse:collapse;">
                    <thead>
                        <tr style="text-align:left;font-size:11px;text-transform:uppercase;color:var(--c-muted);border-bottom:1px solid var(--c-border);">
                            <th style="padding:8px 6px;">Date &amp; Time</th>
                            <th style="padding:8px 6px;">Product</th>
                            <th style="padding:8px 6px;text-align:center;">Quantity</th>
                            <th style="padding:8px 6px;">Reason</th>
                            <th style="padding:8px 6px;">Pulled Out By</th>
                        </tr>
                    </thead>
                    <tbody id="phTbody">
                        <tr><td colspan="5" style="padding:24px 6px;text-align:center;color:var(--c-muted);">Loading…</td></tr>
                    </tbody>
                </table>
            </div>

            <div style="display:flex;align-items:center;justify-content:space-between;margin-top:14px;">
                <span id="phSummary" style="font-size:12px;color:var(--c-muted);"></span>
                <div style="display:flex;align-items:center;gap:8px;">
                    <button type="button" class="btn-ghost" id="phPrevBtn" style="padding:6px 12px;font-size:12.5px;"><i class="fas fa-chevron-left"></i></button>
                    <span id="phPageIndicator" style="font-size:12.5px;font-weight:700;color:var(--c-text);white-space:nowrap;">Page 1</span>
                    <button type="button" class="btn-ghost" id="phNextBtn" style="padding:6px 12px;font-size:12.5px;"><i class="fas fa-chevron-right"></i></button>
                </div>
            </div>
        </div>
    </div>

    <!-- ══════════════ DELETE CONFIRM MODAL ══════════════ -->
    <div class="modal-overlay" id="deleteModal">
        <div class="modal-box">
            <button class="modal-close" onclick="closeModal('deleteModal')">&times;</button>
            <div class="modal-title">Delete Product</div>
            <div class="confirm-warning">
                <i class="fas fa-triangle-exclamation"></i>
                <p>You're about to delete <strong id="deleteProductName"></strong>. This action is permanent and cannot be undone.</p>
            </div>
            <div class="confirm-btns">
                <button class="btn-cancel" onclick="closeModal('deleteModal')">Cancel</button>
                <a id="deleteConfirmLink" href="#" class="btn-danger"><i class="fas fa-trash"></i> Delete</a>
            </div>
        </div>
    </div>

    <!-- ══════════════ DUPLICATE BARCODE MODAL ══════════════ -->
    <div class="modal-overlay" id="dupModal">
        <div class="modal-box">
            <button class="modal-close" onclick="closeDupModal()">&times;</button>
            <div class="modal-title"><i class="fas fa-barcode" style="color:var(--c-warning);margin-right:8px"></i>Duplicate Barcode</div>
            <p style="font-size:14px;color:var(--c-muted);line-height:1.6">
                The barcode you entered already exists in the inventory. Please use a unique barcode for each product.
            </p>
            <div class="modal-footer">
                <button class="btn-ok" onclick="closeDupModal()">Got it</button>
            </div>
        </div>
    </div>

    <!-- Toast Stack -->
    <div class="toast-stack" id="toastStack"></div>

    <!-- ══════════════ JS ══════════════ -->
    <script>
    document.addEventListener('DOMContentLoaded', () => {
        const urlParams = new URLSearchParams(window.location.search);

        /* ─── Toast ─── */
        function showToast(msg, type = 'success') {
            const stack = document.getElementById('toastStack');
            const icons = { success: 'fa-circle-check', error: 'fa-circle-xmark', warning: 'fa-triangle-exclamation' };
            const t = document.createElement('div');
            t.className = `toast ${type}`;
            t.style.position = 'relative; overflow:hidden';
            t.innerHTML = `
                <i class="fas ${icons[type]} toast-icon"></i>
                <span>${msg}</span>
                <div class="toast-bar"></div>`;
            stack.appendChild(t);
            setTimeout(() => {
                t.style.transition = 'opacity .4s, transform .4s';
                t.style.opacity = '0';
                t.style.transform = 'translateX(20px)';
                setTimeout(() => t.remove(), 400);
            }, 3000);
        }

        <?php if (isset($_GET['add_success'])): ?>    showToast('Product added successfully!', 'success'); <?php endif; ?>
        <?php if (isset($_GET['update_success'])): ?> showToast('Product updated successfully!', 'success'); <?php endif; ?>
        <?php if (isset($_GET['delete_success'])): ?> showToast('Product deleted.', 'success'); <?php endif; ?>
        <?php if (isset($_GET['delivery_success'])): ?> showToast('Delivery recorded — stock updated!', 'success'); <?php endif; ?>
        <?php if (isset($_GET['delivery_error'])): ?> showToast(<?= json_encode($_SESSION['delivery_error'] ?? 'There was an error recording the delivery.') ?>, 'error'); <?php unset($_SESSION['delivery_error']); ?><?php endif; ?>
        <?php if (isset($_GET['pullout_success'])): ?> showToast('Pullout recorded — stock updated!', 'success'); <?php endif; ?>
        <?php if (isset($_GET['pullout_error'])): ?> showToast(<?= json_encode($_SESSION['pullout_error'] ?? 'There was an error recording the pullout.') ?>, 'error'); <?php unset($_SESSION['pullout_error']); ?><?php endif; ?>

        /* ─── Search ─── */
        const searchInput  = document.getElementById('searchInput');
        const clearSearch  = document.getElementById('clearSearch');
        let debounce;

        function doSearch() {
            urlParams.delete('duplicate_barcode');
            urlParams.delete('edit_id');
            window.history.replaceState({}, '', location.pathname + '?' + urlParams);
            document.getElementById('searchForm').submit();
        }

        searchInput.addEventListener('input', () => {
            clearSearch.style.display = searchInput.value ? 'block' : 'none';
            clearTimeout(debounce);
            debounce = setTimeout(doSearch, 420);
        });
        clearSearch.addEventListener('click', () => {
            searchInput.value = '';
            clearSearch.style.display = 'none';
            doSearch();
        });
        if (searchInput.value) clearSearch.style.display = 'block';

        /* ─── Add Panel Toggle ─── */
        const addPanel = document.getElementById('addProductSection');
        document.getElementById('addProductToggleBtn').addEventListener('click', () => {
            const open = addPanel.classList.toggle('open');
            if (open) document.getElementById('name').focus();
        });
        <?php if ($form_data): ?> addPanel.classList.add('open'); <?php endif; ?>

        /* ─── Modals ─── */
        window.closeModal = (id) => {
            document.getElementById(id).classList.remove('open');
        };

        document.getElementById('openDeliveryModalBtn').addEventListener('click', () => {
            resetDeliveryForm();
            document.getElementById('deliveryModal').classList.add('open');
        });
        document.getElementById('openDeliveryHistoryBtn').addEventListener('click', () => {
            document.getElementById('deliveryHistoryModal').classList.add('open');
            dhLoad(1);
        });
        <?php if (isset($_GET['delivery_error'])): ?>
        document.getElementById('deliveryModal').classList.add('open');
        <?php endif; ?>

        document.getElementById('openPulloutModalBtn').addEventListener('click', () => {
            resetPulloutForm();
            document.getElementById('pulloutModal').classList.add('open');
        });
        document.getElementById('openPulloutHistoryBtn').addEventListener('click', () => {
            document.getElementById('pulloutHistoryModal').classList.add('open');
            phLoad(1);
        });
        <?php if (isset($_GET['pullout_error'])): ?>
        document.getElementById('pulloutModal').classList.add('open');
        <?php endif; ?>

        /* ─── Record Delivery: search-as-you-type product picker ─── */
        function resetDeliveryForm() {
            document.getElementById('delivery_product_search').value = '';
            document.getElementById('delivery_product_id').value = '';
            document.getElementById('delivery_qty').value = '';
            document.getElementById('delivery_notes').value = '';
            document.getElementById('delivery_product_search').style.borderColor = '';
        }

        (function() {
            const input   = document.getElementById('delivery_product_search');
            const hidden  = document.getElementById('delivery_product_id');
            const results = document.getElementById('deliveryProductResults');
            let items = [], activeIdx = -1, debounce;

            function clearResults() {
                results.style.display = 'none';
                results.innerHTML = '';
                items = [];
                activeIdx = -1;
            }

            function renderItems(list) {
                items = list;
                if (!list.length) {
                    results.innerHTML = '<div style="padding:10px 12px;font-size:13px;color:var(--c-muted);">No matching products.</div>';
                    results.style.display = 'block';
                    return;
                }
                results.innerHTML = '';
                list.forEach((item, i) => {
                    const row = document.createElement('div');
                    row.className = 'dh-pick-row';
                    row.style.cssText = 'padding:9px 12px;cursor:pointer;border-bottom:1px solid var(--c-border-soft,#eff2f7);';
                    row.innerHTML =
                        '<div style="font-size:13px;font-weight:600;color:var(--c-text);">' + item.name +
                        (item.barcode ? ' <span style="font-weight:400;color:var(--c-muted);">(' + item.barcode + ')</span>' : '') + '</div>' +
                        '<div style="font-size:11.5px;color:var(--c-muted);margin-top:2px;">Current stock: ' + item.stock + '</div>';
                    row.addEventListener('mouseenter', () => setActive(i));
                    row.addEventListener('click', () => selectItem(i));
                    results.appendChild(row);
                });
                results.style.display = 'block';
            }

            function setActive(idx) {
                [...results.children].forEach((c, i) => {
                    c.style.background = i === idx ? 'var(--c-primary-lt,#dbeafe)' : '';
                });
                activeIdx = idx;
            }

            function selectItem(idx) {
                const item = items[idx];
                if (!item) return;
                hidden.value = item.id;
                input.value = item.name + (item.barcode ? ' (' + item.barcode + ')' : '');
                input.style.borderColor = '';
                clearResults();
            }

            input.addEventListener('input', function() {
                hidden.value = '';
                clearTimeout(debounce);
                const q = this.value.trim();
                if (q.length < 2) { clearResults(); return; }
                debounce = setTimeout(() => {
                    fetch('inventory.php?search_delivery_product=' + encodeURIComponent(q))
                        .then(r => r.json())
                        .then(renderItems)
                        .catch(() => {});
                }, 250);
            });

            input.addEventListener('keydown', function(e) {
                if (!items.length) return;
                if (e.key === 'ArrowDown') { e.preventDefault(); setActive(Math.min(activeIdx + 1, items.length - 1)); }
                else if (e.key === 'ArrowUp') { e.preventDefault(); setActive(Math.max(activeIdx - 1, 0)); }
                else if (e.key === 'Enter') { if (activeIdx >= 0) { e.preventDefault(); selectItem(activeIdx); } }
                else if (e.key === 'Escape') { clearResults(); }
            });

            document.addEventListener('click', function(e) {
                if (!input.contains(e.target) && !results.contains(e.target)) clearResults();
            });

            document.getElementById('deliveryForm').addEventListener('submit', function(e) {
                if (!hidden.value) {
                    e.preventDefault();
                    input.style.borderColor = 'var(--c-danger)';
                    showToast('Please search and select a product first.', 'error');
                }
            });
        })();

        /* ─── Delivery History: paginated + searchable (no more dumping everything at once) ─── */
        let dhPage = 1, dhSearch = '', dhDebounce;

        function dhLoad(page) {
            dhPage = page;
            const tbody = document.getElementById('dhTbody');
            tbody.innerHTML = '<tr><td colspan="6" style="padding:24px 6px;text-align:center;color:var(--c-muted);">Loading…</td></tr>';
            fetch('inventory.php?fetch_deliveries=1&dh_page=' + dhPage + '&dh_search=' + encodeURIComponent(dhSearch))
                .then(r => r.json())
                .then(data => {
                    if (!data.rows.length) {
                        tbody.innerHTML = '<tr><td colspan="6" style="padding:24px 6px;text-align:center;color:var(--c-muted);">No deliveries found.</td></tr>';
                    } else {
                        tbody.innerHTML = data.rows.map(d => (
                            '<tr style="border-bottom:1px solid var(--c-border-soft,#eff2f7);">' +
                                '<td style="padding:8px 6px;font-size:12.5px;color:var(--c-muted);white-space:nowrap;">' + d.delivery_date + '</td>' +
                                '<td style="padding:8px 6px;font-size:13px;font-weight:600;">' + escapeHtml(d.product_name) + '</td>' +
                                '<td style="padding:8px 6px;text-align:center;font-weight:700;color:var(--c-success,#059669);">+' + d.quantity_added + '</td>' +
                                '<td style="padding:8px 6px;text-align:center;font-size:12.5px;color:var(--c-muted);">' + d.previous_stock + ' → ' + d.new_stock + '</td>' +
                                '<td style="padding:8px 6px;font-size:13px;"><span style="display:inline-flex;align-items:center;gap:5px;font-weight:700;"><i class="fas fa-user-circle" style="color:var(--c-primary);"></i>' + escapeHtml(d.received_by) + '</span></td>' +
                                '<td style="padding:8px 6px;font-size:12.5px;color:var(--c-muted);">' + escapeHtml(d.notes || '') + '</td>' +
                            '</tr>'
                        )).join('');
                    }
                    document.getElementById('dhPageIndicator').textContent = 'Page ' + data.page + ' of ' + data.totalPages;
                    document.getElementById('dhSummary').textContent = data.total + ' total record' + (data.total === 1 ? '' : 's');
                    document.getElementById('dhPrevBtn').disabled = data.page <= 1;
                    document.getElementById('dhNextBtn').disabled = data.page >= data.totalPages;
                })
                .catch(() => {
                    tbody.innerHTML = '<tr><td colspan="6" style="padding:24px 6px;text-align:center;color:var(--c-danger);">Could not load delivery history.</td></tr>';
                });
        }

        function escapeHtml(str) {
            const div = document.createElement('div');
            div.textContent = str == null ? '' : String(str);
            return div.innerHTML;
        }

        document.getElementById('dhPrevBtn').addEventListener('click', () => { if (dhPage > 1) dhLoad(dhPage - 1); });
        document.getElementById('dhNextBtn').addEventListener('click', () => dhLoad(dhPage + 1));
        document.getElementById('dhSearchInput').addEventListener('input', function() {
            clearTimeout(dhDebounce);
            const q = this.value;
            dhDebounce = setTimeout(() => { dhSearch = q; dhLoad(1); }, 300);
        });

        /* ─── Record Pullout: search-as-you-type product picker ─── */
        function resetPulloutForm() {
            document.getElementById('pullout_product_search').value = '';
            document.getElementById('pullout_product_id').value = '';
            document.getElementById('pullout_qty').value = '';
            document.getElementById('pullout_reason').value = '';
            document.getElementById('pullout_product_search').style.borderColor = '';
        }

        (function() {
            const input   = document.getElementById('pullout_product_search');
            const hidden  = document.getElementById('pullout_product_id');
            const results = document.getElementById('pulloutProductResults');
            let items = [], activeIdx = -1, debounce;

            function clearResults() {
                results.style.display = 'none';
                results.innerHTML = '';
                items = [];
                activeIdx = -1;
            }

            function renderItems(list) {
                items = list;
                if (!list.length) {
                    results.innerHTML = '<div style="padding:10px 12px;font-size:13px;color:var(--c-muted);">No matching products.</div>';
                    results.style.display = 'block';
                    return;
                }
                results.innerHTML = '';
                list.forEach((item, i) => {
                    const row = document.createElement('div');
                    row.className = 'dh-pick-row';
                    row.style.cssText = 'padding:9px 12px;cursor:pointer;border-bottom:1px solid var(--c-border-soft,#eff2f7);';
                    row.innerHTML =
                        '<div style="font-size:13px;font-weight:600;color:var(--c-text);">' + item.name +
                        (item.barcode ? ' <span style="font-weight:400;color:var(--c-muted);">(' + item.barcode + ')</span>' : '') + '</div>' +
                        '<div style="font-size:11.5px;color:var(--c-muted);margin-top:2px;">Current stock: ' + item.stock + '</div>';
                    row.addEventListener('mouseenter', () => setActive(i));
                    row.addEventListener('click', () => selectItem(i));
                    results.appendChild(row);
                });
                results.style.display = 'block';
            }

            function setActive(idx) {
                [...results.children].forEach((c, i) => {
                    c.style.background = i === idx ? 'var(--c-primary-lt,#dbeafe)' : '';
                });
                activeIdx = idx;
            }

            function selectItem(idx) {
                const item = items[idx];
                if (!item) return;
                hidden.value = item.id;
                input.value = item.name + (item.barcode ? ' (' + item.barcode + ')' : '');
                input.style.borderColor = '';
                clearResults();
            }

            input.addEventListener('input', function() {
                hidden.value = '';
                clearTimeout(debounce);
                const q = this.value.trim();
                if (q.length < 2) { clearResults(); return; }
                debounce = setTimeout(() => {
                    fetch('inventory.php?search_delivery_product=' + encodeURIComponent(q))
                        .then(r => r.json())
                        .then(renderItems)
                        .catch(() => {});
                }, 250);
            });

            input.addEventListener('keydown', function(e) {
                if (!items.length) return;
                if (e.key === 'ArrowDown') { e.preventDefault(); setActive(Math.min(activeIdx + 1, items.length - 1)); }
                else if (e.key === 'ArrowUp') { e.preventDefault(); setActive(Math.max(activeIdx - 1, 0)); }
                else if (e.key === 'Enter') { if (activeIdx >= 0) { e.preventDefault(); selectItem(activeIdx); } }
                else if (e.key === 'Escape') { clearResults(); }
            });

            document.addEventListener('click', function(e) {
                if (!input.contains(e.target) && !results.contains(e.target)) clearResults();
            });

            document.getElementById('pulloutForm').addEventListener('submit', function(e) {
                if (!hidden.value) {
                    e.preventDefault();
                    input.style.borderColor = 'var(--c-danger)';
                    showToast('Please search and select a product first.', 'error');
                }
            });
        })();

        /* ─── Pullout History: paginated + searchable ─── */
        let phPage = 1, phSearch = '', phDebounce;

        function phLoad(page) {
            phPage = page;
            const tbody = document.getElementById('phTbody');
            tbody.innerHTML = '<tr><td colspan="5" style="padding:24px 6px;text-align:center;color:var(--c-muted);">Loading…</td></tr>';
            fetch('inventory.php?fetch_pullouts=1&ph_page=' + phPage + '&ph_search=' + encodeURIComponent(phSearch))
                .then(r => r.json())
                .then(data => {
                    if (!data.rows.length) {
                        tbody.innerHTML = '<tr><td colspan="5" style="padding:24px 6px;text-align:center;color:var(--c-muted);">No pullouts found.</td></tr>';
                    } else {
                        tbody.innerHTML = data.rows.map(d => (
                            '<tr style="border-bottom:1px solid var(--c-border-soft,#eff2f7);">' +
                                '<td style="padding:8px 6px;font-size:12.5px;color:var(--c-muted);white-space:nowrap;">' + d.pullout_date + '</td>' +
                                '<td style="padding:8px 6px;font-size:13px;font-weight:600;">' + escapeHtml(d.product_name) + '</td>' +
                                '<td style="padding:8px 6px;text-align:center;font-weight:700;color:var(--c-danger,#dc2626);">-' + d.quantity + '</td>' +
                                '<td style="padding:8px 6px;font-size:12.5px;color:var(--c-muted);">' + escapeHtml(d.reason) + '</td>' +
                                '<td style="padding:8px 6px;font-size:13px;"><span style="display:inline-flex;align-items:center;gap:5px;font-weight:700;"><i class="fas fa-user-circle" style="color:var(--c-primary);"></i>' + escapeHtml(d.pulled_out_by) + '</span></td>' +
                            '</tr>'
                        )).join('');
                    }
                    document.getElementById('phPageIndicator').textContent = 'Page ' + data.page + ' of ' + data.totalPages;
                    document.getElementById('phSummary').textContent = data.total + ' total record' + (data.total === 1 ? '' : 's');
                    document.getElementById('phPrevBtn').disabled = data.page <= 1;
                    document.getElementById('phNextBtn').disabled = data.page >= data.totalPages;
                })
                .catch(() => {
                    tbody.innerHTML = '<tr><td colspan="5" style="padding:24px 6px;text-align:center;color:var(--c-danger);">Could not load pullout history.</td></tr>';
                });
        }

        document.getElementById('phPrevBtn').addEventListener('click', () => { if (phPage > 1) phLoad(phPage - 1); });
        document.getElementById('phNextBtn').addEventListener('click', () => phLoad(phPage + 1));
        document.getElementById('phSearchInput').addEventListener('input', function() {
            clearTimeout(phDebounce);
            const q = this.value;
            phDebounce = setTimeout(() => { phSearch = q; phLoad(1); }, 300);
        });

        window.openEditModal = (p) => {
            // Store product data, then show password modal first
            window._pendingEditProduct = p;
            window._pendingAction = 'edit';
            document.querySelector('#passwordModal .pw-sub').textContent = PW_SUB_DEFAULT;
            const overlay = document.getElementById('passwordModal');
            const input   = document.getElementById('pwInput');
            const errEl   = document.getElementById('pwError');
            input.value = '';
            input.classList.remove('shake');
            errEl.classList.remove('show');
            overlay.classList.add('open');
            setTimeout(() => input.focus(), 120);
        };

        // ─── Password Modal Logic ───
        const EDIT_PASSWORD = 'assenuj@azodnem29'; // <-- replace with your desired password
        const INV_TOTAL_PRICE = <?= json_encode('₱' . number_format((float)$totalValue, 2)) ?>;
        const PW_SUB_DEFAULT  = 'Password required to edit the product.';

        window.toggleInvPrice = () => {
            const el   = document.getElementById('invPriceVal');
            if (el.dataset.shown === '1') {            // hide again (no password needed)
                el.textContent = '₱••••••';
                el.dataset.shown = '0';
                return;
            }
            window._pendingAction = 'reveal';          // show → ask for password first
            document.querySelector('#passwordModal .pw-sub').textContent = 'Password required to view the total inventory price.';
            const input = document.getElementById('pwInput');
            input.value = '';
            input.classList.remove('shake');
            document.getElementById('pwError').classList.remove('show');
            document.getElementById('passwordModal').classList.add('open');
            setTimeout(() => input.focus(), 120);
        };

        function _doOpenEditModal(p) {
            document.getElementById('edit-id').value    = p.id;
            document.getElementById('edit-name').value  = p.name;
            document.getElementById('edit-barcode').value = p.barcode;
            document.getElementById('edit-price').value = p.price;
            document.getElementById('edit-cost-price').value = p.cost_price ?? '';
            document.getElementById('edit-stock').value = p.stock;
            document.getElementById('edit-expiry-date').value = p.expiry_date
                ? new Date(p.expiry_date + 'T00:00:00').toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })
                : 'No batch expiry set';
            document.getElementById('editModal').classList.add('open');
        }

        /* ─── Manage Batches Modal ─── */
        window.openBatchesModal = (productId, productName) => {
            document.getElementById('batchesProductName').textContent = productName;
            const listEl = document.getElementById('batchesList');
            listEl.innerHTML = '<div style="text-align:center;padding:24px;color:var(--c-muted);">Loading…</div>';
            document.getElementById('batchesModal').classList.add('open');

            fetch('inventory.php?fetch_batches=1&product_id=' + encodeURIComponent(productId))
                .then(r => r.json())
                .then(batches => {
                    if (!batches.length) {
                        listEl.innerHTML = '<div style="text-align:center;padding:24px;color:var(--c-muted);">No batches with stock for this product.</div>';
                        return;
                    }
                    listEl.innerHTML = batches.map((b, i) => {
                        const soon = i === 0 ? '<span style="font-size:11px;font-weight:700;color:var(--c-success);background:var(--c-success-lt);padding:2px 8px;border-radius:99px;margin-left:8px;">Use first</span>' : '';
                        return `
                        <div style="border:1px solid var(--c-border);border-radius:10px;padding:12px 14px;">
                            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">
                                <div style="font-weight:700;font-size:14px;">${escapeHtml(b.expiry_label)}${soon}</div>
                                <div style="font-size:12px;color:var(--c-muted);">Received: ${escapeHtml(b.received_date)}</div>
                            </div>
                            <div style="font-size:12.5px;color:var(--c-muted);margin-bottom:10px;">
                                ${b.received_by ? 'By ' + escapeHtml(b.received_by) : ''} ${b.notes ? '· ' + escapeHtml(b.notes) : ''}
                            </div>
                            <form method="POST" style="display:flex;align-items:center;gap:8px;">
                                <input type="hidden" name="batch_id" value="${b.id}">
                                <label style="font-size:13px;color:var(--c-text);">Qty:</label>
                                <input type="number" min="0" name="new_quantity" value="${b.quantity}" class="form-input" style="width:90px;padding:6px 10px;">
                                <button type="submit" name="adjust_batch" class="btn-outline" style="padding:6px 12px;font-size:12.5px;" onclick="return confirm('Update the quantity of this batch?');">Save</button>
                                <button type="submit" name="adjust_batch" formnovalidate onclick="this.form.new_quantity.value=0; return confirm('Write off this entire batch (set stock to 0)? Use this if this stock has expired or been damaged.');" class="btn-outline danger" style="padding:6px 12px;font-size:12.5px;">Write off</button>
                            </form>
                        </div>`;
                    }).join('');
                })
                .catch(() => {
                    listEl.innerHTML = '<div style="text-align:center;padding:24px;color:var(--c-danger);">Could not load batches.</div>';
                });
        };

        function checkEditPassword() {
            const input  = document.getElementById('pwInput');
            const errEl  = document.getElementById('pwError');
            if (input.value === EDIT_PASSWORD) {
                document.getElementById('passwordModal').classList.remove('open');
                if (window._pendingAction === 'edit') {
                    _doOpenEditModal(window._pendingEditProduct);
                    window._pendingEditProduct = null;
                } else if (window._pendingAction === 'delete') {
                    const d = window._pendingDelete;
                    document.getElementById('deleteProductName').textContent = d.name;
                    document.getElementById('deleteConfirmLink').href =
                        `?delete=${d.id}&search=${d.search}&page=${d.page}&filter=${d.filter}`;
                    document.getElementById('deleteModal').classList.add('open');
                    window._pendingDelete = null;
                } else if (window._pendingAction === 'reveal') {
                    const el = document.getElementById('invPriceVal');
                    el.textContent = INV_TOTAL_PRICE;
                    el.dataset.shown = '1';
                }
                window._pendingAction = null;
            } else {
                input.classList.remove('shake');
                void input.offsetWidth;
                input.classList.add('shake');
                errEl.classList.add('show');
                input.value = '';
                input.focus();
            }
        }

        document.getElementById('pwSubmitBtn').addEventListener('click', checkEditPassword);
        document.getElementById('pwInput').addEventListener('keydown', e => {
            if (e.key === 'Enter') checkEditPassword();
        });

        [document.getElementById('pwCancelBtn'), document.getElementById('pwCancelBtn2')].forEach(btn => {
            btn.addEventListener('click', () => {
                document.getElementById('passwordModal').classList.remove('open');
                window._pendingEditProduct = null;
                window._pendingDelete = null;
                window._pendingAction = null;
            });
        });

        // Password show/hide toggle
        document.getElementById('pwToggle').addEventListener('click', () => {
            const input = document.getElementById('pwInput');
            const icon  = document.getElementById('pwToggleIcon');
            if (input.type === 'password') {
                input.type = 'text';
                icon.className = 'fas fa-eye-slash';
            } else {
                input.type = 'password';
                icon.className = 'fas fa-eye';
            }
        });

        window.openDeleteConfirm = (id, name, search, page, filter) => {
            // Store delete data, then show password modal first
            window._pendingDelete = { id, name, search, page, filter };
            window._pendingAction = 'delete';
            document.querySelector('#passwordModal .pw-sub').textContent = PW_SUB_DEFAULT;
            const overlay = document.getElementById('passwordModal');
            const input   = document.getElementById('pwInput');
            const errEl   = document.getElementById('pwError');
            input.value = '';
            input.classList.remove('shake');
            errEl.classList.remove('show');
            overlay.classList.add('open');
            setTimeout(() => input.focus(), 120);
        };

        /* ─── Duplicate Barcode Modal ─── */
        window.closeDupModal = () => {
            document.getElementById('dupModal').classList.remove('open');
            const clean = location.href.split('?')[0];
            window.history.replaceState({}, document.title, clean);
        };
        <?php if (isset($_GET['duplicate_barcode'])): ?>
            document.getElementById('dupModal').classList.add('open');
        <?php endif; ?>

        /* ─── Click outside to close ─── */
        document.querySelectorAll('.modal-overlay').forEach(overlay => {
            overlay.addEventListener('click', e => {
                if (e.target === overlay) overlay.classList.remove('open');
            });
        });

        /* ─── Mobile Sidebar ─── */
        const sidebar = document.getElementById('sidebar');
        document.getElementById('mobileMenuBtn')?.addEventListener('click', () => {
            sidebar.classList.toggle('open');
        });

        /* ─── Export CSV ─── */
        document.getElementById('exportCsvBtn').addEventListener('click', () => {
            const table = document.getElementById('productTable');
            const rows  = table.querySelectorAll('tr');
            const csv   = [];

            rows.forEach(row => {
                const cells = row.querySelectorAll('th, td');
                const line  = [];
                cells.forEach((cell, i) => {
                    if (i === cells.length - 1 && row.closest('tbody')) return; // skip actions col
                    let text = cell.innerText.replace(/\n/g, ' ').trim();
                    line.push('"' + text.replace(/"/g, '""') + '"');
                });
                if (line.length > 1) csv.push(line.join(','));
            });

            const blob = new Blob([csv.join('\n')], { type: 'text/csv;charset=utf-8;' });
            const url  = URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href  = url;
            link.download = 'inventory_export.csv';
            link.click();
            URL.revokeObjectURL(url);
            showToast('CSV exported!', 'success');
        });
    });
    </script>
</body>
</html>