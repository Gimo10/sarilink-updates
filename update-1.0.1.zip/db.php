<?php
// DB login ay nasa config.php (hindi ito ino-overwrite ng System Update)
$__cfg = require __DIR__ . '/config.php';
$host = $__cfg['db_host'];
$user = $__cfg['db_user'];
$pass = $__cfg['db_pass'];
$db   = $__cfg['db_name'];

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// ── Make sure `sales.payment_mode` exists (cash / epay). Safe to run every
// request: it only ALTERs the table the first time.
$__pm = $conn->query("SHOW COLUMNS FROM `sales` LIKE 'payment_mode'");
if ($__pm && $__pm->num_rows === 0) {
    $conn->query("ALTER TABLE `sales` ADD COLUMN `payment_mode` varchar(10) NOT NULL DEFAULT 'cash' AFTER `original_price`");
}
if ($__pm) $__pm->free();

// ── Shared stock/batch helpers ──────────────────────────────────────────
// `products.stock` is only a CACHED total. The real source of truth is the
// sum of `product_batches.quantity` for that product. Any code path that
// changes how much of a product exists (delivery, sale, pull-out, manual
// batch adjustment) MUST update `product_batches` and then call
// sync_product_totals() — never touch `products.stock` directly. Otherwise
// the next delivery (which calls sync_product_totals() to add its new
// batch) will recompute stock from the stale batch rows and silently wipe
// out whatever sales/pull-outs happened in between.

// Recompute a product's cached stock + nearest expiry from its
// product_batches rows. Call this after ANY insert/update/delete that
// touches product_batches.
function sync_product_totals($conn, $productId) {
    $stmt = $conn->prepare(
        "SELECT COALESCE(SUM(quantity), 0) AS total_stock,
                MIN(CASE WHEN quantity > 0 THEN expiry_date END) AS nearest_expiry
         FROM product_batches WHERE product_id = ?"
    );
    $stmt->bind_param("i", $productId);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    $upd = $conn->prepare("UPDATE products SET stock = ?, expiry_date = ? WHERE id = ?");
    $upd->bind_param("isi", $row['total_stock'], $row['nearest_expiry'], $productId);
    $upd->execute();
    $upd->close();
}

// Deduct `$qtyToDeduct` units of a product from its product_batches rows,
// FEFO order (soonest expiry first, no-expiry batches last, oldest
// received first as tiebreaker — same order used by the "Manage Batches"
// list), then resyncs products.stock from the batches. Use this for BOTH
// sales and pull-outs instead of decrementing products.stock directly, so
// the batch quantities always reflect what's actually left.
function deduct_stock_fefo($conn, $productId, $qtyToDeduct) {
    $qtyToDeduct = (int) $qtyToDeduct;
    if ($qtyToDeduct <= 0) return;

    $stmt = $conn->prepare(
        "SELECT id, quantity FROM product_batches
         WHERE product_id = ? AND quantity > 0
         ORDER BY (expiry_date IS NULL), expiry_date ASC, received_date ASC
         FOR UPDATE"
    );
    $stmt->bind_param("i", $productId);
    $stmt->execute();
    $batches = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    $remaining = $qtyToDeduct;
    $upd = $conn->prepare("UPDATE product_batches SET quantity = quantity - ? WHERE id = ?");
    foreach ($batches as $batch) {
        if ($remaining <= 0) break;
        $take = min($remaining, (int) $batch['quantity']);
        if ($take <= 0) continue;
        $upd->bind_param("ii", $take, $batch['id']);
        $upd->execute();
        $remaining -= $take;
    }
    $upd->close();
    // If $remaining > 0 here, the batches (already) didn't add up to the
    // requested quantity — e.g. leftover bad data from before this fix.
    // Nothing more to subtract; sync below will reflect the true total.

    sync_product_totals($conn, $productId);
}
?>