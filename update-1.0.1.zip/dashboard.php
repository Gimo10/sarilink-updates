<?php
session_start();
include 'db.php';
include 'auth.php';
require_login();

// ── AJAX: the client-side password check told us it was correct.
//    Mark the Dashboard as unlocked for the rest of this session so
//    pagination / filtering / refreshing this page won't ask again.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['verify_dashboard'])) {
    dashboard_verify();
    echo 'ok';
    exit;
}

$dashboardAlreadyVerified = dashboard_is_verified();

date_default_timezone_set('Asia/Manila');
if (isset($conn)) $conn->query("SET time_zone = '+08:00'");

$filter      = $_GET['filter'] ?? 'all';
$startDate   = $_GET['start_date'] ?? '';
$endDate     = $_GET['end_date']   ?? '';
$filterTitle = 'All Time';
$dateFilterClause = '';

switch ($filter) {
    case 'today':  $dateFilterClause = "DATE(sale_date) = CURDATE()"; $filterTitle = 'Today'; break;
    case 'week':   $dateFilterClause = "sale_date >= DATE_SUB(NOW(), INTERVAL 1 WEEK)"; $filterTitle = 'Last 7 Days'; break;
    case 'month':  $dateFilterClause = "sale_date >= DATE_SUB(NOW(), INTERVAL 1 MONTH)"; $filterTitle = 'Last 30 Days'; break;
    case 'year':   $dateFilterClause = "sale_date >= DATE_SUB(NOW(), INTERVAL 1 YEAR)"; $filterTitle = 'Last 365 Days'; break;
    case 'custom':
        if (!empty($startDate) && !empty($endDate)) {
            $dateFilterClause = "DATE(sale_date) BETWEEN '$startDate' AND '$endDate'";
            $filterTitle = date('M d, Y', strtotime($startDate)) . ' – ' . date('M d, Y', strtotime($endDate));
        }
        break;
}

$todFilter = $_GET['time_of_day_filter'] ?? 'all';
$todClause = '';
$todTitle  = 'All Day';
switch ($todFilter) {
    case 'morning':   $todClause = "HOUR(sale_date) >= 5 AND HOUR(sale_date) < 12";  $todTitle = 'Morning'; break;
    case 'afternoon': $todClause = "HOUR(sale_date) >= 12 AND HOUR(sale_date) < 18"; $todTitle = 'Afternoon'; break;
    case 'evening':   $todClause = "NOT (HOUR(sale_date) >= 5 AND HOUR(sale_date) < 18)"; $todTitle = 'Evening'; break;
}

$where = [];
if ($dateFilterClause) $where[] = $dateFilterClause;
if ($todClause)        $where[] = $todClause;
$W = $where ? 'WHERE ' . implode(' AND ', $where) : '';

// Stats
$grandTotal        = $conn->query("SELECT SUM(total_price) AS v FROM sales")->fetch_assoc()['v'] ?? 0;
$fs                = $conn->query("SELECT COUNT(*) AS txn, SUM(total_price) AS sales, AVG(total_price) AS avg FROM sales $W")->fetch_assoc();
$totalDiscountAvailed = $conn->query("SELECT SUM(original_price - total_price) AS v FROM sales $W " . ($W ? 'AND' : 'WHERE') . " is_discounted = 1")->fetch_assoc()['v'] ?? 0;
$totalTransactions = $fs['txn']   ?? 0;
$totalSales        = $fs['sales'] ?? 0;
$avgTransaction    = $fs['avg']   ?? 0;

// Total per mode of payment (Cash / E-Pay) — follows the same date & time filters
$payTotals = ['cash'=>['total'=>0,'txn'=>0], 'epay'=>['total'=>0,'txn'=>0]];
$payQ = $conn->query("SELECT IF(payment_mode = 'epay', 'epay', 'cash') AS pm, SUM(total_price) AS t, COUNT(*) AS c FROM sales $W GROUP BY pm");
if ($payQ) while ($r = $payQ->fetch_assoc()) $payTotals[$r['pm']] = ['total'=>(float)$r['t'], 'txn'=>(int)$r['c']];

// Profit (actual tubo): total_price - (cost_price * quantity) for sales with known product cost
$profitQ = $conn->query("
    SELECT SUM(s.total_price - (p.cost_price * s.quantity)) AS actual_profit
    FROM sales s
    INNER JOIN products p ON s.product_id = p.id
    WHERE p.cost_price > 0
    " . ($W ? str_replace('WHERE', 'AND', $W) : '') . "
");
$actualProfit = $profitQ->fetch_assoc()['actual_profit'] ?? 0;

// Today's profit
$todayProfitQ = $conn->query("
    SELECT SUM(s.total_price - (p.cost_price * s.quantity)) AS v
    FROM sales s
    INNER JOIN products p ON s.product_id = p.id
    WHERE p.cost_price > 0 AND DATE(s.sale_date) = CURDATE()
");
$todayProfit = $todayProfitQ->fetch_assoc()['v'] ?? 0;

// Time of day
$todQ = $conn->query("SELECT CASE WHEN HOUR(sale_date)>=5 AND HOUR(sale_date)<12 THEN 'Morning' WHEN HOUR(sale_date)>=12 AND HOUR(sale_date)<18 THEN 'Afternoon' ELSE 'Evening' END AS p, SUM(total_price) AS s FROM sales " . ($dateFilterClause ? "WHERE $dateFilterClause" : "") . " GROUP BY p");
$tod = ['Morning'=>0,'Afternoon'=>0,'Evening'=>0];
if ($todQ) while ($r = $todQ->fetch_assoc()) $tod[$r['p']] = $r['s'];
$todTotal = array_sum($tod) ?: 1;
$morPct = round($tod['Morning']   / $todTotal * 100);
$aftPct = round($tod['Afternoon'] / $todTotal * 100);
$evePct = round($tod['Evening']   / $todTotal * 100);

// Last 30 days chart
$chartQ = $conn->query("SELECT DATE(sale_date) AS day, SUM(total_price) AS total, COUNT(*) AS txn FROM sales WHERE sale_date >= DATE_SUB(NOW(), INTERVAL 30 DAY) GROUP BY DATE(sale_date) ORDER BY day ASC");
$chartMap = [];
if ($chartQ) while ($r = $chartQ->fetch_assoc()) $chartMap[$r['day']] = $r;
$chartDays = [];
for ($i = 29; $i >= 0; $i--) {
    $d = date('Y-m-d', strtotime("-$i days"));
    $chartDays[] = ['date'=>$d,'label'=>date('M d',strtotime($d)),'short'=>date('d',strtotime($d)),'total'=>$chartMap[$d]['total']??0,'txn'=>$chartMap[$d]['txn']??0];
}
$chartJson = json_encode($chartDays);

// Pagination
$limit        = 10;
$page         = max(1, (int)($_GET['page'] ?? 1));
$offset       = ($page - 1) * $limit;
$totalRecords = $conn->query("SELECT COUNT(*) AS c FROM sales $W")->fetch_assoc()['c'];
$totalPages   = ceil($totalRecords / $limit);

$salesR = $conn->query("SELECT s.id, COALESCE(s.product_name,p.name) AS name, s.quantity, s.total_price, s.sale_date, s.is_manual, s.cashier, s.is_discounted, s.original_price, s.payment_mode, p.cost_price FROM sales s LEFT JOIN products p ON s.product_id=p.id $W ORDER BY s.sale_date DESC LIMIT $limit OFFSET $offset");
$salesData = [];
while ($r = $salesR->fetch_assoc()) $salesData[] = $r;

$pdfR = $conn->query("SELECT s.id, COALESCE(s.product_name,p.name) AS name, s.quantity, s.total_price, s.sale_date, s.is_manual, s.cashier, s.is_discounted, s.original_price, s.payment_mode, COALESCE(p.cost_price,0) AS cost_price FROM sales s LEFT JOIN products p ON s.product_id=p.id $W ORDER BY s.sale_date DESC");
$pdfRows = [];
$pdfTotalProfit = 0;
if ($pdfR) {
    while ($r = $pdfR->fetch_assoc()) {
        $cp = floatval($r['cost_price']);
        $r['tubo'] = ($cp > 0 && empty($r['is_manual']))
            ? floatval($r['total_price']) - ($cp * intval($r['quantity']))
            : null;
        if ($r['tubo'] !== null) $pdfTotalProfit += $r['tubo'];
        $pdfRows[] = $r;
    }
}

// Per-product tubo breakdown (for tubo card)
$tuboBreakQ = $conn->query("
    SELECT COALESCE(s.product_name, p.name) AS nm,
           SUM(s.quantity) AS qty,
           SUM(s.total_price) AS revenue,
           p.cost_price,
           SUM(s.total_price - (p.cost_price * s.quantity)) AS tubo
    FROM sales s
    INNER JOIN products p ON s.product_id = p.id
    WHERE p.cost_price > 0
    " . ($W ? str_replace('WHERE', 'AND', $W) : '') . "
    GROUP BY nm, p.cost_price
    ORDER BY tubo DESC
    LIMIT 15
");
$tuboBreakdown = [];
if ($tuboBreakQ) while ($r = $tuboBreakQ->fetch_assoc()) $tuboBreakdown[] = $r;

// Avg tubo per transaction
$avgTuboQ = $conn->query("
    SELECT AVG(s.total_price - (p.cost_price * s.quantity)) AS avg_tubo
    FROM sales s
    INNER JOIN products p ON s.product_id = p.id
    WHERE p.cost_price > 0
    " . ($W ? str_replace('WHERE', 'AND', $W) : '') . "
");
$avgTubo = $avgTuboQ->fetch_assoc()['avg_tubo'] ?? 0;

// Top products
$tpQ = $conn->query("SELECT COALESCE(s.product_name,p.name) AS nm, SUM(s.quantity) AS qty, COUNT(*) AS txn, SUM(s.total_price) AS rev FROM sales s LEFT JOIN products p ON s.product_id=p.id $W GROUP BY nm ORDER BY qty DESC LIMIT 10");
$topProducts = [];
while ($r = $tpQ->fetch_assoc()) $topProducts[] = $r;

function pUrl($n) { $p=$_GET; $p['page']=$n; return '?'.http_build_query($p); }
function todUrl($v) { $p=$_GET; unset($p['page']); $p['time_of_day_filter']=$v; return '?'.http_build_query($p); }

$deleteSuccess = isset($_GET['delete_success']);
$deleteCount   = $_GET['count']   ?? 0;
$deleteMonth   = $_GET['month']   ?? '';
$deleteError   = isset($_GET['delete_error']);
$errorMessage  = $_GET['message'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Sales Dashboard — Sari-Link</title>
<link href="assets/css/fonts.css" rel="stylesheet">
<link href="assets/css/fontawesome.min.css" rel="stylesheet">
<script src="assets/js/jspdf.umd.min.js"></script>
<script src="assets/js/jspdf.plugin.autotable.min.js"></script>
<link rel="shortcut icon" href="Sari-Link.ico" type="image/x-icon">
<style>
:root{
    --c-bg:#eef2f8;--c-surface:#ffffff;--c-surface-2:#f6f8fb;
    --c-border:#e2e8f2;--c-border-soft:#edf1f7;
    --c-primary:#2563eb;--c-primary-dk:#1e40af;--c-primary-lt:#dbeafe;--c-primary-hv:#1d4ed8;
    --c-success:#059669;--c-success-lt:#d1fae5;
    --c-warning:#d97706;--c-warning-lt:#fef3c7;
    --c-danger:#dc2626;--c-danger-lt:#fee2e2;
    --c-purple:#7c3aed;--c-purple-lt:#ede9fe;
    --c-text:#0f172a;--c-muted:#57647c;--c-faint:#8695ab;
    --r-sm:8px;--r-md:12px;--r-lg:18px;--r-xl:24px;
    --sh-xs:0 1px 2px rgba(15,23,42,.05);
    --sh-sm:0 2px 6px rgba(15,23,42,.06),0 1px 2px rgba(15,23,42,.04);
    --sh-md:0 8px 24px rgba(15,23,42,.08),0 2px 6px rgba(15,23,42,.04);
    --sh-lg:0 20px 48px rgba(15,23,42,.14),0 4px 12px rgba(15,23,42,.06);
    --font:'DM Sans',sans-serif;--disp:'Playfair Display',serif;
    --t:180ms ease;--sw:278px;
}
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box;}
body{font-family:var(--font);background:var(--c-bg);color:var(--c-text);line-height:1.6;min-height:100vh;display:flex;}
a{text-decoration:none;color:inherit;}
button{font-family:inherit;cursor:pointer;}
input,select{font-family:inherit;}
::-webkit-scrollbar{width:5px;height:5px;}
::-webkit-scrollbar-thumb{background:var(--c-border);border-radius:99px;}

/* ═══ SIDEBAR ════════════════════════════════════════════ */
.sidebar{width:var(--sw);background:var(--c-surface);border-right:1px solid var(--c-border);height:100vh;position:fixed;left:0;top:0;display:flex;flex-direction:column;box-shadow:var(--sh-xs);overflow-y:auto;z-index:100;}
.sb-top{padding:22px 22px 18px;border-bottom:1px solid var(--c-border);}
.logo-wrap{display:flex;align-items:center;gap:11px;margin-bottom:16px;}
.logo-mark{width:42px;height:42px;background:linear-gradient(135deg,#eef4ff,#dce9fb);border-radius:var(--r-md);display:flex;align-items:center;justify-content:center;color:#fff;font-size:16px;flex-shrink:0;padding:7px;box-shadow:inset 0 0 0 1px rgba(37,99,235,.10);}
.logo-mark img{width:100%;height:100%;object-fit:contain;}
.logo-name{font-family:var(--disp);font-size:20px;line-height:1.15;}
.logo-name span{color:var(--c-primary);}
.logo-sub{font-size:11px;color:var(--c-muted);}
.grand-card{background:linear-gradient(135deg,var(--c-primary),#1d4ed8);border-radius:var(--r-lg);padding:18px 20px;color:#fff;box-shadow:0 8px 20px rgba(37,99,235,.25);}
.gc-label{font-size:10.5px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;opacity:.75;margin-bottom:3px;}
.gc-val{font-size:24px;line-height:1.1;}
.sb-body{padding:18px 22px;flex:1;display:flex;flex-direction:column;gap:40px;}
.sb-sec-title{font-size:10.5px;font-weight:700;color:var(--c-muted);text-transform:uppercase;letter-spacing:.07em;margin-bottom:8px;}
.stat-pill{display:flex;align-items:center;gap:11px;background:var(--c-surface-2);border:1px solid var(--c-border-soft);border-radius:var(--r-md);padding:11px 13px;transition:box-shadow var(--t),transform var(--t);}
.stat-pill:hover{box-shadow:var(--sh-sm);transform:translateY(-1px);}
.stat-pill+.stat-pill{margin-top:7px;}
.profit-grid{display:grid;grid-template-columns:1fr 1fr;gap:7px;}
.profit-grid .stat-pill{margin-top:0;}
.spi{width:36px;height:36px;border-radius:var(--r-md);display:flex;align-items:center;justify-content:center;color:#fff;font-size:14px;flex-shrink:0;}
.spi-green{background:linear-gradient(135deg,#10b981,#059669);}
.spi-blue{background:linear-gradient(135deg,#3b82f6,#1d4ed8);}
.spi-purple{background:linear-gradient(135deg,#8b5cf6,#7c3aed);}
.spi-amber{background:linear-gradient(135deg,#f59e0b,#d97706);}
.spi-teal{background:linear-gradient(135deg,#14b8a6,#0d9488);}
.sp-val{font-size:16px;font-weight:700;color:var(--c-text);line-height:1.1;}
.sp-lbl{font-size:11px;color:var(--c-muted);}
/* Cash / E-Pay toggle card */
.pay-toggle{cursor:pointer;user-select:none;position:relative;}
.pay-toggle:active{transform:scale(.98);}
.pay-toggle:focus-visible{outline:2px solid var(--c-primary);outline-offset:2px;}
.pay-toggle .pay-swap{margin-left:auto;font-size:12px;color:var(--c-faint);transition:transform .35s ease;}
.pay-toggle.epay .pay-swap{transform:rotate(180deg);}
.pay-toggle .sp-lbl small{color:var(--c-faint);}
.tod-row{display:flex;align-items:center;gap:9px;}
.tod-row+.tod-row{margin-top:9px;}
.tod-icon{width:28px;height:28px;border-radius:var(--r-sm);display:flex;align-items:center;justify-content:center;font-size:12px;flex-shrink:0;}
.tod-icon.mor{background:var(--c-warning-lt);color:var(--c-warning);}
.tod-icon.aft{background:#cffafe;color:#0891b2;}
.tod-icon.eve{background:var(--c-purple-lt);color:var(--c-purple);}
.tod-lbl{font-size:11px;font-weight:600;color:var(--c-muted);width:64px;}
.tod-track{flex:1;height:8px;background:var(--c-border);border-radius:99px;overflow:hidden;}
.tod-fill{height:100%;border-radius:99px;transition:width .6s ease;}
.tod-fill.mor{background:linear-gradient(to right,#f59e0b,#d97706);}
.tod-fill.aft{background:linear-gradient(to right,#22d3ee,#0891b2);}
.tod-fill.eve{background:linear-gradient(to right,#8b5cf6,#6d28d9);}
.tod-pct{font-size:10px;font-weight:700;color:var(--c-muted);width:28px;text-align:right;}
.tp-mini{display:flex;align-items:center;gap:8px;padding:6px 0;border-bottom:1px solid var(--c-border-soft);}
.tp-mini:last-child{border-bottom:none;}
.tp-mini-rank{width:20px;height:20px;border-radius:50%;color:#fff;display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:800;flex-shrink:0;}
.tp-mini-name{flex:1;font-size:12px;font-weight:600;color:var(--c-text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:0;}
.tp-mini-rev{font-size:11px;font-weight:700;color:var(--c-success);flex-shrink:0;}
.sb-footer{padding:14px 20px 18px;border-top:1px solid var(--c-border);display:flex;flex-direction:column;gap:8px;margin-top:auto;}
.sb-btn{display:flex;align-items:center;gap:9px;padding:9px 13px;border-radius:var(--r-md);font-size:13px;font-weight:600;border:1px solid var(--c-border);background:var(--c-surface-2);color:var(--c-muted);cursor:pointer;transition:all var(--t);}
.sb-btn:hover{background:var(--c-primary-lt);color:var(--c-primary);border-color:var(--c-primary);}
.sb-btn.danger:hover{background:var(--c-danger-lt);color:var(--c-danger);border-color:var(--c-danger);}

/* ═══ MAIN ════════════════════════════════════════════════ */
.main{margin-left:var(--sw);width:calc(100% - var(--sw));display:flex;flex-direction:column;min-height:100vh;}
.topbar{background:var(--c-surface);border-bottom:1px solid var(--c-border);height:72px;padding:0 28px;display:flex;align-items:center;justify-content:space-between;gap:12px;position:sticky;top:0;z-index:50;box-shadow:var(--sh-xs);}
.tb-left{display:flex;align-items:center;gap:10px;}
.tb-title{font-family:var(--disp);font-size:20px;}
.tb-pill{display:inline-flex;align-items:center;gap:5px;background:var(--c-danger-lt);color:var(--c-danger);border:1px solid #fca5a5;border-radius:99px;font-size:11px;font-weight:700;padding:4px 11px;}
.tb-right{display:flex;align-items:center;gap:8px;}
.live-clock{display:flex;align-items:center;gap:7px;background:var(--c-surface-2);border:1px solid var(--c-border);border-radius:var(--r-md);padding:6px 12px;font-size:13px;font-weight:700;color:var(--c-text);white-space:nowrap;}
.live-clock i{color:var(--c-primary);font-size:12px;}
.clock-date{font-size:10px;font-weight:500;color:var(--c-muted);border-left:1px solid var(--c-border);padding-left:7px;margin-left:3px;}
.page-body{padding:24px 28px;flex:1;display:flex;flex-direction:column;gap:18px;}

/* Buttons */
.btn{display:inline-flex;align-items:center;justify-content:center;gap:6px;border:none;border-radius:var(--r-md);font-family:inherit;font-weight:600;cursor:pointer;transition:all var(--t);font-size:13px;}
.btn-sm{padding:6px 12px;font-size:12px;}
.btn-md{padding:8px 15px;}
.btn-primary{background:var(--c-primary);color:#fff;} .btn-primary:hover{background:var(--c-primary-hv);}
.btn-success{background:var(--c-success);color:#fff;} .btn-success:hover{background:#047857;}
.btn-warning{background:var(--c-warning);color:#fff;} .btn-warning:hover{background:#b45309;}
.btn-danger{background:var(--c-danger);color:#fff;}   .btn-danger:hover{background:#b91c1c;}
.btn-ghost{background:var(--c-surface-2);color:var(--c-muted);border:1px solid var(--c-border);}
.btn-ghost:hover{background:var(--c-primary-lt);color:var(--c-primary);border-color:var(--c-primary);}

/* Panel */
.panel{background:var(--c-surface);border:1px solid var(--c-border);border-radius:var(--r-lg);box-shadow:var(--sh-xs);overflow:hidden;}
.panel-head{padding:16px 22px 15px;border-bottom:1px solid var(--c-border-soft);display:flex;align-items:center;gap:11px;flex-wrap:wrap;}
.panel-icon{width:34px;height:34px;border-radius:var(--r-md);display:flex;align-items:center;justify-content:center;color:#fff;font-size:13px;flex-shrink:0;}
.pi-blue{background:linear-gradient(135deg,#3b82f6,#1d4ed8);}
.pi-green{background:linear-gradient(135deg,#10b981,#059669);}
.pi-amber{background:linear-gradient(135deg,#f59e0b,#d97706);}
.pi-slate{background:linear-gradient(135deg,#64748b,#475569);}
.panel-title{font-size:14px;font-weight:700;color:var(--c-text);}
.panel-acts{margin-left:auto;display:flex;gap:7px;flex-wrap:wrap;align-items:center;}

/* ═══ CHART PANEL ════════════════════════════════════════ */
.chart-panel{background:var(--c-surface);border:1px solid var(--c-border);border-radius:var(--r-lg);box-shadow:var(--sh-xs);overflow:hidden;}
.chart-head{padding:13px 20px;border-bottom:1px solid var(--c-border-soft);display:flex;align-items:center;gap:10px;}
.chart-head-left{display:flex;align-items:center;gap:10px;flex:1;min-width:0;}
.chart-head-right{display:flex;align-items:center;gap:14px;flex-shrink:0;}
.chart-meta{display:flex;align-items:center;gap:16px;}
.chart-meta-item{font-size:12px;color:var(--c-muted);}
.chart-meta-item strong{color:var(--c-text);font-weight:700;}
.chart-chevron{font-size:12px;color:var(--c-muted);transition:transform .28s ease;}
.chart-chevron.open{transform:rotate(180deg);}
.chart-body{overflow:hidden;}
.chart-body.open{max-height:520px;}
.chart-inner{padding:20px 20px 14px;}
#revenueChart{display:block;width:100%;height:220px;cursor:crosshair;}
.chart-x-labels{display:flex;gap:0;margin-top:5px;padding:0 2px;}
.chart-x-label{flex:1;text-align:center;font-size:9px;color:var(--c-faint);font-weight:600;white-space:nowrap;overflow:hidden;}
.chart-legend{display:flex;align-items:center;gap:16px;margin-top:12px;padding-top:12px;border-top:1px solid var(--c-border-soft);}
.legend-dot{width:8px;height:8px;border-radius:50%;flex-shrink:0;}
.legend-item{display:flex;align-items:center;gap:6px;font-size:12px;color:var(--c-muted);}
.chart-tooltip{position:fixed;background:var(--c-text);color:#fff;font-size:11px;font-weight:600;padding:7px 11px;border-radius:var(--r-md);pointer-events:none;opacity:0;transition:opacity .12s;white-space:nowrap;z-index:9999;box-shadow:var(--sh-md);line-height:1.7;}

/* Filter dropdowns */
.filter-dd{position:relative;}
.fdd-toggle{display:inline-flex;align-items:center;gap:6px;background:var(--c-surface-2);border:1px solid var(--c-border);border-radius:var(--r-md);padding:7px 12px;font-size:13px;font-weight:600;color:var(--c-text);cursor:pointer;transition:all var(--t);}
.fdd-toggle:hover{background:var(--c-primary-lt);color:var(--c-primary);border-color:var(--c-primary);}
.fdd-toggle .fv{color:var(--c-primary);}
.dd-menu{display:none;position:absolute;top:calc(100% + 4px);left:0;background:var(--c-surface);border:1px solid var(--c-border);border-radius:var(--r-lg);box-shadow:var(--sh-md);padding:6px;z-index:300;min-width:22px;}
.dd-menu.show{display:block;}
.dd-item{display:flex;align-items:center;gap:9px;padding:8px 10px;border-radius:var(--r-md);font-size:13px;color:var(--c-text);cursor:pointer;transition:background var(--t);}
.dd-item:hover{background:var(--c-surface-2);}
.dd-item.active{background:var(--c-primary-lt);color:var(--c-primary);font-weight:700;}
.dd-div{height:1px;background:var(--c-border-soft);margin:4px 0;}
.cform{display:none;flex-direction:column;gap:8px;padding:8px 10px 10px;border-top:1px solid var(--c-border-soft);margin-top:4px;}
.cform.show{display:flex;}
.cform input[type="date"]{padding:7px 10px;border:1px solid var(--c-border);border-radius:var(--r-md);font-size:13px;color:var(--c-text);background:var(--c-surface-2);width:100%;}
.cform input[type="date"]:focus{outline:none;border-color:var(--c-primary);box-shadow:0 0 0 3px rgba(37,99,235,.1);}
.cdate-row{display:flex;align-items:center;gap:6px;font-size:12px;color:var(--c-muted);}
.cdate-row input{flex:1;}

/* Table */
.table-wrap{overflow-x:auto;}
table{width:100%;border-collapse:collapse;}
thead th{background:var(--c-surface-2);color:var(--c-muted);font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;padding:12px 16px;border-bottom:1px solid var(--c-border);white-space:nowrap;text-align:left;}
tbody td{padding:13px 16px;border-bottom:1px solid var(--c-border-soft);font-size:13.5px;}
tbody tr:last-child td{border-bottom:none;}
tbody tr:hover{background:var(--c-surface-2);}
.td-name{font-weight:600;color:var(--c-text);}
.td-manual{font-size:9.5px;font-weight:700;background:var(--c-warning-lt);color:var(--c-warning);border:1px solid #fde68a;border-radius:4px;padding:1px 5px;margin-left:6px;vertical-align:middle;}
.td-pay{font-size:9.5px;font-weight:700;border-radius:4px;padding:1px 5px;margin-left:6px;vertical-align:middle;white-space:nowrap;}
.td-pay-cash{background:#e0f2fe;color:#0369a1;border:1px solid #7dd3fc;}
.td-pay-epay{background:#ede9fe;color:#6d28d9;border:1px solid #c4b5fd;}
.td-discounted{font-size:9.5px;font-weight:700;background:var(--c-success-lt);color:var(--c-success);border:1px solid #6ee7b7;border-radius:4px;padding:1px 5px;margin-left:6px;vertical-align:middle;}
.qty-badge{display:inline-block;background:var(--c-primary-lt);color:var(--c-primary);border-radius:99px;padding:2px 10px;font-size:12px;font-weight:700;}
.td-price{font-weight:700;color:var(--c-success);}
.td-date{color:var(--c-muted);font-size:12.5px;white-space:nowrap;}
.empty-state{text-align:center;padding:52px 20px;}
.empty-icon{width:60px;height:60px;background:var(--c-surface-2);border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 14px;font-size:22px;color:var(--c-faint);}
.empty-state h3{font-size:15px;color:var(--c-text);margin-bottom:4px;}
.empty-state p{font-size:13px;color:var(--c-muted);}

/* Pagination */
.pagination{display:flex;justify-content:center;gap:4px;margin-top:18px;}
.pagination a,.pagination strong{display:inline-flex;align-items:center;justify-content:center;min-width:34px;height:34px;padding:0 6px;border-radius:var(--r-md);font-size:13px;text-decoration:none;transition:all var(--t);}
.pagination a{background:var(--c-surface-2);color:var(--c-muted);border:1px solid var(--c-border);}
.pagination a:hover{background:var(--c-primary-lt);color:var(--c-primary);border-color:var(--c-primary);}
.pagination strong{background:var(--c-primary);color:#fff;font-weight:700;border:1px solid var(--c-primary);}
.pagination .ell{display:inline-flex;align-items:center;justify-content:center;min-width:34px;height:34px;font-size:13px;color:var(--c-muted);}

/* Modals */
.modal-overlay{display:none;position:fixed;inset:0;background:rgba(15,23,42,.42);backdrop-filter:blur(4px);z-index:500;justify-content:center;align-items:center;}
.modal-overlay.open{display:flex;}
.modal-box{background:var(--c-surface);border-radius:var(--r-xl);width:700px;max-width:95%;max-height:88vh;display:flex;flex-direction:column;position:relative;box-shadow:var(--sh-lg);animation:popIn .22s ease;}
.modal-box.sm{width:480px;}
@keyframes popIn{from{opacity:0;transform:scale(.95) translateY(10px)}to{opacity:1;transform:scale(1) translateY(0)}}
.modal-head{padding:20px 24px 16px;border-bottom:1px solid var(--c-border);display:flex;align-items:center;gap:10px;}
.mhi{width:36px;height:36px;border-radius:var(--r-md);display:flex;align-items:center;justify-content:center;font-size:15px;flex-shrink:0;}
.mhi-blue{background:var(--c-primary-lt);color:var(--c-primary);}
.mhi-green{background:var(--c-success-lt);color:var(--c-success);}
.mhi-red{background:var(--c-danger-lt);color:var(--c-danger);}
.mh-title{font-family:var(--disp);font-size:19px;color:var(--c-text);}
.modal-close{position:absolute;top:14px;right:16px;background:var(--c-surface-2);border:none;width:28px;height:28px;border-radius:50%;font-size:14px;color:var(--c-muted);display:flex;align-items:center;justify-content:center;transition:all var(--t);cursor:pointer;}
.modal-close:hover{background:var(--c-danger-lt);color:var(--c-danger);}
.modal-body{padding:20px 24px 24px;overflow-y:auto;flex:1;}
.tp-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:14px;}
.tp-card{position:relative;background:var(--c-surface-2);border:1px solid var(--c-border);border-radius:var(--r-lg);padding:18px;display:flex;align-items:center;gap:13px;transition:box-shadow var(--t),transform var(--t);}
.tp-card:hover{box-shadow:var(--sh-sm);transform:translateY(-2px);}
.tp-rank{position:absolute;top:-8px;left:-8px;width:30px;height:30px;border-radius:50%;background:var(--c-primary);color:#fff;display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:800;box-shadow:var(--sh-xs);}
.tp-card:nth-child(1) .tp-rank{background:linear-gradient(135deg,#f59e0b,#d97706);}
.tp-card:nth-child(2) .tp-rank{background:linear-gradient(135deg,#64748b,#475569);}
.tp-card:nth-child(3) .tp-rank{background:linear-gradient(135deg,#b45309,#92400e);}
.tp-info{flex:1;min-width:0;}
.tp-name{font-size:14px;font-weight:700;color:var(--c-text);margin-bottom:8px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.tp-stat{font-size:12px;color:var(--c-muted);display:flex;align-items:center;gap:6px;margin-bottom:2px;}
.tp-stat i{width:14px;color:var(--c-primary);}
.tp-circle{width:70px;height:70px;background:var(--c-primary-lt);border-radius:50%;display:flex;flex-direction:column;align-items:center;justify-content:center;flex-shrink:0;}
.tp-cv{font-size:18px;font-weight:800;color:var(--c-primary);line-height:1;}
.tp-cl{font-size:10px;color:#6366f1;font-weight:600;}
.search-row{display:flex;gap:8px;margin-bottom:18px;}
.search-row input{flex:1;padding:9px 13px;border:1px solid var(--c-border);border-radius:var(--r-md);font-size:14px;color:var(--c-text);background:var(--c-surface-2);transition:border-color var(--t),box-shadow var(--t);}
.search-row input:focus{outline:none;border-color:var(--c-primary);box-shadow:0 0 0 3px rgba(37,99,235,.1);background:#fff;}
#product-search-results{border-top:1px solid var(--c-border-soft);padding-top:18px;}
.danger-info{background:var(--c-danger-lt);border-left:3px solid var(--c-danger);border-radius:0 var(--r-md) var(--r-md) 0;padding:12px 15px;color:#7f1d1d;font-size:13px;margin-bottom:18px;display:flex;align-items:flex-start;gap:9px;}
.danger-info i{color:var(--c-danger);margin-top:2px;flex-shrink:0;}
.form-group{margin-bottom:14px;}
.form-group label{display:block;font-size:11px;font-weight:700;color:var(--c-muted);text-transform:uppercase;letter-spacing:.06em;margin-bottom:5px;}
.form-group select{width:100%;padding:9px 12px;border:1px solid var(--c-border);border-radius:var(--r-md);font-size:14px;background:var(--c-surface-2);color:var(--c-text);transition:border-color var(--t);}
.form-group select:focus{outline:none;border-color:var(--c-primary);box-shadow:0 0 0 3px rgba(37,99,235,.1);}
.alert{display:flex;align-items:center;gap:10px;padding:13px 16px;border-radius:var(--r-md);font-size:13.5px;font-weight:500;animation:fadeIn .35s ease;}
@keyframes fadeIn{from{opacity:0;transform:translateY(-6px)}to{opacity:1;transform:translateY(0)}}
.alert-success{background:var(--c-success-lt);border-left:3px solid var(--c-success);color:#064e3b;}
.alert-error{background:var(--c-danger-lt);border-left:3px solid var(--c-danger);color:#7f1d1d;}
.alert i{flex-shrink:0;}

/* ═══ TUBO CARD ══════════════════════════════════════════ */
.tubo-panel{background:var(--c-surface);border:1px solid #99f6e4;border-radius:var(--r-lg);box-shadow:var(--sh-xs);overflow:hidden;}
.tubo-head{padding:13px 20px;border-bottom:1px solid #ccfbf1;display:flex;align-items:center;gap:10px;}
.tubo-head-left{display:flex;align-items:center;gap:10px;flex:1;min-width:0;}
.tubo-head-right{display:flex;align-items:center;gap:14px;flex-shrink:0;}
.tubo-meta{display:flex;align-items:center;gap:16px;}
.tubo-meta-item{font-size:12px;color:var(--c-muted);}
.tubo-meta-item strong{color:#0d9488;font-weight:700;}
.tubo-body{overflow:hidden;}
.tubo-inner{padding:20px;}
.tubo-summary-row{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-bottom:20px;}
.tubo-sum-card{background:linear-gradient(135deg,#f0fdfa,#ccfbf1);border:1px solid #99f6e4;border-radius:var(--r-lg);padding:14px 16px;text-align:center;}
.tubo-sum-label{font-size:10.5px;font-weight:700;color:#14b8a6;text-transform:uppercase;letter-spacing:.06em;margin-bottom:4px;}
.tubo-sum-val{font-size:20px;font-weight:800;color:#0d9488;line-height:1.1;}
.tubo-sum-val.danger{color:var(--c-danger);}
.tubo-breakdown-title{font-size:11px;font-weight:700;color:var(--c-muted);text-transform:uppercase;letter-spacing:.07em;margin-bottom:10px;}
.tubo-table{width:100%;border-collapse:collapse;}
.tubo-table th{background:#f0fdfa;color:#0d9488;font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;padding:8px 12px;border-bottom:1px solid #99f6e4;text-align:left;}
.tubo-table td{padding:10px 12px;border-bottom:1px solid var(--c-border-soft);font-size:13px;}
.tubo-table tbody tr:hover{background:#f0fdfa;}
.tubo-table tbody tr:last-child td{border-bottom:none;}
.tubo-no-cost{font-size:11px;color:var(--c-faint);font-style:italic;}
.pi-teal{background:linear-gradient(135deg,#14b8a6,#0d9488);}
@media(max-width:600px){.tubo-summary-row{grid-template-columns:1fr 1fr;}}

/* ═══ TAB NAV ════════════════════════════════════════════ */
.tab-nav{display:flex;align-items:center;gap:6px;background:var(--c-surface-2);border:1px solid var(--c-border);border-radius:var(--r-lg);padding:5px;}
.tab-btn{display:inline-flex;align-items:center;gap:7px;padding:8px 18px;border-radius:var(--r-md);font-size:13px;font-weight:600;color:var(--c-muted);background:transparent;border:none;cursor:pointer;transition:all var(--t);}
.tab-btn:hover{background:var(--c-surface);color:var(--c-text);}
.tab-btn.active{background:var(--c-surface);color:var(--c-primary);box-shadow:var(--sh-xs);border:1px solid var(--c-border);}
.tab-btn.active i{color:var(--c-primary);}
.tab-btn i{font-size:13px;color:var(--c-muted);}
.page-section{display:none;}
.page-section.active{display:flex;flex-direction:column;gap:16px;}

/* Responsive */
.menu-toggle{display:none;}
@media(max-width:860px){
    :root{--sw:0px;}
    .sidebar{transform:translateX(-270px);transition:transform .3s;width:270px;}
    .sidebar.open{transform:translateX(0);}
    .main{margin-left:0;width:100%;}
    .menu-toggle{display:flex!important;}
    .chart-meta{display:none;}
}
@media(max-width:600px){
    .page-body{padding:14px;}
    .topbar{padding:0 14px;}
    .clock-date{display:none;}
}
@media print{
    .sidebar,.topbar,.panel-acts,.pagination,.filter-dd,.btn{display:none!important;}
    .main{margin-left:0!important;width:100!important;}
}
</style>
</head>
<body>

<!-- ══ PASSWORD GATE MODAL ══ -->
<style>
#pwGateOverlay{
    position:fixed;inset:0;z-index:99999;
    background:rgba(15,23,42,.72);backdrop-filter:blur(8px);
    display:flex;align-items:center;justify-content:center;
}
#pwGateOverlay.hidden{display:none;}
.pw-box{
    background:#fff;border-radius:22px;padding:38px 34px 32px;
    width:380px;max-width:93%;box-shadow:0 24px 60px rgba(15,23,42,.22);
    animation:popIn .22s ease;text-align:center;
}
@keyframes popIn{from{opacity:0;transform:scale(.94) translateY(12px)}to{opacity:1;transform:scale(1) translateY(0)}}
.pw-logo{width:54px;height:54px;background:#2563eb;border-radius:14px;
    display:flex;align-items:center;justify-content:center;
    color:#fff;font-size:22px;margin:0 auto 16px;}
.pw-title{font-family:'Playfair Display',serif;font-size:21px;color:#0f172a;margin-bottom:4px;}
.pw-sub{font-size:13px;color:#64748b;margin-bottom:24px;}
.pw-field{
    width:100%;padding:12px 14px;border:2px solid #e4eaf2;border-radius:10px;
    font-size:15px;font-family:inherit;color:#0f172a;background:#f7f9fc;
    transition:border-color .18s,box-shadow .18s;text-align:center;letter-spacing:.12em;
    margin-bottom:12px;
}
.pw-field:focus{outline:none;border-color:#2563eb;box-shadow:0 0 0 3px rgba(37,99,235,.12);background:#fff;}
.pw-btn{
    width:100%;padding:12px;border:none;border-radius:10px;
    background:#2563eb;color:#fff;font-size:15px;font-weight:700;
    font-family:inherit;cursor:pointer;transition:background .18s;
}
.pw-btn:hover{background:#1d4ed8;}
.pw-err{
    font-size:12.5px;color:#dc2626;margin-top:10px;
    background:#fee2e2;border-radius:8px;padding:8px 12px;
    display:none;
}
.pw-err.show{display:block;}
.pw-box{position:relative;}
.pw-close{
    position:absolute;top:14px;right:14px;
    background:none;border:none;color:#94a3b8;
    font-size:17px;cursor:pointer;width:30px;height:30px;
    border-radius:50%;display:flex;align-items:center;justify-content:center;
    transition:background .18s,color .18s;
}
.pw-close:hover{background:#f1f5f9;color:#0f172a;}
.pw-field-wrap{position:relative;width:100%;margin-bottom:12px;}
.pw-field-wrap .pw-field{margin-bottom:0;padding-right:44px;}
.pw-eye{
    position:absolute;right:13px;top:50%;transform:translateY(-50%);
    background:none;border:none;color:#94a3b8;font-size:15px;
    cursor:pointer;padding:4px;transition:color .18s;
}
.pw-eye:hover{color:#2563eb;}
</style>

<div id="pwGateOverlay" class="<?= $dashboardAlreadyVerified ? 'hidden' : '' ?>">
    <div class="pw-box">
        <button class="pw-close" onclick="window.location.href='index.php'" title="Back"><i class="fas fa-times"></i></button>
        <div class="pw-logo"><i class="fas fa-lock"></i></div>
        <div class="pw-title">Dashboard Access</div>
        <div class="pw-sub">Enter password to continue</div>
        <div class="pw-field-wrap">
            <input type="password" id="pwInput" class="pw-field" placeholder="••••••••" autocomplete="off" maxlength="40">
            <button class="pw-eye" type="button" onclick="togglePw()" title="Show/Hide Password"><i class="fas fa-eye" id="eyeIcon"></i></button>
        </div>
        <button class="pw-btn" onclick="checkPassword()"><i class="fas fa-unlock-alt"></i> &nbsp;Enter</button>
        <div class="pw-err" id="pwErr"><i class="fas fa-exclamation-circle"></i> Incorrect password. Try again.</div>
    </div>
</div>

<script>
(function(){
    // Focus password field immediately (only if the gate is actually showing)
    document.addEventListener('DOMContentLoaded', function(){
        var f = document.getElementById('pwInput');
        var overlay = document.getElementById('pwGateOverlay');
        if(f && overlay && !overlay.classList.contains('hidden')) f.focus();
    });

    // Allow Enter key to submit
    document.addEventListener('keydown', function(e){
        var overlay = document.getElementById('pwGateOverlay');
        if(e.key === 'Enter' && overlay && !overlay.classList.contains('hidden')){
            checkPassword();
        }
    });
})();

function togglePw(){
    var input = document.getElementById('pwInput');
    var icon  = document.getElementById('eyeIcon');
    if(input.type === 'password'){
        input.type = 'text';
        icon.classList.replace('fa-eye','fa-eye-slash');
    } else {
        input.type = 'password';
        icon.classList.replace('fa-eye-slash','fa-eye');
    }
}

function checkPassword(){
    var val = document.getElementById('pwInput').value;
    var err = document.getElementById('pwErr');

    if(val === 'assenuj@azodnem29'){
        // Real password — dismiss modal and show real dashboard
        document.getElementById('pwGateOverlay').classList.add('hidden');
        document.body.style.overflow = '';
        err.classList.remove('show');
        // Tell the server this session is unlocked, so pagination/filtering/
        // refreshing this page won't ask for the password again. Leaving the
        // Dashboard for any other page still invalidates it (see auth.php).
        fetch(window.location.pathname, {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: 'verify_dashboard=1'
        }).catch(function(){ /* non-fatal: worst case, it asks again next load */ });
    } else if(val === 'junessa!mendoza@29'){
        // Decoy password — redirect to fake dashboard
        window.location.href = 'dashboard1.php';
    } else {
        err.classList.add('show');
        var inp = document.getElementById('pwInput');
        inp.value = '';
        inp.focus();
        // Shake animation
        var box = document.querySelector('.pw-box');
        box.style.transform = 'translateX(-6px)';
        setTimeout(function(){ box.style.transform = 'translateX(6px)'; }, 80);
        setTimeout(function(){ box.style.transform = 'translateX(-4px)'; }, 160);
        setTimeout(function(){ box.style.transform = 'translateX(0)'; }, 240);
    }
}
</script>

<aside class="sidebar" id="sidebar">
    <div class="sb-top">
        <div class="logo-wrap">
            <div class="logo-mark"><img src="assets/img/logo-mark.png" alt="Sari-Link"></div>
            <div>
                <div class="logo-name">Sari<span>-Link</span></div>
                <div class="logo-sub">Sales Dashboard</div>
            </div>
        </div>
        <div class="grand-card">
            <div class="gc-label">Grand Total Revenue</div>
            <div class="gc-val">₱<?= number_format($grandTotal,2) ?></div>
        </div>
    </div>

    <div class="sb-body">
        <div>
            <div class="sb-sec-title">Filtered · <?= htmlspecialchars($filterTitle) ?></div>
            <div class="stat-pill"><div class="spi spi-green"><i class="fas fa-peso-sign"></i></div><div><div class="sp-val">₱<?= number_format($totalSales,2) ?></div><div class="sp-lbl">Total Sales</div></div></div>
            <div class="stat-pill pay-toggle" id="payToggleCard" role="button" tabindex="0" title="Click to switch between Cash and E-Pay">
                <div class="spi spi-blue" id="payToggleIcon"><i class="fas fa-money-bill-wave" id="payToggleIconI"></i></div>
                <div style="min-width:0">
                    <div class="sp-val" id="payToggleVal">₱<?= number_format($payTotals['cash']['total'],2) ?></div>
                    <div class="sp-lbl"><span id="payToggleLbl">Total Cash</span> <small id="payToggleCnt">· <?= number_format($payTotals['cash']['txn']) ?> txn</small></div>
                </div>
                <div class="pay-swap"><i class="fas fa-rotate"></i></div>
            </div>
            <div class="stat-pill"><div class="spi spi-purple"><i class="fas fa-calendar-day"></i></div><div><div class="sp-val">₱<?= number_format($totalDiscountAvailed,2) ?></div><div class="sp-lbl">Total Discount Availed</div></div></div>
            <div class="stat-pill"><div class="spi spi-amber"><i class="fas fa-list-check"></i></div><div><div class="sp-val"><?= number_format($totalTransactions) ?></div><div class="sp-lbl">Total Transactions</div>
    </div>
</div>
        </div>

        <div>
            <div class="sb-sec-title">Sales by Time of Day</div>
            <div class="tod-row"><div class="tod-icon mor"><i class="fas fa-sun"></i></div><div class="tod-lbl">Morning</div><div class="tod-track"><div class="tod-fill mor" style="width:<?= $morPct ?>%"></div></div><div class="tod-pct"><?= $morPct ?>%</div></div>
            <div class="tod-row"><div class="tod-icon aft"><i class="fas fa-cloud-sun"></i></div><div class="tod-lbl">Afternoon</div><div class="tod-track"><div class="tod-fill aft" style="width:<?= $aftPct ?>%"></div></div><div class="tod-pct"><?= $aftPct ?>%</div></div>
            <div class="tod-row"><div class="tod-icon eve"><i class="fas fa-moon"></i></div><div class="tod-lbl">Evening</div><div class="tod-track"><div class="tod-fill eve" style="width:<?= $evePct ?>%"></div></div><div class="tod-pct"><?= $evePct ?>%</div></div>
        </div>

        <div>
            <div class="sb-sec-title" style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px;">
                <span>Top 3 Products</span>
                <button class="btn btn-ghost btn-sm" style="font-size:10px;padding:2px 8px" onclick="openModal('topProductsModal')">See All</button>
            </div>
            <?php if (empty($topProducts)): ?>
            <div style="text-align:center;padding:14px;font-size:12px;color:var(--c-muted)">No data yet</div>
            <?php else: ?>
            <?php foreach (array_slice($topProducts,0,3) as $i=>$tp): ?>
            <div class="tp-mini">
                <div class="tp-mini-rank" style="background:<?= ['#f59e0b','#64748b','#b45309','#2563eb','#7c3aed'][$i]??'var(--c-primary)' ?>"><?= $i+1 ?></div>
                <div class="tp-mini-name"><?= htmlspecialchars($tp['nm']) ?></div>
                <div class="tp-mini-rev">₱<?= number_format($tp['rev'],0) ?></div>
            </div>
            <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <div class="sb-footer">
        <a href="index.php" class="sb-btn"><i class="fas fa-arrow-left"></i> Back</a>
        <button class="sb-btn danger" onclick="openModal('dbModal')"><i class="fas fa-database"></i> Manage Database</button>
    </div>
</aside>

<div class="main">
    <header class="topbar">
        <div class="tb-left">
            <button class="btn btn-ghost btn-sm menu-toggle" onclick="toggleSidebar()"><i class="fas fa-bars"></i></button>
            <div class="tb-title">Sales Dashboard</div>
            <span class="tb-pill"><i class="fas fa-circle" style="font-size:7px"></i> Live</span>
        </div>
        <div class="tb-right">
            <div class="live-clock"><i class="fas fa-clock"></i><span id="clockTime">--:--</span><span class="clock-date" id="clockDate"></span></div>
            <div class="live-clock" title="Logged in as (<?= htmlspecialchars(current_user_role()) ?>)">
                <i class="fas fa-user-circle" style="color:var(--c-primary)"></i>
                <span><?= htmlspecialchars(current_user_display()) ?></span>
            </div>
        </div>
    </header>

    <div style="background:var(--c-surface);border-bottom:1px solid var(--c-border);padding:10px 24px;">
        <div class="tab-nav">
            <button class="tab-btn active" id="tab-history" onclick="switchTab('history')"><i class="fas fa-history"></i> History</button>
            <button class="tab-btn" id="tab-revenue" onclick="switchTab('revenue')"><i class="fas fa-chart-area"></i> Revenue</button>
            <button class="tab-btn" id="tab-tubo" onclick="switchTab('tubo')"><i class="fas fa-hand-holding-usd"></i> Profit</button>
        </div>
    </div>

    <div class="page-body">

        <?php if ($deleteSuccess): ?>
        <div class="alert alert-success"><i class="fas fa-check-circle"></i><div><strong>Done!</strong> <?= number_format($deleteCount) ?> records from <?= htmlspecialchars($deleteMonth) ?> deleted.</div></div>
        <?php endif; ?>
        <?php if ($deleteError): ?>
        <div class="alert alert-error"><i class="fas fa-exclamation-circle"></i><div><strong>Error:</strong> <?= htmlspecialchars($errorMessage) ?></div></div>
        <?php endif; ?>

        <!-- ═══ REVENUE SECTION ═══════════════════════════════ -->
        <div class="page-section" id="section-revenue">

        <div class="chart-panel">
            <div class="chart-head" id="chartHead">
                <div class="chart-head-left">
                    <div class="panel-icon pi-blue"><i class="fas fa-chart-area"></i></div>
                    <div class="panel-title">Revenue — Last 30 Days</div>
                </div>
                <div class="chart-head-right">
                    <div class="chart-meta">
                        <div class="chart-meta-item">Peak: <strong id="chartPeak">—</strong></div>
                        <div class="chart-meta-item">30-day total: <strong id="chartTotal">—</strong></div>
                    </div>
                </div>
            </div>
            <div class="chart-body open" id="chartBody"> <div class="chart-inner">
                    <canvas id="revenueChart"></canvas>
                    <div class="chart-x-labels" id="chartXLabels"></div>
                    <div class="chart-legend">
                        <div class="legend-item"><div class="legend-dot" style="background:var(--c-primary)"></div>Daily Revenue</div>
                        <div class="legend-item"><div class="legend-dot" style="background:var(--c-success)"></div>7-day avg</div>
                    </div>
                </div>
            </div>
        </div>

        </div><!-- /section-revenue -->

        <!-- ═══ TUBO SECTION ══════════════════════════════════ -->
        <div class="page-section" id="section-tubo">
        <!-- ═══ TUBO CARD ════════════════════════════════════ -->
        <div class="tubo-panel">
            <div class="tubo-head" id="tuboHead">
                <div class="tubo-head-left">
                    <div class="panel-icon pi-teal"><i class="fas fa-hand-holding-usd"></i></div>
                    <div class="panel-title" style="color:#0d9488">Profit — <?= htmlspecialchars($filterTitle) ?></div>
                </div>
                <div class="tubo-head-right">
                    <div class="tubo-meta">
                        <div class="tubo-meta-item">Filtered: <strong>₱<?= number_format($actualProfit, 2) ?></strong></div>
                        <div class="tubo-meta-item">Today: <strong>₱<?= number_format($todayProfit, 2) ?></strong></div>
                    </div>
                </div>
            </div>
            <div class="tubo-body open" id="tuboBody">
                <div class="tubo-inner">
                    <!-- Summary row -->
                    <div class="tubo-summary-row">
                        <div class="tubo-sum-card">
                            <div class="tubo-sum-label"><i class="fas fa-filter"></i> Filtered Profit</div>
                            <div class="tubo-sum-val <?= $actualProfit < 0 ? 'danger' : '' ?>">
                                <?= $actualProfit >= 0 ? '' : '-' ?>₱<?= number_format(abs($actualProfit), 2) ?>
                            </div>
                        </div>
                        <div class="tubo-sum-card">
                            <div class="tubo-sum-label"><i class="fas fa-sun"></i> Today's Profit</div>
                            <div class="tubo-sum-val <?= $todayProfit < 0 ? 'danger' : '' ?>">
                                <?= $todayProfit >= 0 ? '' : '-' ?>₱<?= number_format(abs($todayProfit), 2) ?>
                            </div>
                        </div>
                        <div class="tubo-sum-card">
                            <div class="tubo-sum-label"><i class="fas fa-chart-bar"></i> Avg Profit / Txn</div>
                            <div class="tubo-sum-val <?= $avgTubo < 0 ? 'danger' : '' ?>">
                                <?= $avgTubo >= 0 ? '' : '-' ?>₱<?= number_format(abs($avgTubo), 2) ?>
                            </div>
                        </div>
                    </div>

                    <!-- Per-product breakdown -->
                    <div class="tubo-breakdown-title"><i class="fas fa-list"></i> Breakdown per Product</div>
                    <?php if (!empty($tuboBreakdown)): ?>
                    <div style="overflow-x:auto;">
                        <table class="tubo-table">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Product</th>
                                    <th>Qty Sold</th>
                                    <th>Revenue</th>
                                    <th>Cost / pc</th>
                                    <th>Profit</th>
                                    <th>Margin</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($tuboBreakdown as $i => $tb):
                                $margin = $tb['revenue'] > 0 ? ($tb['tubo'] / $tb['revenue']) * 100 : 0;
                                $isPos  = $tb['tubo'] >= 0;
                            ?>
                                <tr>
                                    <td style="color:var(--c-faint);font-weight:700;font-size:12px"><?= $i + 1 ?></td>
                                    <td style="font-weight:600;color:var(--c-text)"><?= htmlspecialchars($tb['nm']) ?></td>
                                    <td><span class="qty-badge"><?= number_format($tb['qty']) ?></span></td>
                                    <td style="color:var(--c-success);font-weight:700">₱<?= number_format($tb['revenue'], 2) ?></td>
                                    <td style="color:var(--c-muted);font-size:12.5px">₱<?= number_format($tb['cost_price'], 2) ?></td>
                                    <td style="font-weight:800;color:<?= $isPos ? '#0d9488' : 'var(--c-danger)' ?>">
                                        <?= $isPos ? '+' : '' ?>₱<?= number_format($tb['tubo'], 2) ?>
                                    </td>
                                    <td>
                                        <div style="display:flex;align-items:center;gap:7px;">
                                            <div style="flex:1;height:7px;background:var(--c-border);border-radius:99px;overflow:hidden;min-width:50px;">
                                                <div style="height:100%;border-radius:99px;width:<?= min(100, abs($margin)) ?>%;background:<?= $isPos ? 'linear-gradient(to right,#14b8a6,#0d9488)' : 'var(--c-danger)' ?>"></div>
                                            </div>
                                            <span style="font-size:11px;font-weight:700;color:<?= $isPos ? '#0d9488' : 'var(--c-danger)' ?>;min-width:38px"><?= number_format($margin, 1) ?>%</span>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php else: ?>
                        <div class="empty-state" style="padding:30px 20px">
                            <div class="empty-icon"><i class="fas fa-chart-line"></i></div>
                            <h3>No Profit Data</h3>
                            <p class="tubo-no-cost">Make sure products have a cost price set so profit can be calculated.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        </div><!-- /section-tubo -->

        <!-- ═══ HISTORY SECTION ═══════════════════════════════ -->
        <div class="page-section active" id="section-history">
        <div class="panel">
            <div class="panel-head">
                <div class="panel-icon pi-slate"><i class="fas fa-history"></i></div>
                <div class="panel-title">Sales History</div>
                <div class="panel-acts">
                    <div class="filter-dd">
                        <div class="fdd-toggle" id="filterToggleBtn">
                            <i class="fas fa-filter"></i>
                            <span>Date: <span class="fv"><?= htmlspecialchars($filterTitle) ?></span></span>
                            <i class="fas fa-chevron-down" style="font-size:10px"></i>
                        </div>
                        <div class="dd-menu" id="dateFilterContainer">
                            <a href="?filter=today" class="dd-item <?= $filter=='today'?'active':'' ?>"><i class="fas fa-calendar-day"></i> Today</a>
                            <a href="?filter=week"  class="dd-item <?= $filter=='week' ?'active':'' ?>"><i class="fas fa-calendar-week"></i> Last 7 Days</a>
                            <a href="?filter=month" class="dd-item <?= $filter=='month'?'active':'' ?>"><i class="fas fa-calendar-alt"></i> Last 30 Days</a>
                            <a href="?filter=year"  class="dd-item <?= $filter=='year' ?'active':'' ?>"><i class="fas fa-calendar"></i> Last 365 Days</a>
                            <a href="?"             class="dd-item <?= $filter=='all'  ?'active':'' ?>"><i class="fas fa-globe"></i> All Time</a>
                            <div class="dd-div"></div>
                            <div class="dd-item" id="custom-date-toggle"><i class="fas fa-calendar-plus"></i> Custom Range</div>
                            <form class="cform <?= $filter=='custom'?'show':'' ?>" id="custom-date-form">
                                <div class="cdate-row">
                                    <input type="date" name="start_date" value="<?= $startDate ?>" required>
                                    <span>to</span>
                                    <input type="date" name="end_date" value="<?= $endDate ?>" required>
                                </div>
                                <input type="hidden" name="filter" value="custom">
                                <button type="submit" class="btn btn-primary btn-sm" style="width:100%">Apply</button>
                            </form>
                        </div>
                    </div>
                    <div class="filter-dd">
                        <div class="fdd-toggle" id="todToggleBtn">
                            <i class="fas fa-clock"></i>
                            <span>Time: <span class="fv"><?= htmlspecialchars($todTitle) ?></span></span>
                            <i class="fas fa-chevron-down" style="font-size:10px"></i>
                        </div>
                        <div class="dd-menu" id="todContainer">
                            <a href="<?= todUrl('all') ?>"       class="dd-item <?= $todFilter=='all'      ?'active':'' ?>"><i class="fas fa-globe-americas"></i> All Day</a>
                            <div class="dd-div"></div>
                            <a href="<?= todUrl('morning') ?>"   class="dd-item <?= $todFilter=='morning'  ?'active':'' ?>"><i class="fas fa-sun"></i>(5AM–12PM)</a>
                            <a href="<?= todUrl('afternoon') ?>" class="dd-item <?= $todFilter=='afternoon'?'active':'' ?>"><i class="fas fa-cloud-sun"></i>(12PM–6PM)</a>
                            <a href="<?= todUrl('evening') ?>"   class="dd-item <?= $todFilter=='evening'  ?'active':'' ?>"><i class="fas fa-moon"></i>(6PM–5AM)</a>
                        </div>
                    </div>
                </div>
            </div>

            <div style="padding:10px 20px;border-bottom:1px solid var(--c-border-soft);display:flex;gap:7px;flex-wrap:wrap;align-items:center;">
                <button onclick="exportFullPDF()" class="btn btn-warning btn-sm"><i class="fas fa-file-pdf"></i> Export PDF</button>
                <button onclick="openModal('productReportModal')" class="btn btn-primary btn-sm"><i class="fas fa-search-dollar"></i> Product Report</button>
                <span style="margin-left:auto;font-size:12px;color:var(--c-muted)"><?= number_format($totalRecords) ?> records</span>
            </div>

            <div style="padding:0">
                <div class="table-wrap">
                    <table>
                        <thead>
                            <tr>
                                <th><i class="fas fa-box" style="margin-right:5px"></i>Product</th>
                                <th><i class="fas fa-sort-numeric-up" style="margin-right:5px"></i>Qty</th>
                                <th><i class="fas fa-peso-sign" style="margin-right:5px"></i>Total</th>
                                <th><i class="fas fa-chart-line" style="margin-right:5px"></i>Profit</th>
                                <th><i class="fas fa-calendar-alt" style="margin-right:5px"></i>Date &amp; Time</th>
                                <th><i class="fas fa-user" style="margin-right:5px"></i>Cashier</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($salesData)): ?>
                            <?php foreach ($salesData as $row):
                                $costPrice = floatval($row['cost_price'] ?? 0);
                                $hasCost   = $costPrice > 0 && empty($row['is_manual']);
                                $tubo      = $hasCost ? $row['total_price'] - ($costPrice * $row['quantity']) : null;
                            ?>
                            <tr>
                                <td class="td-name"><?= htmlspecialchars($row['name']) ?><?php if(!empty($row['is_manual'])): ?><span class="td-manual">MANUAL</span><?php endif; ?><?php if(!empty($row['is_discounted'])): $discOff = max(0, floatval($row['original_price']) - floatval($row['total_price'])); ?><span class="td-discounted">DISCOUNTED -₱<?= number_format($discOff,2) ?></span><?php endif; ?><?php $isEpay = (($row['payment_mode'] ?? 'cash') === 'epay'); ?><span class="td-pay <?= $isEpay ? 'td-pay-epay' : 'td-pay-cash' ?>"><?= $isEpay ? 'E-PAY' : 'CASH' ?></span></td>
                                <td><span class="qty-badge"><?= (int)$row['quantity'] ?></span></td>
                                <td class="td-price">₱<?= number_format($row['total_price'],2) ?></td>
                                <td>
                                    <?php if ($tubo !== null): ?>
                                        <strong style="color:<?= $tubo >= 0 ? 'var(--c-success)' : 'var(--c-danger)' ?>">
                                            <?= $tubo >= 0 ? '+' : '' ?>₱<?= number_format($tubo, 2) ?>
                                        </strong>
                                    <?php else: ?>
                                        <span style="color:var(--c-faint);font-size:12px">—</span>
                                    <?php endif; ?>
                                </td>
                                <td class="td-date"><?= date('M d, Y · h:i A',strtotime($row['sale_date'])) ?></td>
                                <td><?= !empty($row['cashier']) ? htmlspecialchars($row['cashier']) : '<span style="color:var(--c-faint);font-size:12px">—</span>' ?></td>
                            </tr>
                            <?php endforeach; ?>
                            <?php else: ?>
                            <tr><td colspan="6"><div class="empty-state"><div class="empty-icon"><i class="fas fa-chart-line"></i></div><h3>No Sales Data Found</h3><p>No transactions for the selected period.</p></div></td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <?php if ($totalPages > 1): ?>
                <div class="pagination" style="padding:14px 0">
                    <?php if ($page>1): ?><a href="<?= pUrl($page-1) ?>"><i class="fas fa-chevron-left"></i></a><?php endif; ?>
                    <?php $sp=max(1,min($page-4,$totalPages-9)); $ep=min($sp+9,$totalPages); ?>
                    <?php if ($sp>1): ?><a href="<?= pUrl(1) ?>">1</a><?php if ($sp>2): ?><span class="ell">…</span><?php endif; ?><?php endif; ?>
                    <?php for ($i=$sp;$i<=$ep;$i++): ?><?php if ($i==$page): ?><strong><?= $i ?></strong><?php else: ?><a href="<?= pUrl($i) ?>"><?= $i ?></a><?php endif; ?><?php endfor; ?>
                    <?php if ($ep<$totalPages): ?><?php if ($ep<$totalPages-1): ?><span class="ell">…</span><?php endif; ?><a href="<?= pUrl($totalPages) ?>"><?= $totalPages ?></a><?php endif; ?>
                    <?php if ($page<$totalPages): ?><a href="<?= pUrl($page+1) ?>"><i class="fas fa-chevron-right"></i></a><?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
        </div><!-- /section-history -->
    </div><!-- /page-body -->
</div><!-- /main -->

<div class="chart-tooltip" id="chartTooltip"></div>

<div class="modal-overlay" id="topProductsModal">
    <div class="modal-box">
        <div class="modal-head"><div class="mhi mhi-green"><i class="fas fa-trophy"></i></div><div class="mh-title">Top 10 Products — <?= htmlspecialchars($filterTitle) ?></div></div>
        <button class="modal-close" onclick="closeModal('topProductsModal')"><i class="fas fa-times"></i></button>
        <div class="modal-body">
            <?php if (!empty($topProducts)): ?>
            <div class="tp-grid">
                <?php foreach ($topProducts as $i=>$tp): ?>
                <div class="tp-card">
                    <div class="tp-rank"><?= $i+1 ?></div>
                    <div class="tp-info">
                        <div class="tp-name"><?= htmlspecialchars($tp['nm']) ?></div>
                        <div class="tp-stat"><i class="fas fa-box"></i><?= number_format($tp['qty']) ?> sold</div>
                        <div class="tp-stat"><i class="fas fa-receipt"></i><?= number_format($tp['txn']) ?> transactions</div>
                        <div class="tp-stat"><i class="fas fa-peso-sign"></i>₱<?= number_format($tp['rev'],2) ?></div>
                    </div>
                    <div class="tp-circle"><div class="tp-cv"><?= number_format($tp['qty']) ?></div><div class="tp-cl">Units</div></div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php else: ?>
            <div class="empty-state"><div class="empty-icon"><i class="fas fa-shopping-cart"></i></div><h3>No Product Data</h3><p>No products sold this period.</p></div>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="modal-overlay" id="productReportModal">
    <div class="modal-box sm">
        <div class="modal-head"><div class="mhi mhi-blue"><i class="fas fa-search-dollar"></i></div><div class="mh-title">Product Report</div></div>
        <button class="modal-close" onclick="closeModal('productReportModal')"><i class="fas fa-times"></i></button>
        <div class="modal-body">
            <form class="search-row" id="productSearchForm">
                <input type="text" id="productSearchInput" placeholder="Search product name…" required>
                <button type="submit" class="btn btn-primary btn-md"><i class="fas fa-search"></i></button>
            </form>
            <div id="product-search-results">
                <div class="empty-state" style="padding:30px 10px"><div class="empty-icon"><i class="fas fa-search"></i></div><h3>Search a Product</h3><p>Enter a name to see its sales performance.</p></div>
            </div>
        </div>
    </div>
</div>

<div class="modal-overlay" id="dbModal">
    <div class="modal-box sm">
        <div class="modal-head"><div class="mhi mhi-red"><i class="fas fa-database"></i></div><div class="mh-title">Database Management</div></div>
        <button class="modal-close" onclick="closeModal('dbModal')"><i class="fas fa-times"></i></button>
        <div class="modal-body">
            <div class="danger-info"><i class="fas fa-exclamation-triangle"></i><div><strong>Warning:</strong> Deleting records is permanent and cannot be undone.</div></div>
            <form id="deleteRecordsForm" method="post" action="delete_records.php">
                <div class="form-group">
                    <label for="deleteMonth">Select Month to Delete</label>
                    <select name="month" id="deleteMonth" required>
                        <option value="">— Select Month —</option>
                        <?php
                        $mq = $conn->query("SELECT DISTINCT YEAR(sale_date) y, MONTH(sale_date) m, DATE_FORMAT(sale_date,'%M %Y') mn, COUNT(*) c FROM sales GROUP BY y,m ORDER BY y DESC,m DESC");
                        while ($r=$mq->fetch_assoc()) echo "<option value='{$r['y']}-{$r['m']}'>{$r['mn']} ({$r['c']} records)</option>";
                        ?>
                    </select>
                </div>
                <button type="submit" class="btn btn-danger btn-md" style="width:100%"><i class="fas fa-trash-alt"></i> Delete Records</button>
            </form>
        </div>
    </div>
</div>

<!-- PDF data passed to JS -->
<script>
const PDF_DATA = {
    filterTitle: <?= json_encode($filterTitle) ?>,
    generated:   <?= json_encode(date('M d, Y h:i A')) ?>,
    transactions:<?= (int)$totalTransactions ?>,
    totalSales:  <?= (float)$totalSales ?>,
    totalTubo:   <?= (float)$pdfTotalProfit ?>,
    avgTxn:      <?= (float)$avgTransaction ?>,
    rows: <?= json_encode(array_map(function($r){
        return [
            'name'        => ($r['name'] ?? '') . (!empty($r['is_manual']) ? ' [MANUAL]' : '') . (!empty($r['is_discounted']) ? ' [DISCOUNTED -P' . number_format(max(0, floatval($r['original_price']) - floatval($r['total_price'])), 2) . ']' : '') . ' [' . ((($r['payment_mode'] ?? 'cash') === 'epay') ? 'E-PAY' : 'CASH') . ']',
            'qty'         => (int)$r['quantity'],
            'total'       => (float)$r['total_price'],
            'tubo'        => $r['tubo'],
            'date'        => date('M d, Y h:i A', strtotime($r['sale_date'])),
            'cashier'     => $r['cashier'] ?: '-',
        ];
    }, $pdfRows)) ?>
};
</script>

<script>
const CHART_DATA = <?= $chartJson ?>;

/* Clock */
(function tick(){
    const n = new Date();
    // Using toLocaleTimeString for easy 12-hour formatting
    const timeString = n.toLocaleTimeString('en-PH', { 
        hour: '2-digit', 
        minute: '2-digit', 
        second: '2-digit', 
        hour12: true 
    });
    
    document.getElementById('clockTime').textContent = timeString;
    document.getElementById('clockDate').textContent = n.toLocaleDateString('en-PH', {
        month: 'short', 
        day: 'numeric', 
        year: 'numeric'
    });
    setTimeout(tick, 1000);
})();

/* Tab switching */
function switchTab(name){
    document.querySelectorAll('.page-section').forEach(s=>s.classList.remove('active'));
    document.querySelectorAll('.tab-btn').forEach(b=>b.classList.remove('active'));
    document.getElementById('section-'+name).classList.add('active');
    document.getElementById('tab-'+name).classList.add('active');
    // Redraw chart when revenue tab is activated
    if(name==='revenue') window.dispatchEvent(new Event('resize'));
}

/* Cash <-> E-Pay card: click to switch which total is shown */
(function(){
    var card = document.getElementById('payToggleCard');
    if(!card) return;
    var data = {
        cash: { total: <?= (float)$payTotals['cash']['total'] ?>, txn: <?= (int)$payTotals['cash']['txn'] ?>, label: 'Total Cash',  icon: 'fa-money-bill-wave',     bg: 'spi-blue'   },
        epay: { total: <?= (float)$payTotals['epay']['total'] ?>, txn: <?= (int)$payTotals['epay']['txn'] ?>, label: 'Total E-Pay', icon: 'fa-mobile-screen-button', bg: 'spi-purple' }
    };
    var mode = 'cash';
    function peso(n){ return '₱' + Number(n).toLocaleString('en-PH',{minimumFractionDigits:2,maximumFractionDigits:2}); }
    function render(){
        var d = data[mode];
        document.getElementById('payToggleVal').textContent = peso(d.total);
        document.getElementById('payToggleLbl').textContent = d.label;
        document.getElementById('payToggleCnt').textContent = '· ' + d.txn.toLocaleString('en-PH') + ' txn';
        document.getElementById('payToggleIcon').className = 'spi ' + d.bg;
        document.getElementById('payToggleIconI').className = 'fas ' + d.icon;
        card.classList.toggle('epay', mode === 'epay');
    }
    function flip(){ mode = (mode === 'cash') ? 'epay' : 'cash'; render(); }
    card.addEventListener('click', flip);
    card.addEventListener('keydown', function(e){ if(e.key==='Enter'||e.key===' '){ e.preventDefault(); flip(); } });
})();

/* Sidebar */
function toggleSidebar(){ document.getElementById('sidebar').classList.toggle('open'); }

/* Chart fold */
function toggleChart(){
    document.getElementById('chartBody').classList.toggle('open');
    document.getElementById('chartChevron').classList.toggle('open');
}

/* Tubo fold */
function toggleTubo(){
    document.getElementById('tuboBody').classList.toggle('open');
    document.getElementById('tuboChevron').classList.toggle('open');
}

/* Revenue Canvas Chart */
(function(){
    const data   = CHART_DATA;
    const totals = data.map(d=>parseFloat(d.total)||0);
    const maxVal = Math.max(...totals,1);
    const avg7   = totals.map((_,i)=>{ const s=totals.slice(Math.max(0,i-6),i+1); return s.reduce((a,b)=>a+b,0)/s.length; });
    const peakIdx= totals.indexOf(Math.max(...totals));

    document.getElementById('chartPeak').textContent  = '₱'+Math.max(...totals).toLocaleString('en-PH',{minimumFractionDigits:0,maximumFractionDigits:0});
    document.getElementById('chartTotal').textContent = '₱'+totals.reduce((a,b)=>a+b,0).toLocaleString('en-PH',{minimumFractionDigits:0,maximumFractionDigits:0});

    const xl = document.getElementById('chartXLabels');
    data.forEach((d,i)=>{ const e=document.createElement('div'); e.className='chart-x-label'; e.textContent=(i%5===0||i===data.length-1)?d.short:''; xl.appendChild(e); });

    const canvas = document.getElementById('revenueChart');
    const dpr = window.devicePixelRatio||1;

    function draw(){
        const W=canvas.offsetWidth, H=220;
        canvas.width=W*dpr; canvas.height=H*dpr;
        canvas.style.height=H+'px';
        const ctx=canvas.getContext('2d');
        ctx.scale(dpr,dpr);

        const pL=36,pR=8,pT=14,pB=4;
        const cw=W-pL-pR, ch=H-pT-pB, n=data.length, bw=cw/n;
        const xPos=i=>pL+i*bw+bw*0.15;
        const bW=bw*0.7;
        const yPos=v=>pT+ch-(v/maxVal)*ch;

        const cs=getComputedStyle(document.documentElement);
        const cP=cs.getPropertyValue('--c-primary').trim();
        const cPL=cs.getPropertyValue('--c-primary-lt').trim();
        const cS=cs.getPropertyValue('--c-success').trim();
        const cB=cs.getPropertyValue('--c-border').trim();
        const cF=cs.getPropertyValue('--c-faint').trim();
        const cM=cs.getPropertyValue('--c-muted').trim();

        ctx.clearRect(0,0,W,H);

        // Grid + Y labels
        ctx.font=`9px DM Sans,sans-serif`;
        [0.25,0.5,0.75,1].forEach(f=>{
            const y=pT+ch*(1-f);
            ctx.strokeStyle=cB; ctx.lineWidth=1;
            ctx.setLineDash([3,3]);
            ctx.beginPath(); ctx.moveTo(pL,y); ctx.lineTo(W-pR,y); ctx.stroke();
            ctx.setLineDash([]);
            const v=maxVal*f;
            const label=v>=1000?'₱'+(v/1000).toFixed(v>=10000?0:1)+'k':'₱'+v.toFixed(0);
            ctx.fillStyle=cM; ctx.textAlign='right';
            ctx.fillText(label,pL-4,y+3);
        });
        ctx.textAlign='left';

        // Bars
        totals.forEach((v,i)=>{
            const x=xPos(i), y=yPos(v), bh=ch-(y-pT);
            if(bh<=0) return;
            const grad=ctx.createLinearGradient(0,y,0,pT+ch);
            grad.addColorStop(0,i===peakIdx?cP:cP);
            grad.addColorStop(1,cPL);
            const r=Math.min(4,bW/2);
            ctx.beginPath();
            ctx.moveTo(x+r,y); ctx.lineTo(x+bW-r,y);
            ctx.quadraticCurveTo(x+bW,y,x+bW,y+r);
            ctx.lineTo(x+bW,pT+ch); ctx.lineTo(x,pT+ch);
            ctx.lineTo(x,y+r); ctx.quadraticCurveTo(x,y,x+r,y);
            ctx.fillStyle=i===peakIdx?cP:grad; ctx.globalAlpha=i===peakIdx?1:.82;
            ctx.fill(); ctx.globalAlpha=1;
        });

        // Avg line
        ctx.beginPath(); ctx.strokeStyle=cS; ctx.lineWidth=2.5; ctx.lineJoin='round'; ctx.setLineDash([]);
        avg7.forEach((v,i)=>{ const x=pL+i*bw+bw/2,y=yPos(v); i===0?ctx.moveTo(x,y):ctx.lineTo(x,y); });
        ctx.stroke();
        avg7.forEach((v,i)=>{
            if(i%5===0||i===n-1){
                ctx.beginPath(); ctx.arc(pL+i*bw+bw/2,yPos(v),3.5,0,Math.PI*2);
                ctx.fillStyle=cS; ctx.fill();
                ctx.beginPath(); ctx.arc(pL+i*bw+bw/2,yPos(v),1.5,0,Math.PI*2);
                ctx.fillStyle='#fff'; ctx.fill();
            }
        });

        // Peak label
        const px=xPos(peakIdx)+bW/2, py=yPos(totals[peakIdx])-8;
        ctx.fillStyle=cP; ctx.font='bold 11px DM Sans,sans-serif'; ctx.textAlign='center';
        ctx.fillText('▲',px,py); ctx.textAlign='left';
    }

    draw(); window.addEventListener('resize',draw);

    const tip=document.getElementById('chartTooltip');
    canvas.addEventListener('mousemove',e=>{
        const r=canvas.getBoundingClientRect();
        const bw2=(r.width-44)/data.length;
        const idx=Math.floor((e.clientX-r.left-36)/bw2);
        if(idx<0||idx>=data.length){tip.style.opacity=0;return;}
        const d=data[idx];
        tip.innerHTML=`<div>${d.label}</div><div style="color:#93c5fd">₱${parseFloat(d.total).toLocaleString('en-PH',{minimumFractionDigits:2,maximumFractionDigits:2})}</div><div style="color:#6ee7b7">${d.txn} transactions</div>`;
        tip.style.opacity=1;
        tip.style.left=(e.clientX+14)+'px';
        tip.style.top=(e.clientY-10)+'px';
    });
    canvas.addEventListener('mouseleave',()=>tip.style.opacity=0);
})();

/* Modals */
function openModal(id){document.getElementById(id).classList.add('open');document.body.style.overflow='hidden';}
function closeModal(id){document.getElementById(id).classList.remove('open');document.body.style.overflow='';}
document.addEventListener('click',e=>{document.querySelectorAll('.modal-overlay.open').forEach(m=>{if(e.target===m)closeModal(m.id);});});
document.addEventListener('keydown',e=>{if(e.key==='Escape')document.querySelectorAll('.modal-overlay.open').forEach(m=>closeModal(m.id));});

/* Dropdowns */
document.addEventListener('DOMContentLoaded',()=>{
    [['filterToggleBtn','dateFilterContainer'],['todToggleBtn','todContainer']].forEach(([b,m])=>{
        const btn=document.getElementById(b),menu=document.getElementById(m);
        if(!btn||!menu)return;
        btn.addEventListener('click',e=>{e.stopPropagation();menu.classList.toggle('show');});
        document.addEventListener('click',e=>{if(!menu.contains(e.target)&&!btn.contains(e.target))menu.classList.remove('show');});
    });
    const ct=document.getElementById('custom-date-toggle'),cf=document.getElementById('custom-date-form');
    if(ct&&cf)ct.addEventListener('click',e=>{e.stopPropagation();cf.classList.toggle('show');});

    document.getElementById('productSearchForm').addEventListener('submit',function(e){
        e.preventDefault();
        const term=document.getElementById('productSearchInput').value;
        const res=document.getElementById('product-search-results');
        const p=new URLSearchParams(window.location.search);
        res.innerHTML='<div class="empty-state" style="padding:20px"><div class="empty-icon"><i class="fas fa-spinner fa-spin"></i></div><p>Searching…</p></div>';
        fetch(`search_product_report.php?search=${encodeURIComponent(term)}&filter=${p.get('filter')||'all'}&start_date=${p.get('start_date')||''}&end_date=${p.get('end_date')||''}`)
            .then(r=>r.text()).then(d=>{res.innerHTML=d;})
            .catch(()=>{res.innerHTML='<div class="empty-state"><div class="empty-icon"><i class="fas fa-exclamation-triangle"></i></div><h3>Error</h3><p>Could not fetch report.</p></div>';});
    });

    document.getElementById('deleteRecordsForm').addEventListener('submit',function(e){
        const s=document.getElementById('deleteMonth');
        if(!s.value){alert('Please select a month first.');e.preventDefault();return;}
        if(!confirm(`WARNING: Permanently delete all records from ${s.options[s.selectedIndex].text}?\n\nThis CANNOT be undone.`))e.preventDefault();
    });

    setTimeout(()=>{document.querySelectorAll('.alert').forEach(a=>{a.style.transition='opacity .5s';a.style.opacity='0';setTimeout(()=>a.remove(),500);});},5000);
});

function exportFullPDF(){
    const btn = event.currentTarget;
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Generating…';

    setTimeout(function(){
        try {
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF({ unit:'mm', format:'a4', orientation:'portrait' });
            const d   = PDF_DATA;
            const pw  = doc.internal.pageSize.getWidth();  // 210
            const ph  = doc.internal.pageSize.getHeight(); // 297
            const lm  = 12, rm = 12, tm = 12;
            let y = tm;

            // ── Helper: peso format (no peso sign font issue — use "P ")
            const peso = v => 'P ' + parseFloat(v).toLocaleString('en-PH', {minimumFractionDigits:2,maximumFractionDigits:2});

            // ── HEADER
            doc.setFont('helvetica','bold');
            doc.setFontSize(16);
            doc.setTextColor(37, 99, 235);
            doc.text('Sari', lm, y + 5);
            doc.setTextColor(0, 0, 0);
            doc.text('-Link', lm + doc.getTextWidth('Sari'), y + 5);
            doc.setFontSize(7);
            doc.setFont('helvetica','normal');
            doc.setTextColor(100, 116, 139);
            doc.text('SALES REPORT', lm, y + 10);

            doc.setFontSize(8);
            doc.setTextColor(60, 60, 60);
            doc.text('Period: ' + d.filterTitle, pw - rm, y + 4, {align:'right'});
            doc.text('Generated: ' + d.generated, pw - rm, y + 9, {align:'right'});
            y += 14;

            // ── BLUE LINE
            doc.setDrawColor(37, 99, 235);
            doc.setLineWidth(0.6);
            doc.line(lm, y, pw - rm, y);
            y += 5;

            // ── SUMMARY CARDS (4 boxes)
            const cards = [
                { label:'TRANSACTIONS', value: parseInt(d.transactions).toLocaleString(), color:[29,78,216] },
                { label:'TOTAL SALES',  value: peso(d.totalSales),   color:[5,150,105] },
                { label:'TOTAL PROFIT', value: peso(d.totalTubo),    color:[124,58,237] },
                { label:'AVG / TXN',    value: peso(d.avgTxn),       color:[217,119,6] },
            ];
            const cw = (pw - lm - rm - 9) / 4;
            cards.forEach((c, i) => {
                const cx = lm + i * (cw + 3);
                // label bar
                doc.setFillColor(...c.color);
                doc.rect(cx, y, cw, 6, 'F');
                doc.setFont('helvetica','bold');
                doc.setFontSize(6);
                doc.setTextColor(255,255,255);
                doc.text(c.label, cx + 2, y + 4);
                // value area
                doc.setFillColor(248,250,252);
                doc.setDrawColor(200,200,200);
                doc.setLineWidth(0.3);
                doc.rect(cx, y + 6, cw, 9, 'FD');
                doc.setFont('helvetica','bold');
                doc.setFontSize(9);
                doc.setTextColor(...c.color);
                doc.text(c.value, cx + cw/2, y + 12.5, {align:'center'});
            });
            y += 20;

            // ── SECTION LABEL
            doc.setFont('helvetica','bold');
            doc.setFontSize(6.5);
            doc.setTextColor(150,150,150);
            doc.text('TRANSACTION RECORDS  ·  ' + d.filterTitle.toUpperCase(), lm, y);
            y += 4;

            // ── TABLE via autoTable
            const rows = d.rows.map(r => [
                r.name,
                r.qty,
                peso(r.total),
                r.tubo !== null ? (r.tubo >= 0 ? '+' : '') + peso(r.tubo) : '-',
                r.date,
                r.cashier
            ]);

            // Totals row
            rows.push(['TOTAL', '', peso(d.totalSales), peso(d.totalTubo), '', '']);

            doc.autoTable({
                startY: y,
                margin: { left: lm, right: rm },
                head: [['Product','Qty','Total','Profit','Date & Time','Cashier']],
                body: rows,
                styles: { fontSize:8, cellPadding:2.5, font:'helvetica', overflow:'linebreak' },
                headStyles: { fillColor:[30,41,59], textColor:255, fontStyle:'bold', fontSize:7.5, halign:'center' },
                columnStyles: {
                    0: { halign:'left',  cellWidth:52 },
                    1: { halign:'center',cellWidth:12 },
                    2: { halign:'right', cellWidth:40 },
                    3: { halign:'right', cellWidth:22 },
                    4: { halign:'center',cellWidth:38 },
                    5: { halign:'center',cellWidth:23 },
                },
                alternateRowStyles: { fillColor:[244,244,244] },
                didParseCell: function(data){
                    const isLast = data.row.index === rows.length - 1;
                    if(isLast){
                        data.cell.styles.fillColor  = [220,220,220];
                        data.cell.styles.fontStyle  = 'bold';
                        data.cell.styles.fontSize   = 9;
                        if(data.column.index === 2) data.cell.styles.textColor = [5,150,105];
                        if(data.column.index === 3) data.cell.styles.textColor = [124,58,237];
                    }
                    // Color tubo column
                    if(data.section === 'body' && data.column.index === 3 && !isLast){
                        const v = data.cell.raw;
                        if(typeof v === 'string' && v.startsWith('+')) data.cell.styles.textColor = [5,150,105];
                        else if(typeof v === 'string' && v !== '-')    data.cell.styles.textColor = [220,38,38];
                        else data.cell.styles.textColor = [180,180,180];
                    }
                },
                didDrawPage: function(data){
                    // Footer on each page
                    doc.setFont('helvetica','normal');
                    doc.setFontSize(7);
                    doc.setTextColor(180,180,180);
                    doc.text('\u00A9 ' + new Date().getFullYear() + ' Sari-Link System  \u00B7  Business Confidential', lm, ph - 6);
                    doc.text('Page ' + doc.getCurrentPageInfo().pageNumber, pw - rm, ph - 6, {align:'right'});
                }
            });

            doc.save('SariLink_Sales_Report.pdf');
        } catch(e) {
            alert('PDF generation failed: ' + e.message);
        }

        btn.disabled = false;
        btn.innerHTML = '<i class="fas fa-file-pdf"></i> Export PDF';
    }, 50);
}
</script>
</body>
</html>