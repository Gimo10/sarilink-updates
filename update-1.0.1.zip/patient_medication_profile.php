<?php
session_start();
include 'db.php';
include 'auth.php';
require_login();
dashboard_invalidate();

date_default_timezone_set('Asia/Manila');

// ── Create table if not exists ──────────────────────────────────────────────
$conn->query("
    CREATE TABLE IF NOT EXISTS patient_medication_profiles (
        id INT AUTO_INCREMENT PRIMARY KEY,
        patient_name VARCHAR(255) NOT NULL,
        age INT NOT NULL,
        address TEXT NOT NULL,
        contact_no VARCHAR(50) NOT NULL,
        gender ENUM('Male','Female','Other') NOT NULL,
        date_of_birth DATE NOT NULL,
        pregnant_lactating ENUM('N/A','Pregnant','Lactating') NOT NULL DEFAULT 'N/A',
        allergies TEXT NOT NULL DEFAULT '',
        medications TEXT NOT NULL,
        dose VARCHAR(255) NOT NULL,
        direction TEXT NOT NULL,
        created_at DATETIME DEFAULT NOW(),
        updated_at DATETIME DEFAULT NOW() ON UPDATE NOW()
    )
");

// ── Add allergies column if upgrading from older schema ─────────────────────
$conn->query("ALTER TABLE patient_medication_profiles ADD COLUMN IF NOT EXISTS allergies TEXT NOT NULL DEFAULT ''");



// ── DELETE ──────────────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
    $del_id = intval($_POST['delete_id']);
    $stmt = $conn->prepare("DELETE FROM patient_medication_profiles WHERE id = ?");
    $stmt->bind_param("i", $del_id);
    $_SESSION['pmp_success'] = $stmt->execute() ? "Patient record deleted successfully." : "Failed to delete record.";
    $stmt->close();
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// ── SAVE (Add / Edit) ───────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_patient'])) {
    $edit_id            = intval($_POST['edit_id'] ?? 0);
    $patient_name       = trim($_POST['patient_name'] ?? '');
    $age                = intval($_POST['age'] ?? 0);
    $address            = trim($_POST['address'] ?? '');
    $contact_no         = trim($_POST['contact_no'] ?? '');
    $gender             = $_POST['gender'] ?? '';
    $date_of_birth      = $_POST['date_of_birth'] ?? '';
    $pregnant_lactating = $_POST['pregnant_lactating'] ?? 'N/A';
    $allergies          = trim($_POST['allergies'] ?? '');
    $medications        = trim($_POST['medications'] ?? '');
    $dose               = trim($_POST['dose'] ?? '');
    $direction          = trim($_POST['direction'] ?? '');

    if (!$patient_name || !$age || !$address || !$contact_no || !$gender || !$date_of_birth || !$medications || !$dose || !$direction) {
        $_SESSION['pmp_error'] = "All fields are required.";
    } else {
        if ($edit_id > 0) {
            $stmt = $conn->prepare("UPDATE patient_medication_profiles SET patient_name=?,age=?,address=?,contact_no=?,gender=?,date_of_birth=?,pregnant_lactating=?,allergies=?,medications=?,dose=?,direction=? WHERE id=?");
            $stmt->bind_param("sisssssssssi", $patient_name, $age, $address, $contact_no, $gender, $date_of_birth, $pregnant_lactating, $allergies, $medications, $dose, $direction, $edit_id);
            $msg = "Patient record updated successfully.";
        } else {
            $stmt = $conn->prepare("INSERT INTO patient_medication_profiles (patient_name,age,address,contact_no,gender,date_of_birth,pregnant_lactating,allergies,medications,dose,direction) VALUES (?,?,?,?,?,?,?,?,?,?,?)");
            $stmt->bind_param("sisssssssss", $patient_name, $age, $address, $contact_no, $gender, $date_of_birth, $pregnant_lactating, $allergies, $medications, $dose, $direction);
            $msg = "Patient profile saved successfully.";
        }
        if ($stmt->execute()) {
            $_SESSION['pmp_success'] = $msg;
        } else {
            $_SESSION['pmp_error'] = "Database error: " . $stmt->error;
        }
        $stmt->close();
    }
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// ── Flash messages ──────────────────────────────────────────────────────────
$success_message = '';
$error           = '';
if (isset($_SESSION['pmp_success'])) { $success_message = $_SESSION['pmp_success']; unset($_SESSION['pmp_success']); }
if (isset($_SESSION['pmp_error']))   { $error           = $_SESSION['pmp_error'];   unset($_SESSION['pmp_error']); }

// ── Pre-load record for JS-driven edit modal ────────────────────────────────
$edit_json = 'null';
if (isset($_GET['edit'])) {
    $eid = intval($_GET['edit']);
    $res = $conn->query("SELECT * FROM patient_medication_profiles WHERE id = $eid");
    if ($res && $res->num_rows > 0) {
        $edit_json = json_encode($res->fetch_assoc());
    }
}

// ── Search / Fetch list ─────────────────────────────────────────────────────
$search = trim($_GET['search'] ?? '');
$where  = '';
if ($search !== '') {
    $s     = $conn->real_escape_string($search);
    $where = "WHERE patient_name LIKE '%$s%' OR contact_no LIKE '%$s%' OR medications LIKE '%$s%'";
}
$patients    = $conn->query("SELECT * FROM patient_medication_profiles $where ORDER BY created_at DESC");
$total_count = $patients ? $patients->num_rows : 0;

// Stats
$stat_total  = $conn->query("SELECT COUNT(*) c FROM patient_medication_profiles")->fetch_assoc()['c'];
$stat_male   = $conn->query("SELECT COUNT(*) c FROM patient_medication_profiles WHERE gender='Male'")->fetch_assoc()['c'];
$stat_female = $conn->query("SELECT COUNT(*) c FROM patient_medication_profiles WHERE gender='Female'")->fetch_assoc()['c'];
$stat_preg   = $conn->query("SELECT COUNT(*) c FROM patient_medication_profiles WHERE pregnant_lactating IN ('Pregnant','Lactating')")->fetch_assoc()['c'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Patient Medication Profile — Sari-Link</title>
<link href="assets/css/fonts.css" rel="stylesheet">
<link href="assets/css/fontawesome.min.css" rel="stylesheet">
<link rel="shortcut icon" href="Sari-Link.ico" type="image/x-icon">
<style>
/* ─── Design Tokens ─────────────────────────────────────────────────────── */
:root{
  --c-bg:#eef2f8; --c-surface:#fff; --c-surface-2:#f6f8fb;
  --c-border:#e2e8f2; --c-border-soft:#edf1f7;
  --c-primary:#2563eb; --c-primary-dk:#1e40af; --c-primary-lt:#dbeafe; --c-primary-hv:#1d4ed8;
  --c-success:#059669; --c-success-lt:#d1fae5;
  --c-warning:#d97706; --c-warning-lt:#fef3c7;
  --c-danger:#dc2626;  --c-danger-lt:#fee2e2;
  --c-teal:#0d9488;    --c-teal-lt:#ccfbf1;
  --c-text:#0f172a;    --c-muted:#57647c; --c-faint:#8695ab;
  --r-sm:8px; --r-md:12px; --r-lg:18px; --r-xl:24px;
  --sh-xs:0 1px 2px rgba(15,23,42,.05);
  --sh-sm:0 2px 6px rgba(15,23,42,.06),0 1px 2px rgba(15,23,42,.04);
  --sh-md:0 8px 24px rgba(15,23,42,.08),0 2px 6px rgba(15,23,42,.04);
  --sh-lg:0 20px 56px rgba(15,23,42,.18),0 4px 14px rgba(15,23,42,.08);
  --font:'DM Sans',sans-serif; --disp:'Playfair Display',serif;
  --t:180ms ease;
}
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box;}
body{font-family:var(--font);background:var(--c-bg);color:var(--c-text);line-height:1.6;min-height:100vh;}
a{text-decoration:none;color:inherit;}
button{font-family:inherit;cursor:pointer;}
input,select,textarea{font-family:inherit;}
::-webkit-scrollbar{width:5px;height:5px;}
::-webkit-scrollbar-thumb{background:var(--c-border);border-radius:99px;}

/* ─── Header ─────────────────────────────────────────────────────────────── */
.header{
  background:var(--c-surface);border-bottom:1px solid var(--c-border);
  padding:0 28px;height:72px;display:flex;align-items:center;
  justify-content:space-between;gap:16px;
  position:sticky;top:0;z-index:300;box-shadow:var(--sh-xs);
}
.header-left{display:flex;align-items:center;gap:13px;}
.logo-mark{
  width:42px;height:42px;flex-shrink:0;
  background:linear-gradient(135deg,#eef4ff,#dce9fb);
  border-radius:var(--r-md);display:flex;align-items:center;
  justify-content:center;color:#fff;font-size:17px;
  padding:7px;box-shadow:inset 0 0 0 1px rgba(13,148,136,.14);
}
.logo-mark img{width:100%;height:100%;object-fit:contain;}
.logo-name{font-family:var(--disp);font-size:20px;line-height:1.15;color:var(--c-text);}
.logo-name span{color:var(--c-primary);}
.logo-sub{font-size:11px;color:var(--c-muted);font-weight:500;}
.header-right{display:flex;align-items:center;gap:10px;}
.nav-btn{
  display:inline-flex;align-items:center;gap:7px;
  padding:8px 16px;border-radius:var(--r-md);font-size:13px;font-weight:600;
  border:1px solid var(--c-border);background:var(--c-surface-2);
  color:var(--c-muted);transition:all var(--t);cursor:pointer;
}
.nav-btn:hover{background:var(--c-primary-lt);color:var(--c-primary);border-color:#93c5fd;}
.btn-add-patient{
  display:inline-flex;align-items:center;gap:7px;
  padding:9px 20px;border-radius:var(--r-md);font-size:13px;font-weight:700;
  border:none;background:var(--c-teal);color:#fff;
  box-shadow:0 2px 8px rgba(13,148,136,.35);transition:all var(--t);cursor:pointer;
}
.btn-add-patient:hover{background:#0f766e;transform:translateY(-1px);box-shadow:0 4px 14px rgba(13,148,136,.4);}

/* ─── Page ───────────────────────────────────────────────────────────────── */
.page-body{max-width:1400px;margin:0 auto;padding:28px 28px 56px;}

/* ─── Alert ──────────────────────────────────────────────────────────────── */
.alert{
  display:flex;align-items:center;gap:10px;padding:13px 18px;
  border-radius:var(--r-md);font-size:13px;font-weight:600;
  margin-bottom:20px;border-left:4px solid;
}
.alert-success{background:var(--c-success-lt);color:var(--c-success);border-color:var(--c-success);}
.alert-error  {background:var(--c-danger-lt);color:var(--c-danger);border-color:var(--c-danger);}
.alert-close{margin-left:auto;background:none;border:none;font-size:14px;cursor:pointer;opacity:.55;color:inherit;}
.alert-close:hover{opacity:1;}

/* ─── Stats Row ──────────────────────────────────────────────────────────── */
.stats-row{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-bottom:24px;}
.stat-card{
  background:var(--c-surface);border:1px solid var(--c-border);
  border-radius:var(--r-lg);padding:18px 20px;box-shadow:var(--sh-xs);
  display:flex;align-items:center;gap:14px;transition:box-shadow var(--t);
}
.stat-card:hover{box-shadow:var(--sh-sm);}
.stat-icon{width:46px;height:46px;border-radius:var(--r-md);display:flex;align-items:center;justify-content:center;font-size:19px;flex-shrink:0;}
.si-teal {background:var(--c-teal-lt);  color:var(--c-teal);}
.si-blue {background:var(--c-primary-lt);color:var(--c-primary);}
.si-pink {background:#fce7f3;           color:#be185d;}
.si-amber{background:var(--c-warning-lt);color:var(--c-warning);}
.stat-val{font-size:26px;font-weight:800;line-height:1;color:var(--c-text);}
.stat-lbl{font-size:11px;font-weight:600;color:var(--c-muted);margin-top:2px;}

/* ─── Panel ──────────────────────────────────────────────────────────────── */
.panel{background:var(--c-surface);border:1px solid var(--c-border);border-radius:var(--r-lg);box-shadow:var(--sh-xs);overflow:hidden;}
.panel-header{
  padding:18px 22px;border-bottom:1px solid var(--c-border-soft);
  display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;
}
.panel-header-left{display:flex;align-items:center;gap:12px;}
.panel-icon{width:38px;height:38px;border-radius:var(--r-md);display:flex;align-items:center;justify-content:center;color:#fff;font-size:15px;flex-shrink:0;}
.pi-blue{background:linear-gradient(135deg,#3b82f6,#1d4ed8);}
.panel-title{font-size:15px;font-weight:700;color:var(--c-text);}
.record-badge{background:var(--c-primary-lt);color:var(--c-primary);font-size:11px;font-weight:700;padding:3px 11px;border-radius:99px;border:1px solid #93c5fd;}

/* Search */
.search-form{display:flex;gap:8px;align-items:center;}
.search-wrap{position:relative;}
.search-icon{position:absolute;left:12px;top:50%;transform:translateY(-50%);color:var(--c-faint);font-size:13px;pointer-events:none;}
.search-input{
  padding:8px 14px 8px 36px;border:1px solid var(--c-border);
  border-radius:var(--r-md);background:var(--c-surface-2);
  font-size:13px;color:var(--c-text);width:260px;transition:all var(--t);
}
.search-input:focus{outline:none;border-color:var(--c-primary);background:#fff;box-shadow:0 0 0 3px rgba(37,99,235,.08);}

/* ─── Buttons ────────────────────────────────────────────────────────────── */
.btn{display:inline-flex;align-items:center;gap:6px;padding:8px 16px;border-radius:var(--r-md);font-size:13px;font-weight:700;border:none;transition:all var(--t);cursor:pointer;white-space:nowrap;}
.btn-primary    {background:var(--c-primary);color:#fff;box-shadow:0 2px 6px rgba(37,99,235,.28);}
.btn-primary:hover{background:var(--c-primary-hv);}
.btn-teal       {background:var(--c-teal);color:#fff;box-shadow:0 2px 6px rgba(13,148,136,.28);}
.btn-teal:hover {background:#0f766e;}
.btn-ghost      {background:var(--c-surface-2);color:var(--c-muted);border:1px solid var(--c-border);}
.btn-ghost:hover{background:var(--c-border);color:var(--c-text);}
.btn-icon-view  {background:var(--c-teal-lt);color:var(--c-teal);border:1px solid #5eead4;}
.btn-icon-view:hover{background:#99f6e4;}
.btn-icon-edit  {background:var(--c-primary-lt);color:var(--c-primary);border:1px solid #93c5fd;}
.btn-icon-edit:hover{background:#bfdbfe;}
.btn-icon-del   {background:var(--c-danger-lt);color:var(--c-danger);border:1px solid #fca5a5;}
.btn-icon-del:hover{background:#fecaca;}
.btn-danger-solid{background:var(--c-danger);color:#fff;box-shadow:0 2px 6px rgba(220,38,38,.28);}
.btn-danger-solid:hover{background:#b91c1c;}
.btn-sm{padding:6px 13px;font-size:12px;}
.btn-xs{padding:5px 10px;font-size:11px;border-radius:var(--r-sm);}

/* ─── Table ──────────────────────────────────────────────────────────────── */
.table-wrap{overflow-x:auto;}
table{width:100%;border-collapse:collapse;font-size:13px;}
thead th{
  padding:11px 16px;background:var(--c-surface-2);
  border-bottom:2px solid var(--c-border);
  font-size:10px;font-weight:700;text-transform:uppercase;
  letter-spacing:.08em;color:var(--c-muted);text-align:left;white-space:nowrap;
}
tbody tr{border-bottom:1px solid var(--c-border-soft);transition:background var(--t);}
tbody tr:last-child{border-bottom:none;}
tbody tr:hover{background:#f8faff;}
tbody td{padding:13px 16px;vertical-align:middle;}
.cell-name{font-weight:700;font-size:14px;color:var(--c-text);}
.cell-sub {font-size:11px;color:var(--c-muted);margin-top:2px;}
.badge{display:inline-flex;align-items:center;gap:4px;padding:3px 10px;border-radius:99px;font-size:11px;font-weight:700;}
.badge-male  {background:#dbeafe;color:#1d4ed8;}
.badge-female{background:#fce7f3;color:#be185d;}
.badge-other {background:var(--c-surface-2);color:var(--c-muted);border:1px solid var(--c-border);}
.badge-preg  {background:var(--c-teal-lt);color:var(--c-teal);}
.badge-lact  {background:var(--c-warning-lt);color:var(--c-warning);}
.badge-na    {background:var(--c-surface-2);color:var(--c-faint);border:1px solid var(--c-border);}
.med-chip{display:inline-block;background:var(--c-primary-lt);color:var(--c-primary);border:1px solid #93c5fd;border-radius:5px;padding:2px 8px;font-size:11px;font-weight:600;margin:2px 2px 2px 0;}
.dose-tag{font-weight:700;color:var(--c-teal);}
.dir-text{font-size:12px;color:var(--c-muted);max-width:200px;line-height:1.4;}
.action-group{display:flex;gap:5px;align-items:center;justify-content:center;}

/* Empty */
.empty-state{text-align:center;padding:80px 20px;}
.empty-icon{width:72px;height:72px;background:var(--c-surface-2);border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 18px;font-size:28px;color:var(--c-faint);}
.empty-state h3{font-size:16px;font-weight:700;color:var(--c-text);margin-bottom:6px;}
.empty-state p{font-size:13px;color:var(--c-muted);}

/* ─── Modal overlay ──────────────────────────────────────────────────────── */
.modal-overlay{
  display:none;position:fixed;inset:0;
  background:rgba(15,23,42,.52);backdrop-filter:blur(6px);
  z-index:600;justify-content:center;align-items:center;padding:16px;
}
.modal-overlay.open{display:flex;}
@keyframes popIn{from{opacity:0;transform:scale(.96) translateY(14px)}to{opacity:1;transform:scale(1) translateY(0)}}

.modal-close-btn{
  width:32px;height:32px;border-radius:50%;border:1px solid var(--c-border);
  background:var(--c-surface-2);color:var(--c-muted);font-size:14px;
  display:flex;align-items:center;justify-content:center;
  cursor:pointer;transition:all var(--t);flex-shrink:0;
}
.modal-close-btn:hover{background:var(--c-danger-lt);border-color:#fca5a5;color:var(--c-danger);}

/* ─── Add/Edit Patient Modal ─────────────────────────────────────────────── */
.form-modal{
  background:var(--c-surface);border-radius:var(--r-xl);
  width:800px;max-width:100%;max-height:92vh;
  display:flex;flex-direction:column;
  box-shadow:var(--sh-lg);animation:popIn .25s ease;
}
.fm-header{
  padding:22px 28px 20px;border-bottom:1px solid var(--c-border);
  display:flex;align-items:center;justify-content:space-between;flex-shrink:0;
}
.fm-title-wrap{display:flex;align-items:center;gap:13px;}
.fm-icon{
  width:44px;height:44px;border-radius:var(--r-md);
  background:linear-gradient(135deg,#14b8a6,#0d9488);
  display:flex;align-items:center;justify-content:center;
  color:#fff;font-size:18px;box-shadow:0 2px 8px rgba(13,148,136,.3);flex-shrink:0;
}
.fm-title{font-family:var(--disp);font-size:22px;color:var(--c-text);}
.fm-subtitle{font-size:12px;color:var(--c-muted);margin-top:2px;}
.fm-body{padding:26px 28px;overflow-y:auto;flex:1;}
.fm-section{margin-bottom:24px;}
.fm-section:last-child{margin-bottom:0;}
.fm-section-label{
  display:flex;align-items:center;gap:7px;
  font-size:10px;font-weight:700;text-transform:uppercase;
  letter-spacing:.1em;color:var(--c-faint);
  padding-bottom:10px;border-bottom:1px solid var(--c-border-soft);margin-bottom:16px;
}
.fm-section-label i{font-size:11px;}
.form-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;}
.span2{grid-column:span 2;}
.span3{grid-column:span 3;}
.field-label{display:block;font-size:10.5px;font-weight:700;color:var(--c-muted);text-transform:uppercase;letter-spacing:.06em;margin-bottom:5px;}
.req{color:var(--c-danger);}
.field-input,.field-textarea{
  width:100%;padding:9px 12px;border:1px solid var(--c-border);
  border-radius:var(--r-md);background:var(--c-surface-2);
  font-size:13px;color:var(--c-text);transition:all var(--t);
}
.field-input:focus,.field-textarea:focus{outline:none;border-color:var(--c-primary);box-shadow:0 0 0 3px rgba(37,99,235,.1);background:#fff;}
.field-textarea{resize:vertical;min-height:78px;line-height:1.6;}
.radio-group{display:flex;gap:6px;flex-wrap:wrap;margin-top:3px;}
.radio-pill input{display:none;}
.radio-pill label{
  display:inline-flex;align-items:center;gap:5px;
  padding:7px 15px;border:1.5px solid var(--c-border);
  border-radius:99px;font-size:12px;font-weight:600;
  color:var(--c-muted);cursor:pointer;transition:all var(--t);
}
.radio-pill label:hover{border-color:var(--c-primary);color:var(--c-primary);}
.radio-pill input:checked + label{background:var(--c-primary);border-color:var(--c-primary);color:#fff;box-shadow:0 2px 6px rgba(37,99,235,.25);}
.radio-pill.preg input:checked + label{background:var(--c-teal);border-color:var(--c-teal);box-shadow:0 2px 6px rgba(13,148,136,.25);}
.fm-footer{
  padding:18px 28px;border-top:1px solid var(--c-border);
  display:flex;align-items:center;justify-content:flex-end;gap:10px;
  flex-shrink:0;background:var(--c-surface-2);
  border-radius:0 0 var(--r-xl) var(--r-xl);
}

/* ─── View Modal ─────────────────────────────────────────────────────────── */
.view-modal{
  background:var(--c-surface);border-radius:var(--r-xl);
  width:640px;max-width:100%;max-height:88vh;
  display:flex;flex-direction:column;
  box-shadow:var(--sh-lg);animation:popIn .25s ease;
}
.vm-header{
  padding:24px 28px 20px;border-bottom:1px solid var(--c-border);
  display:flex;align-items:flex-start;justify-content:space-between;gap:12px;flex-shrink:0;
}
.vm-name{font-family:var(--disp);font-size:22px;color:var(--c-text);}
.vm-meta{font-size:11px;color:var(--c-muted);margin-top:3px;}
.vm-body{padding:24px 28px;overflow-y:auto;flex:1;}
.vm-section-label{
  font-size:10px;font-weight:700;text-transform:uppercase;
  letter-spacing:.1em;color:var(--c-teal);
  margin-bottom:12px;margin-top:4px;
  display:flex;align-items:center;gap:6px;
}
.vm-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px 28px;margin-bottom:20px;}
.vm-field label{font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.07em;color:var(--c-muted);}
.vm-field p{font-size:13px;font-weight:600;color:var(--c-text);margin-top:3px;}
.vm-field.full{grid-column:span 2;}
.vm-divider{border:none;border-top:1px dashed var(--c-border);margin:4px 0 18px;}
.vm-footer{
  padding:16px 28px;border-top:1px solid var(--c-border);
  display:flex;justify-content:flex-end;gap:10px;flex-shrink:0;
}

/* ─── Delete Modal ───────────────────────────────────────────────────────── */
.del-modal{
  background:var(--c-surface);border-radius:var(--r-xl);
  width:420px;max-width:100%;padding:32px;
  box-shadow:var(--sh-lg);animation:popIn .22s ease;text-align:center;
}
.del-icon-wrap{width:60px;height:60px;background:var(--c-danger-lt);border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 18px;font-size:24px;color:var(--c-danger);}
.del-modal h3{font-family:var(--disp);font-size:21px;color:var(--c-text);margin-bottom:8px;}
.del-modal p{font-size:13px;color:var(--c-muted);}
.del-name{font-size:15px;font-weight:700;color:var(--c-text);display:block;margin-top:6px;}
.del-warning{font-size:11.5px;color:var(--c-danger);margin-top:12px;background:var(--c-danger-lt);padding:9px 14px;border-radius:var(--r-sm);display:inline-block;width:100%;}
.del-actions{display:flex;gap:10px;margin-top:22px;}
.del-actions .btn{flex:1;justify-content:center;}

/* ─── Responsive ─────────────────────────────────────────────────────────── */
@media(max-width:1100px){.stats-row{grid-template-columns:repeat(2,1fr);}}
@media(max-width:760px){
  .form-grid{grid-template-columns:1fr 1fr;} .span3{grid-column:span 2;}
  .panel-header{flex-direction:column;align-items:flex-start;}
  .search-form{width:100%;}
  .search-input{width:100%;}
}
@media(max-width:520px){
  .form-grid{grid-template-columns:1fr;} .span2,.span3{grid-column:span 1;}
  .stats-row{grid-template-columns:1fr 1fr;}
  .page-body{padding:16px;}
  .header{padding:0 16px;}
  .fm-body,.vm-body{padding:18px 18px;}
  .fm-header,.vm-header,.fm-footer,.vm-footer{padding-left:18px;padding-right:18px;}
}
</style>
</head>
<body>

<!-- ══ HEADER ══ -->
<header class="header">
  <div class="header-left">
    <div class="logo-mark"><img src="assets/img/logo-mark.png" alt="Sari-Link"></div>
    <div>
      <div class="logo-name">Sari<span>-Link</span></div>
      <div class="logo-sub">Patient Medication Profile</div>
    </div>
  </div>
  <div class="header-right">
    <span class="nav-btn" style="cursor:default;" title="Logged in as (<?= htmlspecialchars(current_user_role()) ?>)">
      <i class="fas fa-user-circle" style="color:var(--c-primary)"></i> <?= htmlspecialchars(current_user_display()) ?>
    </span>
    <button class="nav-btn" onclick="window.location.href='index.php'">
      <i class="fas fa-arrow-left"></i> Back to POS
    </button>
    <button class="btn-add-patient" onclick="openAddModal()">
      <i class="fas fa-user-plus"></i> Add Patient
    </button>
  </div>
</header>

<!-- ══ PAGE BODY ══ -->
<div class="page-body">

  <?php if ($success_message): ?>
  <div class="alert alert-success" id="flashAlert">
    <i class="fas fa-circle-check fa-lg"></i>
    <?= htmlspecialchars($success_message) ?>
    <button class="alert-close" onclick="this.parentElement.remove()"><i class="fas fa-xmark"></i></button>
  </div>
  <?php endif; ?>
  <?php if ($error): ?>
  <div class="alert alert-error" id="flashAlert">
    <i class="fas fa-circle-exclamation fa-lg"></i>
    <?= htmlspecialchars($error) ?>
    <button class="alert-close" onclick="this.parentElement.remove()"><i class="fas fa-xmark"></i></button>
  </div>
  <?php endif; ?>

  <!-- Stats -->
  <div class="stats-row">
    <div class="stat-card">
      <div class="stat-icon si-teal"><i class="fas fa-users"></i></div>
      <div><div class="stat-val"><?= $stat_total ?></div><div class="stat-lbl">Total Patients</div></div>
    </div>
    <div class="stat-card">
      <div class="stat-icon si-blue"><i class="fas fa-mars"></i></div>
      <div><div class="stat-val"><?= $stat_male ?></div><div class="stat-lbl">Male Patients</div></div>
    </div>
    <div class="stat-card">
      <div class="stat-icon si-pink"><i class="fas fa-venus"></i></div>
      <div><div class="stat-val"><?= $stat_female ?></div><div class="stat-lbl">Female Patients</div></div>
    </div>
    <div class="stat-card">
      <div class="stat-icon si-amber"><i class="fas fa-baby"></i></div>
      <div><div class="stat-val"><?= $stat_preg ?></div><div class="stat-lbl">Pregnant / Lactating</div></div>
    </div>
  </div>

  <!-- Patient Records -->
  <div class="panel">
    <div class="panel-header">
      <div class="panel-header-left">
        <div class="panel-icon pi-blue"><i class="fas fa-list-ul"></i></div>
        <div class="panel-title">Patient Records</div>
        <span class="record-badge"><?= $total_count ?> record<?= $total_count !== 1 ? 's' : '' ?></span>
      </div>
      <form method="GET" class="search-form">
        <div class="search-wrap">
          <i class="fas fa-magnifying-glass search-icon"></i>
          <input type="text" name="search" class="search-input"
                 placeholder="Search name, contact, medication…"
                 value="<?= htmlspecialchars($search) ?>">
        </div>
        <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-search"></i> Search</button>
        <?php if ($search): ?>
        <a href="patient_medication_profile.php" class="btn btn-ghost btn-sm"><i class="fas fa-xmark"></i> Clear</a>
        <?php endif; ?>
      </form>
    </div>

    <div class="table-wrap">
      <table>
        <thead>
          <tr>
            <th style="width:40px;">#</th>
            <th>Patient</th>
            <th>Age</th>
            <th>Gender</th>
            <th>Date of Birth</th>
            <th>Contact No.</th>
            <th>Preg / Lact</th>
            <th>Allergies</th>
            <th>Medications</th>
            <th>Dose</th>
            <th>Direction</th>
            <th style="text-align:center;width:110px;">Actions</th>
          </tr>
        </thead>
        <tbody>
        <?php if ($patients && $patients->num_rows > 0):
          $i = 1;
          while ($row = $patients->fetch_assoc()):
            $gclass  = $row['gender']==='Male' ? 'badge-male' : ($row['gender']==='Female' ? 'badge-female' : 'badge-other');
            $gicon   = $row['gender']==='Male' ? 'mars' : ($row['gender']==='Female' ? 'venus' : 'genderless');
            $plval   = $row['pregnant_lactating'];
            $plclass = $plval==='Pregnant' ? 'badge-preg' : ($plval==='Lactating' ? 'badge-lact' : 'badge-na');
            $rowJson = htmlspecialchars(json_encode($row), ENT_QUOTES, 'UTF-8');
        ?>
          <tr>
            <td style="color:var(--c-faint);font-size:11px;font-weight:700;"><?= $i++ ?></td>
            <td>
              <div class="cell-name"><?= htmlspecialchars($row['patient_name']) ?></div>
              <div class="cell-sub"><i class="fas fa-location-dot" style="font-size:10px;opacity:.6;"></i> <?= htmlspecialchars($row['address']) ?></div>
            </td>
            <td style="font-weight:600;"><?= (int)$row['age'] ?></td>
            <td><span class="badge <?= $gclass ?>"><i class="fas fa-<?= $gicon ?>"></i> <?= htmlspecialchars($row['gender']) ?></span></td>
            <td style="white-space:nowrap;font-size:12px;"><?= date('M d, Y', strtotime($row['date_of_birth'])) ?></td>
            <td style="white-space:nowrap;font-size:13px;"><?= htmlspecialchars($row['contact_no']) ?></td>
            <td><span class="badge <?= $plclass ?>"><?= $plval==='N/A' ? '—' : htmlspecialchars($plval) ?></span></td>
            <td style="max-width:140px;font-size:12px;color:var(--c-danger);">
              <?= $row['allergies'] !== '' ? '<i class="fas fa-triangle-exclamation" style="margin-right:3px;"></i>'.htmlspecialchars($row['allergies']) : '<span style="color:var(--c-faint);">—</span>' ?>
            </td>
            <td style="max-width:160px;">
              <?php foreach (array_filter(array_map('trim', explode(',', $row['medications']))) as $med): ?>
              <span class="med-chip"><?= htmlspecialchars($med) ?></span>
              <?php endforeach; ?>
            </td>
            <td class="dose-tag" style="white-space:nowrap;"><?= htmlspecialchars($row['dose']) ?></td>
            <td><div class="dir-text"><?= htmlspecialchars($row['direction']) ?></div></td>
            <td>
              <div class="action-group">
                <button class="btn btn-icon-view btn-xs" onclick="openView(<?= $rowJson ?>)" title="View Details"><i class="fas fa-eye"></i></button>
                <button class="btn btn-icon-edit btn-xs" onclick="openEdit(<?= $rowJson ?>)" title="Edit Record"><i class="fas fa-pen"></i></button>
                <button class="btn btn-icon-del btn-xs" onclick="confirmDelete(<?= $row['id'] ?>, '<?= addslashes(htmlspecialchars($row['patient_name'])) ?>')" title="Delete"><i class="fas fa-trash"></i></button>
              </div>
            </td>
          </tr>
        <?php endwhile; else: ?>
          <tr><td colspan="12">
            <div class="empty-state">
              <div class="empty-icon"><i class="fas fa-folder-open"></i></div>
              <h3>No patient records found</h3>
              <p><?= $search ? 'No results for "<strong>'.htmlspecialchars($search).'</strong>". Try a different keyword.' : 'Click <strong>Add Patient</strong> to create the first record.' ?></p>
            </div>
          </td></tr>
        <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

</div><!-- /page-body -->


<!-- ══════════════════════════════════════════════════════
     ADD / EDIT PATIENT MODAL
══════════════════════════════════════════════════════ -->
<div class="modal-overlay" id="formModal">
  <div class="form-modal">

    <div class="fm-header">
      <div class="fm-title-wrap">
        <div class="fm-icon"><i class="fas fa-user-plus" id="fmIcon"></i></div>
        <div>
          <div class="fm-title" id="fmTitle">Add New Patient</div>
          <div class="fm-subtitle" id="fmSubtitle">Fill in all required fields to save the profile.</div>
        </div>
      </div>
      <button class="modal-close-btn" onclick="closeModal('formModal')"><i class="fas fa-xmark"></i></button>
    </div>

    <div class="fm-body">
      <form method="POST" id="patientForm" autocomplete="off">
        <input type="hidden" name="save_patient" value="1">
        <input type="hidden" name="edit_id" id="fm_edit_id" value="0">

        <!-- Personal Information -->
        <div class="fm-section">
          <div class="fm-section-label"><i class="fas fa-user"></i> Personal Information</div>
          <div class="form-grid">
            <div class="span2">
              <label class="field-label">Patient Name <span class="req">*</span></label>
              <input type="text" name="patient_name" id="fm_patient_name" class="field-input" placeholder="Full name" required>
            </div>
            <div>
              <label class="field-label">Age <span class="req">*</span></label>
              <input type="number" name="age" id="fm_age" class="field-input" placeholder="e.g. 35" min="0" max="150" required>
            </div>
            <div class="span3">
              <label class="field-label">Address <span class="req">*</span></label>
              <input type="text" name="address" id="fm_address" class="field-input" placeholder="Complete address" required>
            </div>
            <div>
              <label class="field-label">Contact No. <span class="req">*</span></label>
              <input type="text" name="contact_no" id="fm_contact_no" class="field-input" placeholder="09XX-XXX-XXXX" required>
            </div>
            <div>
              <label class="field-label">Date of Birth <span class="req">*</span></label>
              <input type="date" name="date_of_birth" id="fm_date_of_birth" class="field-input" required>
            </div>
            <div>
              <label class="field-label">Pregnant / Lactating</label>
              <div class="radio-group" style="margin-top:6px;">
                <?php foreach (['N/A','Pregnant','Lactating'] as $opt): ?>
                <span class="radio-pill preg">
                  <input type="radio" name="pregnant_lactating" id="fm_pl_<?= $opt ?>" value="<?= $opt ?>" <?= $opt==='N/A'?'checked':'' ?>>
                  <label for="fm_pl_<?= $opt ?>"><?= $opt ?></label>
                </span>
                <?php endforeach; ?>
              </div>
            </div>
            <div class="span3">
              <label class="field-label">Gender <span class="req">*</span></label>
              <div class="radio-group" style="margin-top:6px;">
                <?php foreach (['Male','Female','Other'] as $g): ?>
                <span class="radio-pill">
                  <input type="radio" name="gender" id="fm_g_<?= $g ?>" value="<?= $g ?>" required>
                  <label for="fm_g_<?= $g ?>"><i class="fas fa-<?= $g==='Male'?'mars':($g==='Female'?'venus':'genderless') ?>"></i> <?= $g ?></label>
                </span>
                <?php endforeach; ?>
              </div>
            </div>
          </div>
        </div>

        <!-- Medication Details -->
        <div class="fm-section">
          <div class="fm-section-label"><i class="fas fa-pills"></i> Medication Details</div>
          <div class="form-grid">
            <div class="span3">
              <label class="field-label"><i class="fas fa-triangle-exclamation" style="color:var(--c-danger);margin-right:3px;"></i> Allergies</label>
              <input type="text" name="allergies" id="fm_allergies" class="field-input" placeholder="e.g. Penicillin, Sulfa drugs, Aspirin (or leave blank if none)">
            </div>
            <div class="span3">
              <label class="field-label">List of Medications <span class="req">*</span></label>
              <textarea name="medications" id="fm_medications" class="field-textarea" placeholder="e.g. Metformin, Amlodipine, Losartan  (separate with commas)" required></textarea>
            </div>
            <div>
              <label class="field-label">Dose <span class="req">*</span></label>
              <input type="text" name="dose" id="fm_dose" class="field-input" placeholder="e.g. 500mg, 5mg" required>
            </div>
            <div class="span2">
              <label class="field-label">Direction <span class="req">*</span></label>
              <input type="text" name="direction" id="fm_direction" class="field-input" placeholder="e.g. 1 tablet twice daily after meals" required>
            </div>
          </div>
        </div>

      </form>
    </div>

    <div class="fm-footer">
      <button class="btn btn-ghost" onclick="closeModal('formModal')"><i class="fas fa-xmark"></i> Cancel</button>
      <button class="btn btn-teal" onclick="document.getElementById('patientForm').submit()">
        <i class="fas fa-floppy-disk"></i> <span id="fmBtnLabel">Save Profile</span>
      </button>
    </div>

  </div>
</div>


<!-- ══════════════════════════════════════════════════════
     VIEW PATIENT MODAL
══════════════════════════════════════════════════════ -->
<div class="modal-overlay" id="viewModal">
  <div class="view-modal">
    <div class="vm-header">
      <div>
        <div class="vm-name" id="vmName">—</div>
        <div class="vm-meta" id="vmMeta"></div>
      </div>
      <button class="modal-close-btn" onclick="closeModal('viewModal')"><i class="fas fa-xmark"></i></button>
    </div>
    <div class="vm-body" id="vmBody"></div>
    <div class="vm-footer">
      <button class="btn btn-ghost" onclick="closeModal('viewModal')"><i class="fas fa-xmark"></i> Close</button>
      <button class="btn btn-icon-edit" id="vmEditBtn">
        <i class="fas fa-pen"></i> Edit Record
      </button>
    </div>
  </div>
</div>


<!-- ══════════════════════════════════════════════════════
     DELETE CONFIRM MODAL
══════════════════════════════════════════════════════ -->
<div class="modal-overlay" id="deleteModal">
  <div class="del-modal">
    <div class="del-icon-wrap"><i class="fas fa-trash-can"></i></div>
    <h3>Delete Record</h3>
    <p>You are about to permanently delete the profile of</p>
    <span class="del-name" id="delPatientName">—</span>
    <div class="del-warning"><i class="fas fa-triangle-exclamation"></i> This action cannot be undone.</div>
    <div class="del-actions">
      <button class="btn btn-ghost" onclick="closeModal('deleteModal')"><i class="fas fa-xmark"></i> Cancel</button>
      <form method="POST" style="flex:1;display:flex;">
        <input type="hidden" name="delete_id" id="delId">
        <button type="submit" class="btn btn-danger-solid" style="flex:1;justify-content:center;">
          <i class="fas fa-trash"></i> Yes, Delete
        </button>
      </form>
    </div>
  </div>
</div>


<script>
let _viewRow = null;

/* ── Modal helpers ─────────────────────────────────────────────────────── */
function closeModal(id) { document.getElementById(id).classList.remove('open'); }

document.querySelectorAll('.modal-overlay').forEach(m => {
  m.addEventListener('click', e => { if (e.target === m) m.classList.remove('open'); });
});
document.addEventListener('keydown', e => {
  if (e.key === 'Escape')
    document.querySelectorAll('.modal-overlay.open').forEach(m => m.classList.remove('open'));
});

/* ── Open ADD modal ────────────────────────────────────────────────────── */
function openAddModal() {
  document.getElementById('patientForm').reset();
  document.getElementById('fm_edit_id').value = '0';
  document.getElementById('fm_allergies').value = '';
  document.getElementById('fm_pl_N/A').checked = true;
  document.getElementById('fmTitle').textContent    = 'Add New Patient';
  document.getElementById('fmSubtitle').textContent = 'Fill in all required fields to save the profile.';
  document.getElementById('fmIcon').className       = 'fas fa-user-plus';
  document.getElementById('fmBtnLabel').textContent = 'Save Profile';
  document.getElementById('formModal').classList.add('open');
  setTimeout(() => document.getElementById('fm_patient_name').focus(), 200);
}

/* ── Open EDIT modal ───────────────────────────────────────────────────── */
function openEdit(row) {
  _viewRow = row;
  document.getElementById('fm_edit_id').value        = row.id;
  document.getElementById('fm_patient_name').value   = row.patient_name;
  document.getElementById('fm_age').value             = row.age;
  document.getElementById('fm_address').value         = row.address;
  document.getElementById('fm_contact_no').value      = row.contact_no;
  document.getElementById('fm_date_of_birth').value   = row.date_of_birth;
  document.getElementById('fm_medications').value     = row.medications;
  document.getElementById('fm_allergies').value       = row.allergies || '';
  document.getElementById('fm_dose').value            = row.dose;
  document.getElementById('fm_direction').value       = row.direction;
  document.querySelectorAll('input[name="gender"]').forEach(r => r.checked = (r.value === row.gender));
  document.querySelectorAll('input[name="pregnant_lactating"]').forEach(r => r.checked = (r.value === row.pregnant_lactating));
  document.getElementById('fmTitle').textContent     = 'Edit Patient Record';
  document.getElementById('fmSubtitle').textContent  = 'Update the information below then save.';
  document.getElementById('fmIcon').className        = 'fas fa-pen-to-square';
  document.getElementById('fmBtnLabel').textContent  = 'Update Record';
  document.getElementById('formModal').classList.add('open');
  setTimeout(() => document.getElementById('fm_patient_name').focus(), 200);
}

/* ── Open VIEW modal ───────────────────────────────────────────────────── */
function openView(row) {
  _viewRow = row;
  document.getElementById('vmName').textContent = row.patient_name;
  document.getElementById('vmMeta').textContent = 'Date Added: ' + row.created_at;

  const pl   = row.pregnant_lactating === 'N/A' ? '—' : row.pregnant_lactating;
  const meds = row.medications.split(',').map(m => `<span class="med-chip">${m.trim()}</span>`).join('');
  const gIconMap = {Male:'mars', Female:'venus', Other:'genderless'};

  document.getElementById('vmBody').innerHTML = `
    <div class="vm-section-label"><i class="fas fa-user"></i> Personal Information</div>
    <div class="vm-grid">
      <div class="vm-field"><label>Patient Name</label><p>${row.patient_name}</p></div>
      <div class="vm-field"><label>Age</label><p>${row.age} years old</p></div>
      <div class="vm-field full"><label>Address</label><p>${row.address}</p></div>
      <div class="vm-field"><label>Contact No.</label><p>${row.contact_no}</p></div>
      <div class="vm-field"><label>Gender</label><p><i class="fas fa-${gIconMap[row.gender]||'genderless'}" style="margin-right:4px;opacity:.6;"></i>${row.gender}</p></div>
      <div class="vm-field"><label>Date of Birth</label><p>${row.date_of_birth}</p></div>
      <div class="vm-field"><label>Pregnant / Lactating</label><p>${pl}</p></div>
    </div>
    <hr class="vm-divider">
    <div class="vm-section-label"><i class="fas fa-pills"></i> Medication Details</div>
    <div class="vm-grid">
      <div class="vm-field full"><label><i class="fas fa-triangle-exclamation" style="color:var(--c-danger);margin-right:3px;"></i> Allergies</label><p style="color:${row.allergies ? 'var(--c-danger)' : 'var(--c-faint)'};">${row.allergies || '—'}</p></div>
      <div class="vm-field full"><label>Medications</label><p style="margin-top:6px;line-height:2.2;">${meds}</p></div>
      <div class="vm-field"><label>Dose</label><p style="color:var(--c-teal);">${row.dose}</p></div>
      <div class="vm-field"><label>Direction</label><p>${row.direction}</p></div>
    </div>
  `;

  document.getElementById('vmEditBtn').onclick = () => {
    closeModal('viewModal');
    openEdit(row);
  };

  document.getElementById('viewModal').classList.add('open');
}

/* ── Delete confirm ────────────────────────────────────────────────────── */
function confirmDelete(id, name) {
  document.getElementById('delId').value = id;
  document.getElementById('delPatientName').textContent = name;
  document.getElementById('deleteModal').classList.add('open');
}

/* ── Auto-open edit modal from URL ?edit= ──────────────────────────────── */
const _editData = <?= $edit_json ?>;
if (_editData) document.addEventListener('DOMContentLoaded', () => openEdit(_editData));

/* ── Auto-dismiss flash alert ──────────────────────────────────────────── */
const _fa = document.getElementById('flashAlert');
if (_fa) {
  setTimeout(() => { _fa.style.transition = 'opacity .5s'; _fa.style.opacity = '0'; setTimeout(() => _fa.remove(), 500); }, 4000);
}
</script>
</body>
</html>