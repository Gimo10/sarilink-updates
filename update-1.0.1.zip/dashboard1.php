<?php date_default_timezone_set('Asia/Manila'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Sales Dashboard — Sari-Link</title>
<link href="assets/css/fonts.css" rel="stylesheet">
<link href="assets/css/fontawesome.min.css" rel="stylesheet">
<link rel="shortcut icon" href="Sari-Link.ico" type="image/x-icon">
<style>
:root{
    --c-bg:#eef2f8;--c-surface:#ffffff;--c-surface-2:#f6f8fb;
    --c-border:#e2e8f2;--c-border-soft:#edf1f7;
    --c-primary:#2563eb;--c-primary-dk:#1e40af;--c-primary-lt:#dbeafe;--c-primary-hv:#1d4ed8;
    --c-success:#059669;--c-success-lt:#d1fae5;
    --c-warning:#d97706;--c-warning-lt:#fef3c7;
    --c-danger:#dc2626;--c-danger-lt:#fee2e2;
    --c-purple:#7c3aed;--c-purple-lt:#ede9fe;
    --c-text:#0f172a;--c-muted:#57647c;--c-faint:#8695ab;
    --r-sm:8px;--r-md:12px;--r-lg:18px;--r-xl:24px;
    --sh-xs:0 1px 2px rgba(15,23,42,.05);
    --sh-sm:0 2px 6px rgba(15,23,42,.06),0 1px 2px rgba(15,23,42,.04);
    --sh-md:0 8px 24px rgba(15,23,42,.08),0 2px 6px rgba(15,23,42,.04);
    --sh-lg:0 20px 48px rgba(15,23,42,.14),0 4px 12px rgba(15,23,42,.06);
    --font:'DM Sans',sans-serif;--disp:'Playfair Display',serif;
    --t:180ms ease;--sw:278px;
}
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box;}
body{font-family:var(--font);background:var(--c-bg);color:var(--c-text);line-height:1.6;min-height:100vh;display:flex;}
a{text-decoration:none;color:inherit;}
button{font-family:inherit;cursor:pointer;}
input,select,textarea{font-family:inherit;}
::-webkit-scrollbar{width:5px;height:5px;}
::-webkit-scrollbar-thumb{background:var(--c-border);border-radius:99px;}

.sidebar{width:var(--sw);background:var(--c-surface);border-right:1px solid var(--c-border);height:100vh;position:fixed;left:0;top:0;display:flex;flex-direction:column;box-shadow:var(--sh-xs);overflow-y:auto;z-index:100;}
.sb-top{padding:22px 22px 18px;border-bottom:1px solid var(--c-border);}
.logo-wrap{display:flex;align-items:center;gap:11px;margin-bottom:16px;user-select:none;}
.logo-mark{width:42px;height:42px;background:linear-gradient(135deg,#eef4ff,#dce9fb);border-radius:var(--r-md);display:flex;align-items:center;justify-content:center;color:#fff;font-size:16px;flex-shrink:0;cursor:pointer;transition:transform .15s;padding:7px;box-shadow:inset 0 0 0 1px rgba(37,99,235,.10);}
.logo-mark img{width:100%;height:100%;object-fit:contain;pointer-events:none;}
.logo-mark:active{transform:scale(.9);}
.logo-name{font-family:var(--disp);font-size:20px;line-height:1.15;}
.logo-name span{color:var(--c-primary);}
.logo-sub{font-size:11px;color:var(--c-muted);}
.grand-card{background:linear-gradient(135deg,var(--c-primary),#1d4ed8);border-radius:var(--r-lg);padding:18px 20px;color:#fff;box-shadow:0 8px 20px rgba(37,99,235,.25);}
.gc-label{font-size:10.5px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;opacity:.75;margin-bottom:3px;}
.gc-val{font-size:24px;line-height:1.1;font-weight:800;}
.sb-body{padding:18px 22px;flex:1;display:flex;flex-direction:column;gap:28px;}
.sb-sec-title{font-size:10.5px;font-weight:700;color:var(--c-muted);text-transform:uppercase;letter-spacing:.07em;margin-bottom:8px;}
.stat-pill{display:flex;align-items:center;gap:11px;background:var(--c-surface-2);border:1px solid var(--c-border-soft);border-radius:var(--r-md);padding:11px 13px;}
.stat-pill+.stat-pill{margin-top:7px;}
.spi{width:36px;height:36px;border-radius:var(--r-md);display:flex;align-items:center;justify-content:center;color:#fff;font-size:14px;flex-shrink:0;}
.spi-green{background:linear-gradient(135deg,#10b981,#059669);}
.spi-purple{background:linear-gradient(135deg,#8b5cf6,#7c3aed);}
.spi-amber{background:linear-gradient(135deg,#f59e0b,#d97706);}
.sp-val{font-size:16px;font-weight:700;color:var(--c-text);line-height:1.1;}
.sp-lbl{font-size:11px;color:var(--c-muted);}
.spi-blue{background:linear-gradient(135deg,#3b82f6,#1d4ed8);}
/* Cash / E-Pay toggle card */
.pay-toggle{cursor:pointer;user-select:none;transition:box-shadow var(--t),transform var(--t);}
.pay-toggle:hover{box-shadow:var(--sh-sm);transform:translateY(-1px);}
.pay-toggle:active{transform:scale(.98);}
.pay-toggle:focus-visible{outline:2px solid var(--c-primary);outline-offset:2px;}
.pay-toggle .pay-swap{margin-left:auto;font-size:12px;color:var(--c-faint);transition:transform .35s ease;}
.pay-toggle.epay .pay-swap{transform:rotate(180deg);}
.pay-toggle .sp-lbl small{color:var(--c-faint);}
.td-pay{display:inline-block;margin-left:7px;padding:1px 7px;border-radius:99px;font-size:9.5px;font-weight:700;letter-spacing:.05em;vertical-align:middle;}
.td-pay-cash{background:#e0f2fe;color:#0369a1;border:1px solid #7dd3fc;}
.td-pay-epay{background:#ede9fe;color:#6d28d9;border:1px solid #c4b5fd;}
.tod-row{display:flex;align-items:center;gap:9px;}
.tod-row+.tod-row{margin-top:9px;}
.tod-icon{width:28px;height:28px;border-radius:var(--r-sm);display:flex;align-items:center;justify-content:center;font-size:12px;flex-shrink:0;}
.tod-icon.mor{background:var(--c-warning-lt);color:var(--c-warning);}
.tod-icon.aft{background:#cffafe;color:#0891b2;}
.tod-icon.eve{background:var(--c-purple-lt);color:var(--c-purple);}
.tod-lbl{font-size:11px;font-weight:600;color:var(--c-muted);width:64px;}
.tod-track{flex:1;height:8px;background:var(--c-border);border-radius:99px;overflow:hidden;}
.tod-fill{height:100%;border-radius:99px;}
.tod-fill.mor{background:linear-gradient(to right,#f59e0b,#d97706);}
.tod-fill.aft{background:linear-gradient(to right,#22d3ee,#0891b2);}
.tod-fill.eve{background:linear-gradient(to right,#8b5cf6,#6d28d9);}
.tod-pct{font-size:10px;font-weight:700;color:var(--c-muted);width:28px;text-align:right;}
.tp-mini{display:flex;align-items:center;gap:8px;padding:6px 0;border-bottom:1px solid var(--c-border-soft);}
.tp-mini:last-child{border-bottom:none;}
.tp-mini-rank{width:20px;height:20px;border-radius:50%;color:#fff;display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:800;flex-shrink:0;}
.tp-mini-name{flex:1;font-size:12px;font-weight:600;color:var(--c-text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.tp-mini-rev{font-size:11px;font-weight:700;color:var(--c-success);flex-shrink:0;}
.sb-footer{padding:14px 20px 18px;border-top:1px solid var(--c-border);margin-top:auto;}
.sb-btn{display:flex;align-items:center;gap:9px;padding:9px 13px;border-radius:var(--r-md);font-size:13px;font-weight:600;border:1px solid var(--c-border);background:var(--c-surface-2);color:var(--c-muted);cursor:pointer;transition:all var(--t);text-decoration:none;}
.sb-btn:hover{background:var(--c-primary-lt);color:var(--c-primary);border-color:var(--c-primary);}

.main{margin-left:var(--sw);width:calc(100% - var(--sw));display:flex;flex-direction:column;min-height:100vh;}
.topbar{background:var(--c-surface);border-bottom:1px solid var(--c-border);height:72px;padding:0 28px;display:flex;align-items:center;justify-content:space-between;gap:12px;position:sticky;top:0;z-index:50;box-shadow:var(--sh-xs);}
.tb-left{display:flex;align-items:center;gap:10px;}
.tb-title{font-family:var(--disp);font-size:20px;}
.tb-pill{display:inline-flex;align-items:center;gap:5px;background:var(--c-danger-lt);color:var(--c-danger);border:1px solid #fca5a5;border-radius:99px;font-size:11px;font-weight:700;padding:4px 11px;}
.live-clock{display:flex;align-items:center;gap:7px;background:var(--c-surface-2);border:1px solid var(--c-border);border-radius:var(--r-md);padding:6px 12px;font-size:13px;font-weight:700;color:var(--c-text);}
.live-clock i{color:var(--c-primary);font-size:12px;}
.clock-date{font-size:10px;font-weight:500;color:var(--c-muted);border-left:1px solid var(--c-border);padding-left:7px;margin-left:3px;}
.page-body{padding:24px 28px;flex:1;display:flex;flex-direction:column;gap:18px;}

.btn{display:inline-flex;align-items:center;justify-content:center;gap:6px;border:none;border-radius:var(--r-md);font-family:inherit;font-weight:600;cursor:pointer;transition:all var(--t);font-size:13px;}
.btn-sm{padding:6px 12px;font-size:12px;}
.btn-md{padding:8px 15px;}
.btn-ghost{background:var(--c-surface-2);color:var(--c-muted);border:1px solid var(--c-border);}
.btn-ghost:hover{background:var(--c-primary-lt);color:var(--c-primary);border-color:var(--c-primary);}
.btn-warning{background:var(--c-warning);color:#fff;}
.btn-warning:hover{background:#b45309;}
.btn-primary{background:var(--c-primary);color:#fff;}
.btn-primary:hover{background:var(--c-primary-hv);}
.btn-success{background:var(--c-success);color:#fff;}
.btn-success:hover{background:#047857;}
.btn-danger{background:var(--c-danger);color:#fff;}
.btn-danger:hover{background:#b91c1c;}

.panel{background:var(--c-surface);border:1px solid var(--c-border);border-radius:var(--r-lg);box-shadow:var(--sh-xs);overflow:hidden;}
.panel-head{padding:16px 22px 15px;border-bottom:1px solid var(--c-border-soft);display:flex;align-items:center;gap:11px;flex-wrap:wrap;}
.panel-icon{width:34px;height:34px;border-radius:var(--r-md);display:flex;align-items:center;justify-content:center;color:#fff;font-size:13px;flex-shrink:0;}
.pi-blue{background:linear-gradient(135deg,#3b82f6,#1d4ed8);}
.pi-slate{background:linear-gradient(135deg,#64748b,#475569);}
.pi-teal{background:linear-gradient(135deg,#14b8a6,#0d9488);}
.panel-title{font-size:14px;font-weight:700;color:var(--c-text);}
.panel-acts{margin-left:auto;display:flex;gap:7px;flex-wrap:wrap;align-items:center;}

.chart-panel{background:var(--c-surface);border:1px solid var(--c-border);border-radius:var(--r-lg);box-shadow:var(--sh-xs);overflow:hidden;}
.chart-head{padding:13px 20px;border-bottom:1px solid var(--c-border-soft);display:flex;align-items:center;gap:10px;flex-wrap:wrap;}
.chart-head-left{display:flex;align-items:center;gap:10px;flex:1;}
.chart-head-right{display:flex;align-items:center;gap:14px;flex-shrink:0;}
.chart-meta-item{font-size:12px;color:var(--c-muted);}
.chart-meta-item strong{color:var(--c-text);font-weight:700;}
.chart-inner{padding:20px 20px 14px;}
#fakeChart{display:block;width:100%;height:220px;}
.chart-x-labels{display:flex;margin-top:5px;}
.chart-x-label{flex:1;text-align:center;font-size:9px;color:var(--c-faint);font-weight:600;}
.chart-legend{display:flex;align-items:center;gap:16px;margin-top:12px;padding-top:12px;border-top:1px solid var(--c-border-soft);}
.legend-dot{width:8px;height:8px;border-radius:50%;flex-shrink:0;}
.legend-item{display:flex;align-items:center;gap:6px;font-size:12px;color:var(--c-muted);}

.table-wrap{overflow-x:auto;}
table{width:100%;border-collapse:collapse;}
thead th{background:var(--c-surface-2);color:var(--c-muted);font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;padding:12px 16px;border-bottom:1px solid var(--c-border);white-space:nowrap;text-align:left;}
tbody td{padding:13px 16px;border-bottom:1px solid var(--c-border-soft);font-size:13.5px;vertical-align:middle;}
tbody tr:last-child td{border-bottom:none;}
tbody tr:hover{background:var(--c-surface-2);}
.td-name{font-weight:600;color:var(--c-text);}
.qty-badge{display:inline-block;background:var(--c-primary-lt);color:var(--c-primary);border-radius:99px;padding:2px 10px;font-size:12px;font-weight:700;}
.td-price{font-weight:700;color:var(--c-success);}
.td-date{color:var(--c-muted);font-size:12.5px;}
.empty-state{text-align:center;padding:36px 20px;}
.empty-icon{width:54px;height:54px;background:var(--c-surface-2);border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 12px;font-size:20px;color:var(--c-faint);}

.pagination{display:flex;justify-content:center;gap:4px;padding:14px 0;}
.pagination button{display:inline-flex;align-items:center;justify-content:center;min-width:34px;height:34px;padding:0 8px;border-radius:var(--r-md);font-size:13px;border:1px solid var(--c-border);background:var(--c-surface-2);color:var(--c-muted);cursor:pointer;transition:all var(--t);}
.pagination button:hover{background:var(--c-primary-lt);color:var(--c-primary);border-color:var(--c-primary);}
.pagination button.active{background:var(--c-primary);color:#fff;font-weight:700;border-color:var(--c-primary);}
.pagination button:disabled{opacity:.4;cursor:default;}

.tab-nav{display:flex;align-items:center;gap:6px;background:var(--c-surface-2);border:1px solid var(--c-border);border-radius:var(--r-lg);padding:5px;}
.tab-btn{display:inline-flex;align-items:center;gap:7px;padding:8px 18px;border-radius:var(--r-md);font-size:13px;font-weight:600;color:var(--c-muted);background:transparent;border:none;cursor:pointer;transition:all var(--t);}
.tab-btn.active{background:var(--c-surface);color:var(--c-primary);box-shadow:var(--sh-xs);border:1px solid var(--c-border);}
.tab-btn i{font-size:13px;}
.page-section{display:none;}
.page-section.active{display:flex;flex-direction:column;gap:16px;}

/* MANAGER MODAL */
.mgr-overlay{display:none;position:fixed;inset:0;background:rgba(15,23,42,.6);backdrop-filter:blur(7px);z-index:9000;align-items:center;justify-content:center;}
.mgr-overlay.open{display:flex;}
.mgr-box{background:var(--c-surface);border-radius:var(--r-xl);width:740px;max-width:96%;max-height:90vh;display:flex;flex-direction:column;position:relative;box-shadow:var(--sh-lg);animation:mgrIn .22s ease;}
@keyframes mgrIn{from{opacity:0;transform:scale(.95) translateY(14px)}to{opacity:1;transform:none}}
.mgr-head{padding:20px 24px 16px;border-bottom:1px solid var(--c-border);display:flex;align-items:center;gap:12px;flex-shrink:0;}
.mgr-head-icon{width:40px;height:40px;background:linear-gradient(135deg,#1e3a5f,#2563eb);border-radius:var(--r-lg);display:flex;align-items:center;justify-content:center;color:#fff;font-size:16px;flex-shrink:0;}
.mgr-title{font-family:var(--disp);font-size:20px;}
.mgr-sub{font-size:11.5px;color:var(--c-muted);}
.mgr-close{position:absolute;top:14px;right:14px;background:var(--c-surface-2);border:none;width:30px;height:30px;border-radius:50%;font-size:14px;color:var(--c-muted);display:flex;align-items:center;justify-content:center;transition:all var(--t);cursor:pointer;}
.mgr-close:hover{background:var(--c-danger-lt);color:var(--c-danger);}
.mgr-body{flex:1;overflow-y:auto;padding:0 24px 24px;}

.mgr-tabs{display:flex;gap:0;border-bottom:1px solid var(--c-border);position:sticky;top:0;background:var(--c-surface);z-index:2;padding-top:4px;}
.mgr-tab{padding:10px 18px;font-size:13px;font-weight:600;color:var(--c-muted);background:none;border:none;border-bottom:2px solid transparent;cursor:pointer;transition:all var(--t);margin-bottom:-1px;display:flex;align-items:center;gap:7px;}
.mgr-tab.active{color:var(--c-primary);border-bottom-color:var(--c-primary);}
.mgr-sec{display:none;padding-top:18px;}
.mgr-sec.active{display:block;}

.field-group{margin-bottom:13px;}
.field-label{display:block;font-size:11px;font-weight:700;color:var(--c-muted);text-transform:uppercase;letter-spacing:.06em;margin-bottom:5px;}
.field-input{width:100%;padding:9px 12px;border:1.5px solid var(--c-border);border-radius:var(--r-md);font-size:14px;color:var(--c-text);background:var(--c-surface-2);transition:border-color var(--t),box-shadow var(--t);}
.field-input:focus{outline:none;border-color:var(--c-primary);box-shadow:0 0 0 3px rgba(37,99,235,.1);background:#fff;}
.field-row{display:grid;grid-template-columns:1fr 1fr;gap:12px;}

.prod-form-wrap{background:var(--c-surface-2);border:1px solid var(--c-border);border-radius:var(--r-lg);padding:16px;margin-bottom:14px;display:none;}
.prod-form-title{font-size:12px;font-weight:700;color:var(--c-primary);text-transform:uppercase;letter-spacing:.06em;margin-bottom:12px;}
.prod-list{display:flex;flex-direction:column;gap:8px;max-height:300px;overflow-y:auto;}
.prod-card{background:var(--c-surface);border:1px solid var(--c-border);border-radius:var(--r-md);padding:11px 14px;display:flex;align-items:center;gap:12px;}
.prod-card:hover{box-shadow:var(--sh-xs);}
.prod-info{flex:1;min-width:0;}
.prod-name{font-size:13.5px;font-weight:700;color:var(--c-text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.prod-meta{font-size:11.5px;color:var(--c-muted);margin-top:1px;}
.prod-acts{display:flex;gap:6px;}
.icon-btn{width:30px;height:30px;border-radius:var(--r-sm);border:none;display:flex;align-items:center;justify-content:center;font-size:13px;cursor:pointer;transition:all var(--t);}
.icon-btn.edit{background:var(--c-primary-lt);color:var(--c-primary);}
.icon-btn.edit:hover{background:#bfdbfe;}
.icon-btn.del{background:var(--c-danger-lt);color:var(--c-danger);}
.icon-btn.del:hover{background:#fecaca;}

.sum-cards{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-bottom:16px;}
.sum-card{background:var(--c-surface-2);border:1px solid var(--c-border);border-radius:var(--r-lg);padding:12px 14px;text-align:center;}
.sum-lbl{font-size:10px;font-weight:700;color:var(--c-muted);text-transform:uppercase;letter-spacing:.06em;margin-bottom:4px;}
.sum-val{font-size:19px;font-weight:800;}

.txn-card{background:var(--c-surface-2);border:1px solid var(--c-border);border-radius:var(--r-md);padding:9px 12px;display:flex;align-items:center;gap:10px;}
.txn-card:hover{box-shadow:var(--sh-xs);}
.txn-info{flex:1;min-width:0;}
.txn-name{font-size:13px;font-weight:700;color:var(--c-text);}
.txn-meta{font-size:11px;color:var(--c-muted);}

/* Toast */
.toast-stack{position:fixed;top:18px;right:18px;z-index:99999;display:flex;flex-direction:column;gap:8px;pointer-events:none;}
.toast{display:flex;align-items:center;gap:10px;background:var(--c-surface);border:1px solid var(--c-border);border-radius:var(--r-md);padding:11px 15px;box-shadow:var(--sh-md);font-size:14px;font-weight:500;min-width:210px;animation:toastIn .22s ease;position:relative;overflow:hidden;}
@keyframes toastIn{from{opacity:0;transform:translateX(20px)}to{opacity:1;transform:none}}
.toast.ok .ti{color:var(--c-success);}
.toast.err .ti{color:var(--c-danger);}
.toast-bar{position:absolute;bottom:0;left:0;height:3px;animation:shrink 3s linear forwards;}
.toast.ok .toast-bar{background:var(--c-success);}
.toast.err .toast-bar{background:var(--c-danger);}
@keyframes shrink{from{width:100%}to{width:0}}

.menu-toggle{display:none;}
@media(max-width:860px){
    :root{--sw:0px;}
    .sidebar{transform:translateX(-270px);transition:transform .3s;width:270px;}
    .sidebar.open{transform:translateX(0);}
    .main{margin-left:0;width:100%;}
    .menu-toggle{display:flex!important;}
    .field-row{grid-template-columns:1fr;}
    .sum-cards{grid-template-columns:1fr 1fr;}
}
@media(max-width:600px){
    .page-body{padding:14px;}
    .topbar{padding:0 14px;}
    .clock-date{display:none;}
    .chart-head-right{display:none;}
}
</style>
</head>
<body>

<div class="toast-stack" id="toastStack"></div>

<aside class="sidebar" id="sidebar">
    <div class="sb-top">
        <div class="logo-wrap">
            <div class="logo-mark" id="logoMark" ondblclick="openManager()" title="Sari-Link">
                <img src="assets/img/logo-mark.png" alt="Sari-Link">
            </div>
            <div>
                <div class="logo-name">Sari<span>-Link</span></div>
                <div class="logo-sub">Sales Dashboard</div>
            </div>
        </div>
        <div class="grand-card">
            <div class="gc-label">Grand Total Revenue</div>
            <div class="gc-val" id="sbGrand">₱0.00</div>
        </div>
    </div>
    <div class="sb-body">
        <div>
            <div class="sb-sec-title">Summary</div>
            <div class="stat-pill"><div class="spi spi-green"><i class="fas fa-peso-sign"></i></div><div><div class="sp-val" id="sbTotal">₱0.00</div><div class="sp-lbl">Total Sales</div></div></div>
            <div class="stat-pill pay-toggle" id="payToggleCard" role="button" tabindex="0" title="Click to switch between Cash and E-Pay">
                <div class="spi spi-blue" id="payToggleIcon"><i class="fas fa-money-bill-wave" id="payToggleIconI"></i></div>
                <div style="min-width:0">
                    <div class="sp-val" id="payToggleVal">₱0.00</div>
                    <div class="sp-lbl"><span id="payToggleLbl">Total Cash</span> <small id="payToggleCnt">· 0 txn</small></div>
                </div>
                <div class="pay-swap"><i class="fas fa-rotate"></i></div>
            </div>
            <div class="stat-pill"><div class="spi spi-purple"><i class="fas fa-calendar-day"></i></div><div><div class="sp-val" id="sbToday">₱0.00</div><div class="sp-lbl">Today's Sales</div></div></div>
            <div class="stat-pill"><div class="spi spi-amber"><i class="fas fa-list-check"></i></div><div><div class="sp-val" id="sbTxns">0</div><div class="sp-lbl">Transactions</div></div></div>
        </div>
        <div>
            <div class="sb-sec-title">Sales by Time of Day</div>
            <div class="tod-row"><div class="tod-icon mor"><i class="fas fa-sun"></i></div><div class="tod-lbl">Morning</div><div class="tod-track"><div class="tod-fill mor" id="morBar" style="width:0%"></div></div><div class="tod-pct" id="morPct">0%</div></div>
            <div class="tod-row"><div class="tod-icon aft"><i class="fas fa-cloud-sun"></i></div><div class="tod-lbl">Afternoon</div><div class="tod-track"><div class="tod-fill aft" id="aftBar" style="width:0%"></div></div><div class="tod-pct" id="aftPct">0%</div></div>
            <div class="tod-row"><div class="tod-icon eve"><i class="fas fa-moon"></i></div><div class="tod-lbl">Evening</div><div class="tod-track"><div class="tod-fill eve" id="eveBar" style="width:0%"></div></div><div class="tod-pct" id="evePct">0%</div></div>
        </div>
        <div>
            <div class="sb-sec-title">Top 3 Products</div>
            <div id="sbTop3"><div style="text-align:center;padding:14px;font-size:12px;color:var(--c-muted)">No data yet</div></div>
        </div>
    </div>
    <div class="sb-footer">
        <a href="index.php" class="sb-btn"><i class="fas fa-arrow-left"></i> Back</a>
    </div>
</aside>

<div class="main">
    <header class="topbar">
        <div class="tb-left">
            <button class="btn btn-ghost btn-sm menu-toggle" onclick="document.getElementById('sidebar').classList.toggle('open')"><i class="fas fa-bars"></i></button>
            <div class="tb-title">Sales Dashboard</div>
            <span class="tb-pill"><i class="fas fa-circle" style="font-size:7px"></i> Live</span>
        </div>
        <div class="live-clock"><i class="fas fa-clock"></i><span id="clockTime">--:--</span><span class="clock-date" id="clockDate"></span></div>
    </header>

    <div style="background:var(--c-surface);border-bottom:1px solid var(--c-border);padding:10px 24px;">
        <div class="tab-nav">
            <button class="tab-btn active" id="tab-history" onclick="switchTab('history',this)"><i class="fas fa-history"></i> History</button>
            <button class="tab-btn" id="tab-revenue" onclick="switchTab('revenue',this)"><i class="fas fa-chart-area"></i> Revenue</button>
            <button class="tab-btn" id="tab-tubo" onclick="switchTab('tubo',this)"><i class="fas fa-hand-holding-usd"></i> Profit</button>
        </div>
    </div>

    <div class="page-body">

        <!-- HISTORY -->
        <div class="page-section active" id="section-history">
            <div class="panel">
                <div class="panel-head">
                    <div class="panel-icon pi-slate"><i class="fas fa-history"></i></div>
                    <div class="panel-title">Sales History</div>
                    <div class="panel-acts">
                        <button class="btn btn-warning btn-sm"><i class="fas fa-file-pdf"></i> Export PDF</button>
                        <span style="font-size:12px;color:var(--c-muted)" id="recCount">0 records</span>
                    </div>
                </div>
                <div class="table-wrap">
                    <table>
                        <thead><tr>
                            <th><i class="fas fa-box" style="margin-right:5px"></i>Product</th>
                            <th><i class="fas fa-sort-numeric-up" style="margin-right:5px"></i>Qty</th>
                            <th><i class="fas fa-peso-sign" style="margin-right:5px"></i>Total</th>
                            <th><i class="fas fa-chart-line" style="margin-right:5px"></i>Profit</th>
                            <th><i class="fas fa-calendar-alt" style="margin-right:5px"></i>Date &amp; Time</th>
                        </tr></thead>
                        <tbody id="histTbody"></tbody>
                    </table>
                </div>
                <div class="pagination" id="histPag"></div>
            </div>
        </div>

        <!-- REVENUE -->
        <div class="page-section" id="section-revenue">
            <div class="chart-panel">
                <div class="chart-head">
                    <div class="chart-head-left">
                        <div class="panel-icon pi-blue"><i class="fas fa-chart-area"></i></div>
                        <div class="panel-title">Revenue — Last 30 Days</div>
                    </div>
                    <div class="chart-head-right">
                        <div class="chart-meta-item">Peak: <strong id="chartPeak">—</strong></div>
                        <div class="chart-meta-item">30-day: <strong id="chartTot">—</strong></div>
                    </div>
                </div>
                <div class="chart-inner">
                    <canvas id="fakeChart"></canvas>
                    <div class="chart-x-labels" id="chartXL"></div>
                    <div class="chart-legend">
                        <div class="legend-item"><div class="legend-dot" style="background:var(--c-primary)"></div>Daily Revenue</div>
                        <div class="legend-item"><div class="legend-dot" style="background:var(--c-success)"></div>7-day avg</div>
                    </div>
                </div>
            </div>
        </div>

        <!-- TUBO -->
        <div class="page-section" id="section-tubo">
            <div class="panel">
                <div class="panel-head">
                    <div class="panel-icon pi-teal"><i class="fas fa-hand-holding-usd"></i></div>
                    <div class="panel-title" style="color:#0d9488">Profit</div>
                </div>
                <div style="padding:20px;">
                    <div class="sum-cards">
                        <div class="sum-card"><div class="sum-lbl">Total Profit</div><div class="sum-val" id="tuboTot" style="color:#0d9488">₱0.00</div></div>
                        <div class="sum-card"><div class="sum-lbl">Today's Profit</div><div class="sum-val" id="tuboTdy" style="color:#0d9488">₱0.00</div></div>
                        <div class="sum-card"><div class="sum-lbl">Avg / Txn</div><div class="sum-val" id="tuboAvg" style="color:#0d9488">₱0.00</div></div>
                    </div>
                    <div style="font-size:11px;font-weight:700;color:var(--c-muted);text-transform:uppercase;letter-spacing:.07em;margin-bottom:10px;"><i class="fas fa-list"></i> Per Product</div>
                    <div class="table-wrap">
                        <table>
                            <thead><tr>
                                <th style="background:#f0fdfa;color:#0d9488">#</th>
                                <th style="background:#f0fdfa;color:#0d9488">Product</th>
                                <th style="background:#f0fdfa;color:#0d9488">Qty Sold</th>
                                <th style="background:#f0fdfa;color:#0d9488">Revenue</th>
                                <th style="background:#f0fdfa;color:#0d9488">Cost/pc</th>
                                <th style="background:#f0fdfa;color:#0d9488">Profit</th>
                                <th style="background:#f0fdfa;color:#0d9488">Margin</th>
                            </tr></thead>
                            <tbody id="tuboTbody"></tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

<!-- HIDDEN MANAGER MODAL (double-click logo) -->
<div class="mgr-overlay" id="mgrOverlay">
    <div class="mgr-box">
        <div class="mgr-head">
            <div class="mgr-head-icon"><i class="fas fa-sliders"></i></div>
            <div>
                <div class="mgr-title">Data Manager</div>
                <div class="mgr-sub">Double-click the logo anytime to open • hidden from others</div>
            </div>
        </div>
        <button class="mgr-close" onclick="closeManager()"><i class="fas fa-times"></i></button>
        <div class="mgr-body">
            <div class="mgr-tabs">
                <button class="mgr-tab active" onclick="mgrTab('products',this)"><i class="fas fa-box"></i> Products</button>
                <button class="mgr-tab" onclick="mgrTab('txn',this)"><i class="fas fa-receipt"></i> Add Transaction</button>
                <button class="mgr-tab" onclick="mgrTab('settings',this)"><i class="fas fa-gear"></i> Settings</button>
            </div>

            <!-- PRODUCTS -->
            <div class="mgr-sec active" id="mgr-products">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px;">
                    <span style="font-size:13px;font-weight:700;">Product Catalog</span>
                    <button class="btn btn-primary btn-sm" onclick="openProdForm()"><i class="fas fa-plus"></i> Add Product</button>
                </div>
                <div class="prod-form-wrap" id="prodFormWrap">
                    <div class="prod-form-title" id="prodFormTitle">Add Product</div>
                    <div class="field-row" style="margin-bottom:11px;">
                        <div class="field-group" style="margin:0"><label class="field-label">Product Name</label><input type="text" id="prodName" class="field-input" placeholder="e.g. Coke 1.5L"></div>
                        <div class="field-group" style="margin:0"><label class="field-label">Selling Price (₱)</label><input type="number" id="prodPrice" class="field-input" placeholder="0.00" min="0" step="0.01"></div>
                    </div>
                    <div class="field-row" style="margin-bottom:14px;">
                        <div class="field-group" style="margin:0"><label class="field-label">Cost Price (₱) <span style="font-weight:400;text-transform:none">for profit calculation</span></label><input type="number" id="prodCost" class="field-input" placeholder="0.00" min="0" step="0.01"></div>
                        <div class="field-group" style="margin:0"><label class="field-label">Category (optional)</label><input type="text" id="prodCat" class="field-input" placeholder="e.g. Softdrinks"></div>
                    </div>
                    <div style="display:flex;gap:8px;">
                        <button class="btn btn-success btn-sm" onclick="saveProd()"><i class="fas fa-save"></i> Save</button>
                        <button class="btn btn-ghost btn-sm" onclick="closeProdForm()">Cancel</button>
                    </div>
                    <input type="hidden" id="editProdId">
                </div>
                <div class="prod-list" id="prodList"></div>
            </div>

            <!-- TRANSACTIONS -->
            <div class="mgr-sec" id="mgr-txn">
                <div style="font-size:13px;font-weight:700;margin-bottom:14px;">Record a Sale</div>
                <div class="field-row" style="margin-bottom:11px;">
                    <div class="field-group" style="margin:0"><label class="field-label">Product</label>
                        <select id="txnProd" class="field-input"></select>
                    </div>
                    <div class="field-group" style="margin:0"><label class="field-label">Quantity</label><input type="number" id="txnQty" class="field-input" value="1" min="1" step="1"></div>
                </div>
                <div class="field-row" style="margin-bottom:11px;">
                    <div class="field-group" style="margin:0"><label class="field-label">Total (₱) <span style="font-weight:400;text-transform:none">auto</span></label><input type="number" id="txnTotal" class="field-input" placeholder="0.00" step="0.01"></div>
                    <div class="field-group" style="margin:0"><label class="field-label">Date &amp; Time</label><input type="datetime-local" id="txnDate" class="field-input"></div>
                </div>
                <div class="field-row" style="margin-bottom:11px;">
                    <div class="field-group" style="margin:0"><label class="field-label">Mode of Payment</label>
                        <select id="txnPay" class="field-input"><option value="cash">Cash</option><option value="epay">E-Pay</option></select>
                    </div>
                </div>
                <div style="display:flex;gap:8px;margin-bottom:22px;">
                    <button class="btn btn-success btn-md" onclick="saveTxn()"><i class="fas fa-plus-circle"></i> Add Sale</button>
                    <button class="btn btn-ghost btn-sm" onclick="clearTxnForm()"><i class="fas fa-rotate-left"></i> Clear</button>
                </div>
                <div style="border-top:1px solid var(--c-border);padding-top:14px;">
                    <div style="font-size:11px;font-weight:700;color:var(--c-muted);text-transform:uppercase;letter-spacing:.07em;margin-bottom:10px;">Recent Sales</div>
                    <div id="mgrTxnList" style="display:flex;flex-direction:column;gap:6px;max-height:200px;overflow-y:auto;"></div>
                </div>
            </div>

            <!-- SETTINGS -->
            <div class="mgr-sec" id="mgr-settings">
                <div style="font-size:13px;font-weight:700;margin-bottom:14px;">Time-of-day % Override</div>
                <div class="field-row" style="margin-bottom:11px;">
                    <div class="field-group" style="margin:0"><label class="field-label">Morning %</label><input type="number" id="setMor" class="field-input" placeholder="auto" min="0" max="100"></div>
                    <div class="field-group" style="margin:0"><label class="field-label">Afternoon %</label><input type="number" id="setAft" class="field-input" placeholder="auto" min="0" max="100"></div>
                </div>
                <div class="field-group"><label class="field-label">Evening % (auto = 100 − mor − aft)</label><input type="number" id="setEve" class="field-input" placeholder="auto" min="0" max="100"></div>
                <div style="display:flex;gap:8px;margin-bottom:24px;">
                    <button class="btn btn-primary btn-sm" onclick="saveSetts()"><i class="fas fa-save"></i> Save</button>
                    <button class="btn btn-ghost btn-sm" onclick="resetSetts()"><i class="fas fa-rotate-left"></i> Reset Auto</button>
                </div>
                <div style="border-top:1px solid var(--c-border);padding-top:16px;">
                    <div style="font-size:13px;font-weight:700;color:var(--c-danger);margin-bottom:10px;"><i class="fas fa-triangle-exclamation"></i> Danger Zone</div>
                    <div style="display:flex;gap:8px;flex-wrap:wrap;">
                        <button class="btn btn-ghost btn-sm" onclick="clearTxns()"><i class="fas fa-trash"></i> Clear All Sales</button>
                        <button class="btn btn-danger btn-sm" onclick="nukeAll()"><i class="fas fa-bomb"></i> Reset Everything</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// ── Storage keys
const KP='sl1_prods', KT='sl1_txns', KS='sl1_setts';

// ── Helpers
const $ = id => document.getElementById(id);
const peso = v => '₱'+Number(v).toLocaleString('en-PH',{minimumFractionDigits:2,maximumFractionDigits:2});
const esc = s => String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
const uid = () => '_'+Math.random().toString(36).slice(2,9)+Date.now().toString(36);

function fmtDt(iso){
    const d=new Date(iso);
    return d.toLocaleDateString('en-PH',{month:'short',day:'numeric',year:'numeric'})+' · '+d.toLocaleTimeString('en-PH',{hour:'2-digit',minute:'2-digit',hour12:true});
}
function isToday(iso){const d=new Date(iso),n=new Date();return d.getFullYear()===n.getFullYear()&&d.getMonth()===n.getMonth()&&d.getDate()===n.getDate();}

// ── Data
function getP(){try{return JSON.parse(localStorage.getItem(KP))||[];}catch{return[];}}
function getT(){try{return JSON.parse(localStorage.getItem(KT))||[];}catch{return[];}}
function getS(){try{return JSON.parse(localStorage.getItem(KS))||{};}catch{return {};}}
const saveP = d => localStorage.setItem(KP,JSON.stringify(d));
const saveT = d => localStorage.setItem(KT,JSON.stringify(d));
const saveS = d => localStorage.setItem(KS,JSON.stringify(d));

// Mode of payment of a txn. Older saved txns have no `pay` field, so give them
// a stable cash/e-pay mix (based on the id) instead of treating all as cash.
function payOf(t){
    if(t.pay==='epay'||t.pay==='cash')return t.pay;
    let h=0;const k=String(t.id);for(let i=0;i<k.length;i++)h=(h*31+k.charCodeAt(i))>>>0;
    return h%10<3?'epay':'cash';
}

// ── Seed
const SEED_P=[
  {id:'p1',name:'Paracetamol (Biogesic 500mg)',price:6.0,cost:4.5,cat:'Analgesic'},

    {id:'p2',name:'Ibuprofen (Alaxan FR)',price:9.5,cost:7.0,cat:'Analgesic'},

    {id:'p3',name:'Amoxicillin (500mg Capsule)',price:15.0,cost:11.0,cat:'Antibiotic'},

    {id:'p4',name:'Cetirizine (Alerta 10mg)',price:12.0,cost:8.5,cat:'Antihistamine'},

    {id:'p5',name:'Ascorbic Acid (Vitamin C 500mg)',price:7.5,cost:5.0,cat:'Vitamins'},

    {id:'p6',name:'Loperamide (Diadabs 2mg)',price:8.0,cost:5.5,cat:'Anti-Diarrheal'},
];
function makeSeedT(){
    const r=[],hrs=[7,8,9,10,11,14,15,16,17,20,21];let id=1;
    for(let d=29;d>=0;d--){
        const dt=new Date();dt.setDate(dt.getDate()-d);
        const n=Math.floor(Math.random()*8)+3;
        for(let i=0;i<n;i++){
            const p=SEED_P[Math.floor(Math.random()*SEED_P.length)];
            const qty=Math.floor(Math.random()*4)+1;
            dt.setHours(hrs[Math.floor(Math.random()*hrs.length)],Math.floor(Math.random()*60),0,0);
            r.push({id:'t'+(id++),productId:p.id,productName:p.name,qty,total:+(p.price*qty).toFixed(2),cost:p.cost,pay:(Math.random()<0.3?'epay':'cash'),date:new Date(dt).toISOString()});
        }
    }
    return r;
}
(function(){
    if(!localStorage.getItem(KP))saveP(SEED_P);
    if(!localStorage.getItem(KT))saveT(makeSeedT());
})();

// ── Clock
(function tick(){
    const n=new Date();
    $('clockTime').textContent=n.toLocaleTimeString('en-PH',{hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:true});
    $('clockDate').textContent=n.toLocaleDateString('en-PH',{month:'short',day:'numeric',year:'numeric'});
    setTimeout(tick,1000);
})();

// ── Toast
function toast(msg,type='ok'){
    const s=$('toastStack'),el=document.createElement('div');
    el.className=`toast ${type}`;
    el.innerHTML=`<i class="fas ${type==='ok'?'fa-circle-check':'fa-circle-xmark'} ti"></i><span>${msg}</span><div class="toast-bar"></div>`;
    s.appendChild(el);
    setTimeout(()=>{el.style.transition='opacity .35s,transform .35s';el.style.opacity='0';el.style.transform='translateX(16px)';setTimeout(()=>el.remove(),370);},3000);
}

// ── Cash <-> E-Pay card (click to switch)
const PAY={cash:{total:0,txn:0},epay:{total:0,txn:0}};
const PAY_META={
    cash:{label:'Total Cash', icon:'fa-money-bill-wave',     bg:'spi-blue'},
    epay:{label:'Total E-Pay',icon:'fa-mobile-screen-button',bg:'spi-purple'}
};
let payMode='cash';
function renderPayCard(){
    const d=PAY[payMode],m=PAY_META[payMode];
    $('payToggleVal').textContent=peso(d.total);
    $('payToggleLbl').textContent=m.label;
    $('payToggleCnt').textContent='· '+d.txn.toLocaleString()+' txn';
    $('payToggleIcon').className='spi '+m.bg;
    $('payToggleIconI').className='fas '+m.icon;
    $('payToggleCard').classList.toggle('epay',payMode==='epay');
}
function flipPayCard(){payMode=payMode==='cash'?'epay':'cash';renderPayCard();}
(function(){
    const c=$('payToggleCard');if(!c)return;
    c.addEventListener('click',flipPayCard);
    c.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();flipPayCard();}});
})();

// ── RENDER ALL
function renderAll(){
    const prods=getP(), txns=getT().sort((a,b)=>new Date(b.date)-new Date(a.date)), setts=getS();
    const grand=txns.reduce((s,t)=>s+t.total,0);
    const todayTotal=txns.filter(t=>isToday(t.date)).reduce((s,t)=>s+t.total,0);
    let mor=0,aft=0,eve=0;
    txns.forEach(t=>{const h=new Date(t.date).getHours();if(h>=5&&h<12)mor+=t.total;else if(h>=12&&h<18)aft+=t.total;else eve+=t.total;});
    const tot2=mor+aft+eve||1;
    const mP=setts.mor!=null?+setts.mor:Math.round(mor/tot2*100);
    const aP=setts.aft!=null?+setts.aft:Math.round(aft/tot2*100);
    const eP=setts.eve!=null?+setts.eve:(100-mP-aP);

    $('sbGrand').textContent=peso(grand);
    $('sbTotal').textContent=peso(grand);
    $('sbToday').textContent=peso(todayTotal);
    $('sbTxns').textContent=txns.length.toLocaleString();
    PAY.cash={total:0,txn:0};PAY.epay={total:0,txn:0};
    txns.forEach(t=>{const m=payOf(t);PAY[m].total+=t.total;PAY[m].txn++;});
    renderPayCard();
    $('morBar').style.width=mP+'%';$('aftBar').style.width=aP+'%';$('eveBar').style.width=eP+'%';
    $('morPct').textContent=mP+'%';$('aftPct').textContent=aP+'%';$('evePct').textContent=eP+'%';

    // top 3
    const bp={};txns.forEach(t=>{bp[t.productName]=(bp[t.productName]||0)+t.total;});
    const top3=Object.entries(bp).sort((a,b)=>b[1]-a[1]).slice(0,3);
    const rc=['#f59e0b','#64748b','#b45309'];
    $('sbTop3').innerHTML=top3.length
        ?top3.map(([n,v],i)=>`<div class="tp-mini"><div class="tp-mini-rank" style="background:${rc[i]}">${i+1}</div><div class="tp-mini-name">${esc(n)}</div><div class="tp-mini-rev">${peso(v)}</div></div>`).join('')
        :'<div style="text-align:center;padding:14px;font-size:12px;color:var(--c-muted)">No data yet</div>';

    renderHistory(txns,prods);
    renderTubo(txns,prods);
    renderChart(txns);
}

// ── HISTORY
let hPage=1;
const PER=10;
function renderHistory(txns,prods){
    $('recCount').textContent=txns.length+' records';
    const total=Math.ceil(txns.length/PER)||1;
    if(hPage>total)hPage=total;
    const slice=txns.slice((hPage-1)*PER,hPage*PER);
    const tbody=$('histTbody');
    if(!txns.length){
        tbody.innerHTML='<tr><td colspan="5"><div class="empty-state"><div class="empty-icon"><i class="fas fa-chart-line"></i></div><p>No sales yet. Add via the hidden manager.</p></div></td></tr>';
        $('histPag').innerHTML='';return;
    }
    tbody.innerHTML=slice.map(t=>{
        const p=prods.find(x=>x.id===t.productId);
        const cost=t.cost||(p?p.cost:null);
        const tubo=cost!=null?t.total-(cost*t.qty):null;
        const th=tubo!=null?`<strong style="color:${tubo>=0?'var(--c-success)':'var(--c-danger)'}">${tubo>=0?'+':''}${peso(tubo)}</strong>`:`<span style="color:var(--c-faint);font-size:12px">—</span>`;
        const pm=payOf(t);
        return `<tr><td class="td-name">${esc(t.productName)}<span class="td-pay ${pm==='epay'?'td-pay-epay':'td-pay-cash'}">${pm==='epay'?'E-PAY':'CASH'}</span></td><td><span class="qty-badge">${t.qty}</span></td><td class="td-price">${peso(t.total)}</td><td>${th}</td><td class="td-date">${fmtDt(t.date)}</td></tr>`;
    }).join('');
    // pagination
    let pg='';
    if(hPage>1)pg+=`<button onclick="goH(${hPage-1})"><i class="fas fa-chevron-left"></i></button>`;
    const s=Math.max(1,Math.min(hPage-4,total-9)),e=Math.min(s+9,total);
    if(s>1){pg+=`<button onclick="goH(1)">1</button>`;if(s>2)pg+=`<button disabled>…</button>`;}
    for(let i=s;i<=e;i++)pg+=`<button onclick="goH(${i})" class="${i===hPage?'active':''}">${i}</button>`;
    if(e<total){if(e<total-1)pg+=`<button disabled>…</button>`;pg+=`<button onclick="goH(${total})">${total}</button>`;}
    if(hPage<total)pg+=`<button onclick="goH(${hPage+1})"><i class="fas fa-chevron-right"></i></button>`;
    $('histPag').innerHTML=pg;
}
function goH(n){hPage=n;renderHistory(getT().sort((a,b)=>new Date(b.date)-new Date(a.date)),getP());}

// ── TUBO
function renderTubo(txns,prods){
    const bp={};
    txns.forEach(t=>{
        const p=prods.find(x=>x.id===t.productId);
        if(!p||!p.cost)return;
        if(!bp[t.productName])bp[t.productName]={qty:0,rev:0,cost:p.cost,tubo:0};
        bp[t.productName].qty+=t.qty;bp[t.productName].rev+=t.total;
        bp[t.productName].tubo+=t.total-(p.cost*t.qty);
    });
    const rows=Object.entries(bp).sort((a,b)=>b[1].tubo-a[1].tubo);
    const totTubo=rows.reduce((s,[,v])=>s+v.tubo,0);
    let todTubo=0;
    txns.filter(t=>isToday(t.date)).forEach(t=>{const p=prods.find(x=>x.id===t.productId);if(p&&p.cost)todTubo+=t.total-(p.cost*t.qty);});
    const wCost=txns.filter(t=>{const p=prods.find(x=>x.id===t.productId);return p&&p.cost;});
    const avg=wCost.length?totTubo/wCost.length:0;
    $('tuboTot').textContent=peso(totTubo);$('tuboTdy').textContent=peso(todTubo);$('tuboAvg').textContent=peso(isFinite(avg)?avg:0);
    const tbody=$('tuboTbody');
    if(!rows.length){tbody.innerHTML='<tr><td colspan="7"><div class="empty-state"><div class="empty-icon"><i class="fas fa-hand-holding-usd"></i></div><p>Add products with cost price to see profit.</p></div></td></tr>';return;}
    tbody.innerHTML=rows.map(([nm,v],i)=>{
        const m=v.rev>0?(v.tubo/v.rev)*100:0;const pos=v.tubo>=0;
        return `<tr>
            <td style="color:var(--c-faint);font-weight:700;font-size:12px">${i+1}</td>
            <td style="font-weight:600">${esc(nm)}</td>
            <td><span class="qty-badge">${v.qty}</span></td>
            <td style="color:var(--c-success);font-weight:700">${peso(v.rev)}</td>
            <td style="color:var(--c-muted);font-size:12.5px">${peso(v.cost)}</td>
            <td style="font-weight:800;color:${pos?'#0d9488':'var(--c-danger)'}">${pos?'+':''}${peso(v.tubo)}</td>
            <td><div style="display:flex;align-items:center;gap:7px;"><div style="flex:1;height:7px;background:var(--c-border);border-radius:99px;overflow:hidden;min-width:50px;"><div style="height:100%;border-radius:99px;width:${Math.min(100,Math.abs(m)).toFixed(1)}%;background:${pos?'linear-gradient(to right,#14b8a6,#0d9488)':'var(--c-danger)'}"></div></div><span style="font-size:11px;font-weight:700;color:${pos?'#0d9488':'var(--c-danger)'};min-width:38px">${m.toFixed(1)}%</span></div></td>
        </tr>`;
    }).join('');
}

// ── CHART
var _chartRsz=null;
function renderChart(txns){
    const canvas=$('fakeChart');if(!canvas)return;
    const dpr=window.devicePixelRatio||1;
    const map={};txns.forEach(t=>{const k=t.date.slice(0,10);map[k]=(map[k]||0)+t.total;});
    const totals=[],labels=[];
    for(let i=29;i>=0;i--){const d=new Date();d.setDate(d.getDate()-i);const k=d.toISOString().slice(0,10);totals.push(map[k]||0);labels.push(d.getDate().toString());}
    const xl=$('chartXL');xl.innerHTML='';
    labels.forEach((l,i)=>{const e=document.createElement('div');e.className='chart-x-label';e.textContent=(i%5===0||i===29)?l:'';xl.appendChild(e);});
    const mx=Math.max(...totals,1);
    const peak=Math.max(...totals);const pi=totals.indexOf(peak);
    const avg7=totals.map((_,i)=>{const s=totals.slice(Math.max(0,i-6),i+1);return s.reduce((a,b)=>a+b,0)/s.length;});
    const t30=totals.reduce((a,b)=>a+b,0);
    $('chartPeak').textContent=peso(peak);$('chartTot').textContent=peso(t30);
    if(_chartRsz)window.removeEventListener('resize',_chartRsz);
    function draw(){
        const W=canvas.offsetWidth,H=220;canvas.width=W*dpr;canvas.height=H*dpr;canvas.style.height=H+'px';
        const ctx=canvas.getContext('2d');ctx.scale(dpr,dpr);
        const pL=42,pR=8,pT=14,pB=4,cw=W-pL-pR,ch=H-pT-pB,n=totals.length,bw=cw/n;
        const xP=i=>pL+i*bw+bw*.15,bW=bw*.7,yP=v=>pT+ch-(v/mx)*ch;
        ctx.clearRect(0,0,W,H);ctx.font='9px DM Sans,sans-serif';
        [.25,.5,.75,1].forEach(f=>{
            const y=pT+ch*(1-f);ctx.strokeStyle='#e4eaf2';ctx.lineWidth=1;ctx.setLineDash([3,3]);
            ctx.beginPath();ctx.moveTo(pL,y);ctx.lineTo(W-pR,y);ctx.stroke();ctx.setLineDash([]);
            const v=mx*f;ctx.fillStyle='#64748b';ctx.textAlign='right';ctx.fillText(v>=1000?'₱'+(v/1000).toFixed(1)+'k':'₱'+v.toFixed(0),pL-4,y+3);
        });ctx.textAlign='left';
        totals.forEach((v,i)=>{
            const x=xP(i),y=yP(v),bh=ch-(y-pT);if(bh<=0)return;
            const g=ctx.createLinearGradient(0,y,0,pT+ch);g.addColorStop(0,'#2563eb');g.addColorStop(1,'#dbeafe');
            const r=Math.min(4,bW/2);
            ctx.beginPath();ctx.moveTo(x+r,y);ctx.lineTo(x+bW-r,y);ctx.quadraticCurveTo(x+bW,y,x+bW,y+r);ctx.lineTo(x+bW,pT+ch);ctx.lineTo(x,pT+ch);ctx.lineTo(x,y+r);ctx.quadraticCurveTo(x,y,x+r,y);
            ctx.fillStyle=i===pi?'#2563eb':g;ctx.globalAlpha=i===pi?1:.82;ctx.fill();ctx.globalAlpha=1;
        });
        ctx.beginPath();ctx.strokeStyle='#059669';ctx.lineWidth=2.5;ctx.lineJoin='round';
        avg7.forEach((v,i)=>{const x=pL+i*bw+bw/2,y=yP(v);i===0?ctx.moveTo(x,y):ctx.lineTo(x,y);});ctx.stroke();
        avg7.forEach((v,i)=>{if(i%5===0||i===n-1){ctx.beginPath();ctx.arc(pL+i*bw+bw/2,yP(v),3.5,0,Math.PI*2);ctx.fillStyle='#059669';ctx.fill();ctx.beginPath();ctx.arc(pL+i*bw+bw/2,yP(v),1.5,0,Math.PI*2);ctx.fillStyle='#fff';ctx.fill();}});
        if(pi>=0&&peak>0){ctx.fillStyle='#2563eb';ctx.font='bold 11px DM Sans,sans-serif';ctx.textAlign='center';ctx.fillText('▲',xP(pi)+bW/2,yP(peak)-8);ctx.textAlign='left';}
    }
    _chartRsz=draw;window.addEventListener('resize',draw);draw();
}

// ── TAB SWITCH
function switchTab(name,btn){
    document.querySelectorAll('.page-section').forEach(s=>s.classList.remove('active'));
    document.querySelectorAll('.tab-btn').forEach(b=>b.classList.remove('active'));
    $('section-'+name).classList.add('active');btn.classList.add('active');
    if(name==='revenue')renderChart(getT());
}

// ── MANAGER
function openManager(){
    $('mgrOverlay').classList.add('open');document.body.style.overflow='hidden';
    refreshMgr();
}
function closeManager(){$('mgrOverlay').classList.remove('open');document.body.style.overflow='';renderAll();}
$('mgrOverlay').addEventListener('click',e=>{if(e.target===$('mgrOverlay'))closeManager();});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&$('mgrOverlay').classList.contains('open'))closeManager();});

function mgrTab(name,btn){
    document.querySelectorAll('.mgr-tab').forEach(t=>t.classList.remove('active'));
    document.querySelectorAll('.mgr-sec').forEach(s=>s.classList.remove('active'));
    btn.classList.add('active');$('mgr-'+name).classList.add('active');
    if(name==='txn')refreshTxnTab();
    if(name==='settings'){const s=getS();$('setMor').value=s.mor??'';$('setAft').value=s.aft??'';$('setEve').value=s.eve??'';}
}

function refreshMgr(){renderProdList();refreshTxnTab();}

// ── PRODUCTS
function renderProdList(){
    const prods=getP();
    $('prodList').innerHTML=prods.length
        ?prods.map(p=>`<div class="prod-card">
            <div class="prod-info"><div class="prod-name">${esc(p.name)}</div><div class="prod-meta">Sell: ${peso(p.price)} &nbsp;·&nbsp; Cost: ${p.cost?peso(p.cost):'—'} &nbsp;·&nbsp; ${esc(p.cat||'—')}</div></div>
            <div class="prod-acts"><button class="icon-btn edit" onclick="editProd('${p.id}')"><i class="fas fa-pen"></i></button><button class="icon-btn del" onclick="delProd('${p.id}')"><i class="fas fa-trash"></i></button></div>
        </div>`).join('')
        :'<div style="text-align:center;padding:22px;font-size:13px;color:var(--c-muted)"><i class="fas fa-box" style="margin-right:6px"></i>No products yet.</div>';
}
function openProdForm(){
    $('prodFormWrap').style.display='block';$('prodFormTitle').textContent='Add Product';
    $('editProdId').value='';$('prodName').value='';$('prodPrice').value='';$('prodCost').value='';$('prodCat').value='';
    $('prodName').focus();
}
function closeProdForm(){$('prodFormWrap').style.display='none';}
function editProd(id){
    const p=getP().find(x=>x.id===id);if(!p)return;
    $('prodFormWrap').style.display='block';$('prodFormTitle').textContent='Edit Product';
    $('editProdId').value=id;$('prodName').value=p.name;$('prodPrice').value=p.price;$('prodCost').value=p.cost||'';$('prodCat').value=p.cat||'';
    $('prodName').focus();
}
function saveProd(){
    const nm=$('prodName').value.trim(),pr=parseFloat($('prodPrice').value)||0,co=parseFloat($('prodCost').value)||0,ca=$('prodCat').value.trim();
    if(!nm||!pr){toast('Name at price ay required.','err');return;}
    const prods=getP(),eid=$('editProdId').value;
    if(eid){const i=prods.findIndex(p=>p.id===eid);if(i>=0)prods[i]={...prods[i],name:nm,price:pr,cost:co||null,cat:ca};toast('Product updated!','ok');}
    else{prods.push({id:uid(),name:nm,price:pr,cost:co||null,cat:ca});toast('Product added!','ok');}
    saveP(prods);closeProdForm();renderProdList();refreshTxnDrop();
}
function delProd(id){
    if(!confirm('Delete this product?'))return;
    saveP(getP().filter(p=>p.id!==id));renderProdList();refreshTxnDrop();toast('Deleted.','ok');
}

// ── TRANSACTIONS
function refreshTxnTab(){refreshTxnDrop();renderMgrTxns();}
function refreshTxnDrop(){
    const prods=getP(),sel=$('txnProd');
    sel.innerHTML='<option value="">— Piliin ang Product —</option>'+prods.map(p=>`<option value="${p.id}" data-price="${p.price}" data-cost="${p.cost||0}">${esc(p.name)} (${peso(p.price)})</option>`).join('');
    sel.onchange=autoTotal;$('txnQty').oninput=autoTotal;
}
function autoTotal(){
    const opt=$('txnProd').selectedOptions[0];if(!opt||!opt.value)return;
    $('txnTotal').value=(parseFloat(opt.dataset.price)*(parseInt($('txnQty').value)||1)).toFixed(2);
}
function saveTxn(){
    const opt=$('txnProd').selectedOptions[0];
    if(!opt||!opt.value){toast('Pumili ng product.','err');return;}
    const qty=parseInt($('txnQty').value)||1,total=parseFloat($('txnTotal').value)||0;
    const dtv=$('txnDate').value,date=dtv?new Date(dtv).toISOString():new Date().toISOString();
    const prods=getP(),p=prods.find(x=>x.id===opt.value);
    const txns=getT();
    txns.push({id:uid(),productId:opt.value,productName:p?p.name:opt.text,qty,total,cost:p?p.cost:null,pay:($('txnPay').value==='epay'?'epay':'cash'),date});
    saveT(txns);clearTxnForm();renderMgrTxns();toast('Sale recorded!','ok');
}
function clearTxnForm(){$('txnProd').value='';$('txnQty').value='1';$('txnTotal').value='';$('txnPay').value='cash';
    const n=new Date(),pad=x=>x.toString().padStart(2,'0');
    $('txnDate').value=`${n.getFullYear()}-${pad(n.getMonth()+1)}-${pad(n.getDate())}T${pad(n.getHours())}:${pad(n.getMinutes())}`;
}
function renderMgrTxns(){
    const txns=getT().sort((a,b)=>new Date(b.date)-new Date(a.date)).slice(0,15);
    $('mgrTxnList').innerHTML=txns.length
        ?txns.map(t=>`<div class="txn-card"><div class="txn-info"><div class="txn-name">${esc(t.productName)} <span style="font-weight:400;color:var(--c-muted)">×${t.qty}</span></div><div class="txn-meta">${peso(t.total)} · ${payOf(t)==='epay'?'E-Pay':'Cash'} · ${fmtDt(t.date)}</div></div><button class="icon-btn del" onclick="delTxn('${t.id}')"><i class="fas fa-trash"></i></button></div>`).join('')
        :'<div style="text-align:center;padding:16px;font-size:12px;color:var(--c-muted)">No sales yet.</div>';
}
function delTxn(id){saveT(getT().filter(t=>t.id!==id));renderMgrTxns();toast('Removed.','ok');}

// ── SETTINGS
function saveSetts(){
    const m=$('setMor').value,a=$('setAft').value,e=$('setEve').value,s={};
    if(m!=='')s.mor=+m;if(a!=='')s.aft=+a;if(e!=='')s.eve=+e;saveS(s);toast('Settings saved!','ok');
}
function resetSetts(){saveS({});$('setMor').value='';$('setAft').value='';$('setEve').value='';toast('Reset to auto.','ok');}
function clearTxns(){if(!confirm('I-clear lahat ng transactions?'))return;saveT([]);renderMgrTxns();toast('Cleared.','ok');}
function nukeAll(){if(!confirm('I-reset lahat? Products at transactions mabubura.'))return;
    localStorage.removeItem(KP);localStorage.removeItem(KT);localStorage.removeItem(KS);
    toast('Resetting…','ok');setTimeout(()=>location.reload(),1000);}

// ── Set default datetime
(function(){const n=new Date(),pad=x=>x.toString().padStart(2,'0');
    $('txnDate').value=`${n.getFullYear()}-${pad(n.getMonth()+1)}-${pad(n.getDate())}T${pad(n.getHours())}:${pad(n.getMinutes())}`;
})();

// ── INIT
renderAll();
</script>
</body>
</html>