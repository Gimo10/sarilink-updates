<?php
/* ============================================================================
   Sari-Link — System Update
   ----------------------------------------------------------------------------
   Flow:  check internet/version -> BACKUP (files + database) -> download +
          verify -> extract -> palitan ang files -> run SQL -> bagong version.
   Kapag may pumalpak pagkatapos magsimulang palitan ang files: AUTO-ROLLBACK
   mula sa backup.
   ============================================================================ */
session_start();
require_once __DIR__ . '/auth.php';
require_login();

$CFG  = require __DIR__ . '/config.php';
$ROOT = str_replace('\\', '/', __DIR__);

if (!in_array(current_user_username(), $CFG['update_users'], true)) {
    http_response_code(403);
    exit('Hindi ka pinapayagang mag-update ng system.');
}
if (empty($_SESSION['upd_csrf'])) $_SESSION['upd_csrf'] = bin2hex(random_bytes(16));
$CSRF = $_SESSION['upd_csrf'];

// Hindi kailanman ino-overwrite ng update (local na data/settings ng client)
const NEVER_OVERWRITE = ['config.php', 'auth.php', 'backup', 'uploads', 'version.txt'];
// Hindi rin kinokopya galing sa package
const SKIP_FROM_PACKAGE = ['config.php', 'auth.php', 'backup', 'uploads', 'version.txt',
                           'update.php', 'deleted.txt', 'tools', '.git'];

/* ───────────────────────── helpers ───────────────────────── */

function json_out($arr) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($arr);
    exit;
}

function current_version($root) {
    $v = trim((string)@file_get_contents("$root/version.txt"));
    return $v !== '' ? $v : '0.0.0';
}

function http_get($url, $saveTo = null, $timeout = 30) {
    if (stripos($url, 'https://') !== 0) throw new Exception('Dapat https:// ang update link.');

    if (function_exists('curl_init')) {
        $ch   = curl_init($url);
        $fh   = $saveTo ? fopen($saveTo, 'wb') : null;
        $opts = [
            CURLOPT_FOLLOWLOCATION => true, CURLOPT_MAXREDIRS => 5,
            CURLOPT_CONNECTTIMEOUT => 8,    CURLOPT_TIMEOUT => $timeout,
            CURLOPT_USERAGENT      => 'SariLink-Updater',
            CURLOPT_SSL_VERIFYPEER => true,
        ];
        if ($fh) $opts[CURLOPT_FILE] = $fh; else $opts[CURLOPT_RETURNTRANSFER] = true;

        // Ilang XAMPP install ay walang CA bundle na naka-set
        if (!ini_get('curl.cainfo')) {
            $dr = !empty($_SERVER['DOCUMENT_ROOT']) ? dirname(str_replace('\\', '/', $_SERVER['DOCUMENT_ROOT'])) : '';
            foreach ([$dr . '/apache/bin/curl-ca-bundle.crt', $dr . '/php/extras/ssl/cacert.pem',
                      'C:/xampp/apache/bin/curl-ca-bundle.crt'] as $ca) {
                if ($ca && file_exists($ca)) { $opts[CURLOPT_CAINFO] = $ca; break; }
            }
        }
        curl_setopt_array($ch, $opts);
        $body = curl_exec($ch);
        $err  = curl_error($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($fh) fclose($fh);
        if ($body === false || $code !== 200) {
            if ($saveTo) @unlink($saveTo);
            throw new Exception($err ? "Walang internet o hindi maabot ang update server ($err)"
                                     : "Hindi maabot ang update server (HTTP $code)");
        }
        return $saveTo ? true : $body;
    }

    $ctx  = stream_context_create(['http' => ['timeout' => $timeout, 'user_agent' => 'SariLink-Updater']]);
    $body = @file_get_contents($url, false, $ctx);
    if ($body === false) throw new Exception('Walang internet o hindi maabot ang update server.');
    if ($saveTo) { file_put_contents($saveTo, $body); return true; }
    return $body;
}

function fetch_manifest($cfg) {
    $raw = http_get($cfg['update_manifest_url'], null, 15);
    $m   = json_decode($raw, true);
    if (!is_array($m) || empty($m['version']) || empty($m['url']) || empty($m['sha256'])) {
        throw new Exception('Mali ang laman ng version.json sa server.');
    }
    if (stripos($m['url'], 'https://') !== 0) throw new Exception('Dapat https:// ang link ng update package.');
    return $m;
}

function can_exec() {
    if (!function_exists('exec')) return false;
    $dis = array_map('trim', explode(',', (string)ini_get('disable_functions')));
    return !in_array('exec', $dis, true);
}

function find_bin($name, $configured) {
    if ($configured && file_exists($configured)) return $configured;
    $c  = [];
    $dr = !empty($_SERVER['DOCUMENT_ROOT']) ? str_replace('\\', '/', $_SERVER['DOCUMENT_ROOT']) : '';
    if ($dr) $c[] = dirname($dr) . "/mysql/bin/$name.exe";
    $c[] = "C:/xampp/mysql/bin/$name.exe";
    foreach ($c as $p) if (file_exists($p)) return $p;
    return null;
}

function q($s) { return '"' . str_replace('"', '', $s) . '"'; }

function rrmdir($dir) {
    if (!is_dir($dir)) return;
    $it = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::CHILD_FIRST
    );
    foreach ($it as $f) { $f->isDir() ? @rmdir($f->getPathname()) : @unlink($f->getPathname()); }
    @rmdir($dir);
}

function zip_folder($src, $zipPath, $skipTop) {
    $zip = new ZipArchive;
    if ($zip->open($zipPath, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) return false;
    $src = rtrim(str_replace('\\', '/', $src), '/');
    $it  = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($src, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::LEAVES_ONLY
    );
    foreach ($it as $f) {
        if (!$f->isFile()) continue;
        $path = str_replace('\\', '/', $f->getPathname());
        $rel  = ltrim(substr($path, strlen($src)), '/');
        if (in_array(explode('/', $rel)[0], $skipTop, true)) continue;
        $zip->addFile($path, $rel);
    }
    return $zip->close();
}

function zip_is_safe(ZipArchive $zip) {
    for ($i = 0; $i < $zip->numFiles; $i++) {
        $n = str_replace('\\', '/', $zip->getNameIndex($i));
        if ($n === '' || $n[0] === '/' || strpos($n, ':') !== false) return false;
        foreach (explode('/', $n) as $seg) if ($seg === '..') return false;
    }
    return true;
}

/* ── Database ── */

function db_connect($cfg) {
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    $db = new mysqli($cfg['db_host'], $cfg['db_user'], $cfg['db_pass'], $cfg['db_name']);
    $db->set_charset('utf8mb4');
    return $db;
}

function run_sql_file(mysqli $db, $sql) {
    $db->multi_query($sql);
    do { if ($r = $db->store_result()) $r->free(); } while ($db->more_results() && $db->next_result());
}

function php_dump(mysqli $db, $file) {
    $fh = fopen($file, 'wb');
    fwrite($fh, "SET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS=0;\n\n");
    $tables = [];
    $res = $db->query("SHOW FULL TABLES WHERE Table_type = 'BASE TABLE'");
    while ($row = $res->fetch_row()) $tables[] = $row[0];
    $res->free();

    foreach ($tables as $t) {
        fwrite($fh, "DROP TABLE IF EXISTS `$t`;\n");
        $create = $db->query("SHOW CREATE TABLE `$t`")->fetch_row()[1];
        fwrite($fh, $create . ";\n\n");

        $rs = $db->query("SELECT * FROM `$t`", MYSQLI_USE_RESULT);
        $buf = [];
        while ($row = $rs->fetch_row()) {
            $vals = [];
            foreach ($row as $v) $vals[] = $v === null ? 'NULL' : "'" . $db->real_escape_string($v) . "'";
            $buf[] = '(' . implode(',', $vals) . ')';
            if (count($buf) >= 200) { fwrite($fh, "INSERT INTO `$t` VALUES " . implode(",\n", $buf) . ";\n"); $buf = []; }
        }
        $rs->free();
        if ($buf) fwrite($fh, "INSERT INTO `$t` VALUES " . implode(",\n", $buf) . ";\n");
        fwrite($fh, "\n");
    }
    fwrite($fh, "SET FOREIGN_KEY_CHECKS=1;\n");
    fclose($fh);
}

function backup_database($cfg, $file, &$log) {
    $bin = can_exec() ? find_bin('mysqldump', $cfg['mysqldump_path']) : null;
    if ($bin) {
        $cmd = q($bin) . ' --host=' . q($cfg['db_host']) . ' --user=' . q($cfg['db_user'])
             . ($cfg['db_pass'] !== '' ? ' --password=' . q($cfg['db_pass']) : '')
             . ' --default-character-set=utf8mb4 --single-transaction --routines --triggers --add-drop-table'
             . ' --result-file=' . q($file) . ' ' . q($cfg['db_name']) . ' 2>&1';
        exec($cmd, $out, $code);
        if ($code === 0 && file_exists($file) && filesize($file) > 200) { $log[] = 'Database backup OK (mysqldump).'; return; }
        @unlink($file);
        $log[] = 'mysqldump hindi gumana, gagamit ng built-in na backup...';
    }
    php_dump(db_connect($cfg), $file);
    if (!file_exists($file) || filesize($file) < 100) throw new Exception('Pumalpak ang database backup.');
    $log[] = 'Database backup OK (built-in).';
}

function restore_database($cfg, $file) {
    $bin = can_exec() ? find_bin('mysql', $cfg['mysql_path']) : null;
    if ($bin) {
        $cmd = q($bin) . ' --host=' . q($cfg['db_host']) . ' --user=' . q($cfg['db_user'])
             . ($cfg['db_pass'] !== '' ? ' --password=' . q($cfg['db_pass']) : '')
             . ' --default-character-set=utf8mb4 ' . q($cfg['db_name'])
             . ' --execute=' . q('source ' . str_replace('\\', '/', $file)) . ' 2>&1';
        exec($cmd, $out, $code);
        if ($code === 0) return;
    }
    run_sql_file(db_connect($cfg), file_get_contents($file));
}

/* ── Files ── */

function apply_files($src, $dst, &$added, $top = true) {
    foreach (scandir($src) as $f) {
        if ($f === '.' || $f === '..') continue;
        if ($top && in_array($f, SKIP_FROM_PACKAGE, true)) continue;
        $s = "$src/$f"; $d = "$dst/$f";
        if (is_dir($s)) {
            if (!is_dir($d)) { mkdir($d, 0777, true); $added[] = $d; }
            apply_files($s, $d, $added, false);
        } else {
            if (!file_exists($d)) $added[] = $d;
            if (!@copy($s, $d)) throw new Exception('Hindi ma-copy ang file: ' . $f);
        }
    }
}

function apply_deletions($tmpRoot, $root, &$log) {
    $list = "$tmpRoot/deleted.txt";
    if (!file_exists($list)) return;
    foreach (file($list, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $rel) {
        $rel = trim(str_replace('\\', '/', $rel), " \t/");
        if ($rel === '' || strpos($rel, '..') !== false || strpos($rel, ':') !== false) continue;
        if (in_array(explode('/', $rel)[0], NEVER_OVERWRITE, true)) continue;
        if (is_file("$root/$rel") && @unlink("$root/$rel")) $log[] = "Tinanggal na lumang file: $rel";
    }
}

function rollback($root, $bdir, $cfg, $dbTouched, $added, &$log) {
    $zip = new ZipArchive;
    if ($zip->open("$bdir/files.zip") === true) { $zip->extractTo($root); $zip->close(); $log[] = 'Naibalik ang files.'; }
    foreach (array_reverse($added) as $p) {
        if (is_file($p)) @unlink($p); elseif (is_dir($p)) @rmdir($p);
    }
    if ($dbTouched) { restore_database($cfg, "$bdir/database.sql"); $log[] = 'Naibalik ang database.'; }
}

/* ───────────────────────── actions ───────────────────────── */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($CSRF, (string)($_POST['csrf'] ?? ''))) json_out(['ok' => false, 'message' => 'Invalid request. I-refresh ang page.']);
    $action = $_POST['action'] ?? '';

    // ── CHECK ──
    if ($action === 'check') {
        session_write_close();
        try {
            $m   = fetch_manifest($CFG);
            $cur = current_version($ROOT);
            json_out(['ok' => true, 'current' => $cur, 'latest' => $m['version'],
                      'available' => version_compare($m['version'], $cur, '>'),
                      'notes' => (string)($m['notes'] ?? '')]);
        } catch (Throwable $e) {
            json_out(['ok' => false, 'message' => $e->getMessage()]);
        }
    }

    // ── RUN ──
    if ($action === 'run') {
        session_write_close();            // huwag harangan ang ibang tab ng POS
        set_time_limit(0);
        ignore_user_abort(true);          // tuloy ang update kahit maisara ang browser
        ini_set('memory_limit', '512M');

        $log = []; $added = []; $dbTouched = false; $applying = false;
        $bdir = null; $tmp = null; $lock = "$ROOT/backup/.lock"; $haveLock = false;

        try {
            // 1. Internet + version
            $m   = fetch_manifest($CFG);
            $cur = current_version($ROOT);
            if (!version_compare($m['version'], $cur, '>')) json_out(['ok' => true, 'message' => "Updated na. Version $cur na ang gamit mo.", 'log' => []]);
            $log[] = "Internet OK. $cur -> {$m['version']}";

            // Backup folder + proteksyon
            if (!is_dir("$ROOT/backup")) mkdir("$ROOT/backup", 0777, true);
            @file_put_contents("$ROOT/backup/.htaccess", "Require all denied\n");
            @file_put_contents("$ROOT/backup/index.html", '');
            if (file_exists($lock) && time() - filemtime($lock) < 1800) throw new Exception('May tumatakbong update na. Maghintay muna.');
            file_put_contents($lock, date('c'));
            $haveLock = true;

            $stamp = date('Ymd_His');
            $bdir  = "$ROOT/backup/$stamp";
            mkdir($bdir, 0777, true);

            // 2. BACKUP muna: files + database
            if (!zip_folder($ROOT, "$bdir/files.zip", ['backup'])) throw new Exception('Pumalpak ang files backup.');
            $log[] = 'Files backup OK.';
            backup_database($CFG, "$bdir/database.sql", $log);

            // 3. Download + verify
            http_get($m['url'], "$bdir/update.zip", 300);
            if (!hash_equals(strtolower($m['sha256']), hash_file('sha256', "$bdir/update.zip"))) {
                throw new Exception('Sira ang download (hash mismatch).');
            }
            $log[] = 'Download OK at na-verify.';

            // 4. Extract sa temp
            $zip = new ZipArchive;
            if ($zip->open("$bdir/update.zip") !== true) throw new Exception('Hindi mabuksan ang update package.');
            if (!zip_is_safe($zip)) { $zip->close(); throw new Exception('Delikadong update package (di-ligtas na path).'); }
            $tmp = "$bdir/tmp";
            $zip->extractTo($tmp);
            $zip->close();

            $src = $tmp;
            $ent = array_values(array_diff(scandir($tmp), ['.', '..']));
            if (count($ent) === 1 && is_dir("$tmp/{$ent[0]}")) $src = "$tmp/{$ent[0]}";
            if (!file_exists("$src/index.php")) throw new Exception('Mali ang laman ng update package.');
            $log[] = 'Na-extract ang package. (Wala pang nababago sa system.)';

            // 5. Palitan ang files  (mula dito, may rollback kapag pumalpak)
            $applying = true;
            apply_files($src, $ROOT, $added);
            apply_deletions($src, $ROOT, $log);
            if (file_exists("$src/update.php")) copy("$src/update.php", "$ROOT/update.php");   // huli, ang updater mismo
            $log[] = 'Napalitan ang files.';

            // 6. Database: idempotent structure script + migrations
            $dbTouched = true;
            $db = db_connect($CFG);
            if (file_exists("$ROOT/posmachin_structure_safe_update.sql")) {
                run_sql_file($db, file_get_contents("$ROOT/posmachin_structure_safe_update.sql"));
                $log[] = 'Na-update ang database structure.';
            }
            if (is_dir("$ROOT/migrations")) {
                $db->query("CREATE TABLE IF NOT EXISTS schema_migrations (name VARCHAR(255) PRIMARY KEY, ran_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
                $files = glob("$ROOT/migrations/*.sql"); sort($files);
                foreach ($files as $f) {
                    $n = $db->real_escape_string(basename($f));
                    if ($db->query("SELECT 1 FROM schema_migrations WHERE name='$n'")->num_rows) continue;
                    run_sql_file($db, file_get_contents($f));
                    $db->query("INSERT INTO schema_migrations (name) VALUES ('$n')");
                    $log[] = 'Migration: ' . basename($f);
                }
            }
            $db->close();

            // 7. Bagong version
            file_put_contents("$ROOT/version.txt", $m['version']);
            $log[] = "Version {$m['version']} na.";

            // Linis: temp + lumang backups
            rrmdir($tmp); @unlink("$bdir/update.zip");
            $keep = max(1, (int)$CFG['keep_backups']);
            $dirs = array_filter(glob("$ROOT/backup/*", GLOB_ONLYDIR), function ($d) { return preg_match('/^\d{8}_\d{6}$/', basename($d)); });
            sort($dirs);
            while (count($dirs) > $keep) rrmdir(array_shift($dirs));

            file_put_contents("$bdir/update.log", implode("\n", $log));
            @unlink($lock);
            json_out(['ok' => true, 'message' => "Success! Na-update na sa version {$m['version']}.", 'log' => $log]);

        } catch (Throwable $e) {
            $log[] = 'ERROR: ' . $e->getMessage();
            $msg = $e->getMessage() . ' — Walang nabago sa system.';
            if ($applying && $bdir) {
                try {
                    rollback($ROOT, $bdir, $CFG, $dbTouched, $added, $log);
                    $msg = $e->getMessage() . ' — Naibalik na sa dating version.';
                } catch (Throwable $e2) {
                    $log[] = 'ROLLBACK ERROR: ' . $e2->getMessage();
                    $msg = 'Pumalpak ang update AT ang rollback. Tawagan ang developer. Nasa backup/' . basename($bdir) . ' ang backup.';
                }
            }
            if ($bdir && is_dir($bdir)) @file_put_contents("$bdir/update.log", implode("\n", $log));
            if ($tmp) rrmdir($tmp);
            if ($haveLock) @unlink($lock);
            json_out(['ok' => false, 'message' => $msg, 'log' => $log]);
        }
    }
    json_out(['ok' => false, 'message' => 'Unknown action.']);
}

$curVersion = current_version($ROOT);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>System Update — Sari-Link POS</title>
<link href="assets/css/fonts.css" rel="stylesheet">
<link href="assets/css/fontawesome.min.css" rel="stylesheet">
<link rel="shortcut icon" href="Sari-Link.ico" type="image/x-icon">
<style>
  :root{--c-bg:#eef2f8;--c-surface:#fff;--c-border:#e2e8f2;--c-primary:#2563eb;--c-primary-hv:#1d4ed8;--c-primary-lt:#dbeafe;
        --c-danger:#dc2626;--c-danger-lt:#fee2e2;--c-ok:#15803d;--c-ok-lt:#dcfce7;--c-warn:#b45309;--c-warn-lt:#fef3c7;
        --c-text:#0f172a;--c-muted:#57647c;--c-faint:#8695ab;--font:'DM Sans',sans-serif;--disp:'Playfair Display',serif;}
  *,*::before,*::after{margin:0;padding:0;box-sizing:border-box;}
  body{font-family:var(--font);min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px;
       background:radial-gradient(circle at 15% 12%,rgba(59,130,246,.20),transparent 45%),
                  linear-gradient(160deg,#0b1526 0%,#132743 55%,#1c3a5e 100%);}
  .card{background:var(--c-surface);border-radius:24px;width:520px;max-width:100%;padding:38px 36px 30px;
        box-shadow:0 24px 60px rgba(8,15,30,.35);}
  .logo{width:56px;height:56px;border-radius:16px;background:linear-gradient(135deg,#eef4ff,#dbe7fb);padding:8px;margin:0 auto 16px;display:block;}
  .logo img{width:100%;height:100%;object-fit:contain;}
  h1{font-family:var(--disp);font-size:25px;text-align:center;color:var(--c-text);margin-bottom:4px;}
  h1 span{color:var(--c-primary);}
  .sub{font-size:13px;color:var(--c-muted);text-align:center;margin-bottom:24px;}
  .ver{display:flex;justify-content:space-between;background:#f7f9fc;border:1px solid var(--c-border);border-radius:12px;padding:13px 16px;margin-bottom:14px;font-size:13.5px;}
  .ver b{font-weight:700;color:var(--c-text);}
  .msg{display:none;border-radius:12px;padding:12px 14px;font-size:13px;font-weight:600;margin-bottom:14px;line-height:1.5;}
  .msg.info{display:block;background:var(--c-primary-lt);color:var(--c-primary-hv);}
  .msg.ok{display:block;background:var(--c-ok-lt);color:var(--c-ok);}
  .msg.err{display:block;background:var(--c-danger-lt);color:var(--c-danger);}
  .msg.warn{display:block;background:var(--c-warn-lt);color:var(--c-warn);}
  .notes{white-space:pre-wrap;font-weight:500;margin-top:6px;font-size:12.5px;}
  .btn{width:100%;padding:14px;border:none;border-radius:12px;font-family:inherit;font-weight:700;font-size:14.5px;cursor:pointer;
       color:#fff;background:linear-gradient(135deg,var(--c-primary),var(--c-primary-hv));display:flex;align-items:center;justify-content:center;gap:9px;
       box-shadow:0 8px 20px rgba(37,99,235,.28);margin-top:8px;}
  .btn:disabled{opacity:.55;cursor:not-allowed;}
  .btn.ghost{background:#fff;color:var(--c-muted);border:1.5px solid var(--c-border);box-shadow:none;}
  .btn.go{background:linear-gradient(135deg,#16a34a,#15803d);box-shadow:0 8px 20px rgba(21,128,61,.28);}
  pre.log{display:none;background:#0f172a;color:#cbd5e1;border-radius:12px;padding:12px 14px;font-size:12px;line-height:1.6;max-height:180px;overflow:auto;margin-top:12px;white-space:pre-wrap;}
  .foot{margin-top:18px;text-align:center;font-size:11.5px;color:var(--c-faint);line-height:1.5;}
</style>
</head>
<body>
<div class="card">
  <div class="logo"><img src="assets/img/logo-mark.png" alt="Sari-Link"></div>
  <h1>System <span>Update</span></h1>
  <div class="sub">Ikonekta muna ang PC sa internet bago mag-update.</div>

  <div class="ver"><span>Current version</span><b id="curVer"><?= htmlspecialchars($curVersion) ?></b></div>
  <div class="msg" id="msg"></div>

  <button class="btn" id="btnCheck"><i class="fas fa-magnifying-glass"></i> Check for Updates</button>
  <button class="btn go" id="btnUpdate" style="display:none"><i class="fas fa-cloud-arrow-down"></i> Update Now</button>
  <pre class="log" id="log"></pre>
  <button class="btn ghost" onclick="window.location.href='index.php'"><i class="fas fa-arrow-left"></i> Back to POS</button>

  <div class="foot">May awtomatikong backup ng files at database bago mag-update.<br>Kapag pumalpak, awtomatikong maibabalik ang dating version.</div>
</div>

<script>
const CSRF = <?= json_encode($CSRF) ?>;
const $ = id => document.getElementById(id);
const msg = (t, cls, notes) => {
  const m = $('msg'); m.className = 'msg ' + cls; m.textContent = t;
  if (notes) { const n = document.createElement('div'); n.className = 'notes'; n.textContent = notes; m.appendChild(n); }
};
async function post(action) {
  const fd = new FormData(); fd.append('action', action); fd.append('csrf', CSRF);
  const r = await fetch('update.php', { method: 'POST', body: fd });
  return r.json();
}

$('btnCheck').onclick = async () => {
  $('btnCheck').disabled = true; $('btnUpdate').style.display = 'none';
  msg('Chine-check ang update...', 'info');
  try {
    const d = await post('check');
    if (!d.ok) msg(d.message, 'err');
    else if (d.available) { msg('May bagong version: ' + d.latest, 'ok', d.notes); $('btnUpdate').style.display = 'flex'; }
    else msg('Updated na. Ito na ang pinakabagong version.', 'ok');
  } catch (e) { msg('May error: ' + e, 'err'); }
  $('btnCheck').disabled = false;
};

$('btnUpdate').onclick = async () => {
  if (!confirm('Siguraduhing may internet at WALANG nagbebenta ngayon. Ituloy ang update?')) return;
  $('btnUpdate').disabled = true; $('btnCheck').disabled = true;
  msg('Nag-a-update... Huwag isara o i-off ang PC. Maaaring abutin ng ilang minuto.', 'warn');
  window.onbeforeunload = () => 'Nag-a-update pa!';
  try {
    const d = await post('run');
    msg(d.message, d.ok ? 'ok' : 'err');
    if (d.log && d.log.length) { const l = $('log'); l.style.display = 'block'; l.textContent = d.log.join('\n'); }
    if (d.ok) { $('btnUpdate').style.display = 'none'; setTimeout(() => location.reload(), 2500); }
  } catch (e) { msg('Naputol ang koneksyon: ' + e + ' — I-refresh at i-check ang version.', 'err'); }
  window.onbeforeunload = null;
  $('btnUpdate').disabled = false; $('btnCheck').disabled = false;
};
</script>
</body>
</html>
