<?php
/* ============================================================================
   Sari-Link — System Update
   ----------------------------------------------------------------------------
   Flow:  check internet/version -> BACKUP (files + database) -> download +
          verify -> extract -> replace files -> run SQL -> new version.
   If anything fails after file replacement begins: AUTOMATIC ROLLBACK
   from the backup.
   ============================================================================ */
session_start();
require_once __DIR__ . '/auth.php';
require_login();

$CFG  = require __DIR__ . '/config.php';
$ROOT = str_replace('\\', '/', __DIR__);

if (!in_array(current_user_username(), $CFG['update_users'], true)) {
    http_response_code(403);
    exit('You are not authorized to update the system.');
}
if (empty($_SESSION['upd_csrf'])) $_SESSION['upd_csrf'] = bin2hex(random_bytes(16));
$CSRF = $_SESSION['upd_csrf'];

// Never overwritten by an update (client's local data/settings)
const NEVER_OVERWRITE = ['config.php', 'auth.php', 'backup', 'uploads', 'version.txt'];
// Also never copied from the update package
const SKIP_FROM_PACKAGE = ['config.php', 'auth.php', 'backup', 'uploads', 'version.txt',
                           'update.php', 'deleted.txt', 'tools', '.git'];

/* ───────────────────────── helpers ───────────────────────── */

function json_out($arr) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($arr);
    exit;
}

function current_version($root) {
    $v = trim((string)@file_get_contents("$root/version.txt"));
    return $v !== '' ? $v : '0.0.0';
}

function http_get($url, $saveTo = null, $timeout = 30) {
    if (stripos($url, 'https://') !== 0) throw new Exception('The update link must use https://.');

    if (function_exists('curl_init')) {
        $ch   = curl_init($url);
        $fh   = $saveTo ? fopen($saveTo, 'wb') : null;
        $opts = [
            CURLOPT_FOLLOWLOCATION => true, CURLOPT_MAXREDIRS => 5,
            CURLOPT_CONNECTTIMEOUT => 8,    CURLOPT_TIMEOUT => $timeout,
            CURLOPT_USERAGENT      => 'SariLink-Updater',
            CURLOPT_SSL_VERIFYPEER => true,
        ];
        if ($fh) $opts[CURLOPT_FILE] = $fh; else $opts[CURLOPT_RETURNTRANSFER] = true;

        // Some XAMPP installs have no CA bundle configured
        if (!ini_get('curl.cainfo')) {
            $dr = !empty($_SERVER['DOCUMENT_ROOT']) ? dirname(str_replace('\\', '/', $_SERVER['DOCUMENT_ROOT'])) : '';
            foreach ([$dr . '/apache/bin/curl-ca-bundle.crt', $dr . '/php/extras/ssl/cacert.pem',
                      'C:/xampp/apache/bin/curl-ca-bundle.crt'] as $ca) {
                if ($ca && file_exists($ca)) { $opts[CURLOPT_CAINFO] = $ca; break; }
            }
        }
        curl_setopt_array($ch, $opts);
        $body = curl_exec($ch);
        $err  = curl_error($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($fh) fclose($fh);
        if ($body === false || $code !== 200) {
            if ($saveTo) @unlink($saveTo);
            throw new Exception($err ? "No internet connection or the update server is unreachable ($err)"
                                     : "The update server is unreachable (HTTP $code)");
        }
        return $saveTo ? true : $body;
    }

    $ctx  = stream_context_create(['http' => ['timeout' => $timeout, 'user_agent' => 'SariLink-Updater']]);
    $body = @file_get_contents($url, false, $ctx);
    if ($body === false) throw new Exception('No internet connection or the update server is unreachable.');
    if ($saveTo) { file_put_contents($saveTo, $body); return true; }
    return $body;
}

function fetch_manifest($cfg) {
    $raw = http_get($cfg['update_manifest_url'], null, 15);
    $m   = json_decode($raw, true);
    if (!is_array($m) || empty($m['version']) || empty($m['url']) || empty($m['sha256'])) {
        throw new Exception('The version.json file on the server is invalid.');
    }
    if (stripos($m['url'], 'https://') !== 0) throw new Exception('The update package link must use https://.');
    return $m;
}

/* Client targeting: if the manifest has a "clients" list, only those client IDs may update.
   No "clients" list = update is for everyone. */
function client_allowed($m, $cfg) {
    if (empty($m['clients']) || !is_array($m['clients'])) return true;
    $id = strtolower(trim((string)($cfg['client_id'] ?? '')));
    if ($id === '') return false;
    foreach ($m['clients'] as $c) {
        if (strtolower(trim((string)$c)) === $id) return true;
    }
    return false;
}

function can_exec() {
    if (!function_exists('exec')) return false;
    $dis = array_map('trim', explode(',', (string)ini_get('disable_functions')));
    return !in_array('exec', $dis, true);
}

function find_bin($name, $configured) {
    if ($configured && file_exists($configured)) return $configured;
    $c  = [];
    $dr = !empty($_SERVER['DOCUMENT_ROOT']) ? str_replace('\\', '/', $_SERVER['DOCUMENT_ROOT']) : '';
    if ($dr) $c[] = dirname($dr) . "/mysql/bin/$name.exe";
    $c[] = "C:/xampp/mysql/bin/$name.exe";
    foreach ($c as $p) if (file_exists($p)) return $p;
    return null;
}

function q($s) { return '"' . str_replace('"', '', $s) . '"'; }

function rrmdir($dir) {
    if (!is_dir($dir)) return;
    $it = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::CHILD_FIRST
    );
    foreach ($it as $f) { $f->isDir() ? @rmdir($f->getPathname()) : @unlink($f->getPathname()); }
    @rmdir($dir);
}

function zip_folder($src, $zipPath, $skipTop) {
    $zip = new ZipArchive;
    if ($zip->open($zipPath, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) return false;
    $src = rtrim(str_replace('\\', '/', $src), '/');
    $it  = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($src, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::LEAVES_ONLY
    );
    foreach ($it as $f) {
        if (!$f->isFile()) continue;
        $path = str_replace('\\', '/', $f->getPathname());
        $rel  = ltrim(substr($path, strlen($src)), '/');
        if (in_array(explode('/', $rel)[0], $skipTop, true)) continue;
        $zip->addFile($path, $rel);
    }
    return $zip->close();
}

function zip_is_safe(ZipArchive $zip) {
    for ($i = 0; $i < $zip->numFiles; $i++) {
        $n = str_replace('\\', '/', $zip->getNameIndex($i));
        if ($n === '' || $n[0] === '/' || strpos($n, ':') !== false) return false;
        foreach (explode('/', $n) as $seg) if ($seg === '..') return false;
    }
    return true;
}

/* ── Database ── */

function db_connect($cfg) {
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    $db = new mysqli($cfg['db_host'], $cfg['db_user'], $cfg['db_pass'], $cfg['db_name']);
    $db->set_charset('utf8mb4');
    return $db;
}

function run_sql_file(mysqli $db, $sql) {
    $db->multi_query($sql);
    do { if ($r = $db->store_result()) $r->free(); } while ($db->more_results() && $db->next_result());
}

function php_dump(mysqli $db, $file) {
    $fh = fopen($file, 'wb');
    fwrite($fh, "SET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS=0;\n\n");
    $tables = [];
    $res = $db->query("SHOW FULL TABLES WHERE Table_type = 'BASE TABLE'");
    while ($row = $res->fetch_row()) $tables[] = $row[0];
    $res->free();

    foreach ($tables as $t) {
        fwrite($fh, "DROP TABLE IF EXISTS `$t`;\n");
        $create = $db->query("SHOW CREATE TABLE `$t`")->fetch_row()[1];
        fwrite($fh, $create . ";\n\n");

        $rs = $db->query("SELECT * FROM `$t`", MYSQLI_USE_RESULT);
        $buf = [];
        while ($row = $rs->fetch_row()) {
            $vals = [];
            foreach ($row as $v) $vals[] = $v === null ? 'NULL' : "'" . $db->real_escape_string($v) . "'";
            $buf[] = '(' . implode(',', $vals) . ')';
            if (count($buf) >= 200) { fwrite($fh, "INSERT INTO `$t` VALUES " . implode(",\n", $buf) . ";\n"); $buf = []; }
        }
        $rs->free();
        if ($buf) fwrite($fh, "INSERT INTO `$t` VALUES " . implode(",\n", $buf) . ";\n");
        fwrite($fh, "\n");
    }
    fwrite($fh, "SET FOREIGN_KEY_CHECKS=1;\n");
    fclose($fh);
}

function backup_database($cfg, $file, &$log) {
    $bin = can_exec() ? find_bin('mysqldump', $cfg['mysqldump_path']) : null;
    if ($bin) {
        $cmd = q($bin) . ' --host=' . q($cfg['db_host']) . ' --user=' . q($cfg['db_user'])
             . ($cfg['db_pass'] !== '' ? ' --password=' . q($cfg['db_pass']) : '')
             . ' --default-character-set=utf8mb4 --single-transaction --routines --triggers --add-drop-table'
             . ' --result-file=' . q($file) . ' ' . q($cfg['db_name']) . ' 2>&1';
        exec($cmd, $out, $code);
        if ($code === 0 && file_exists($file) && filesize($file) > 200) { $log[] = 'Database backup OK (mysqldump).'; return; }
        @unlink($file);
        $log[] = 'mysqldump failed; falling back to the built-in backup...';
    }
    php_dump(db_connect($cfg), $file);
    if (!file_exists($file) || filesize($file) < 100) throw new Exception('The database backup failed.');
    $log[] = 'Database backup OK (built-in).';
}

function restore_database($cfg, $file) {
    $bin = can_exec() ? find_bin('mysql', $cfg['mysql_path']) : null;
    if ($bin) {
        $cmd = q($bin) . ' --host=' . q($cfg['db_host']) . ' --user=' . q($cfg['db_user'])
             . ($cfg['db_pass'] !== '' ? ' --password=' . q($cfg['db_pass']) : '')
             . ' --default-character-set=utf8mb4 ' . q($cfg['db_name'])
             . ' --execute=' . q('source ' . str_replace('\\', '/', $file)) . ' 2>&1';
        exec($cmd, $out, $code);
        if ($code === 0) return;
    }
    run_sql_file(db_connect($cfg), file_get_contents($file));
}

/* ── Files ── */

function apply_files($src, $dst, &$added, $top = true) {
    foreach (scandir($src) as $f) {
        if ($f === '.' || $f === '..') continue;
        if ($top && in_array($f, SKIP_FROM_PACKAGE, true)) continue;
        $s = "$src/$f"; $d = "$dst/$f";
        if (is_dir($s)) {
            if (!is_dir($d)) { mkdir($d, 0777, true); $added[] = $d; }
            apply_files($s, $d, $added, false);
        } else {
            if (!file_exists($d)) $added[] = $d;
            if (!@copy($s, $d)) throw new Exception('Unable to copy file: ' . $f);
        }
    }
}

function apply_deletions($tmpRoot, $root, &$log) {
    $list = "$tmpRoot/deleted.txt";
    if (!file_exists($list)) return;
    foreach (file($list, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $rel) {
        $rel = trim(str_replace('\\', '/', $rel), " \t/");
        if ($rel === '' || strpos($rel, '..') !== false || strpos($rel, ':') !== false) continue;
        if (in_array(explode('/', $rel)[0], NEVER_OVERWRITE, true)) continue;
        if (is_file("$root/$rel") && @unlink("$root/$rel")) $log[] = "Removed obsolete file: $rel";
    }
}

function rollback($root, $bdir, $cfg, $dbTouched, $added, &$log) {
    $zip = new ZipArchive;
    if ($zip->open("$bdir/files.zip") === true) { $zip->extractTo($root); $zip->close(); $log[] = 'Files restored.'; }
    foreach (array_reverse($added) as $p) {
        if (is_file($p)) @unlink($p); elseif (is_dir($p)) @rmdir($p);
    }
    if ($dbTouched) { restore_database($cfg, "$bdir/database.sql"); $log[] = 'Database restored.'; }
}

/* ───────────────────────── actions ───────────────────────── */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($CSRF, (string)($_POST['csrf'] ?? ''))) json_out(['ok' => false, 'message' => 'Invalid request. Please refresh the page.']);
    $action = $_POST['action'] ?? '';

    // ── CHECK ──
    if ($action === 'check') {
        session_write_close();
        try {
            $m   = fetch_manifest($CFG);
            $cur = current_version($ROOT);
            json_out(['ok' => true, 'current' => $cur, 'latest' => $m['version'],
                      'available' => client_allowed($m, $CFG) && version_compare($m['version'], $cur, '>'),
                      'notes' => (string)($m['notes'] ?? '')]);
        } catch (Throwable $e) {
            json_out(['ok' => false, 'message' => $e->getMessage()]);
        }
    }

    // ── RUN ──
    if ($action === 'run') {
        session_write_close();            // don't block other POS tabs
        set_time_limit(0);
        ignore_user_abort(true);          // keep updating even if the browser is closed
        ini_set('memory_limit', '512M');

        $log = []; $added = []; $dbTouched = false; $applying = false;
        $bdir = null; $tmp = null; $lock = "$ROOT/backup/.lock"; $haveLock = false;

        try {
            // 1. Internet + version
            $m   = fetch_manifest($CFG);
            $cur = current_version($ROOT);
            if (!client_allowed($m, $CFG) || !version_compare($m['version'], $cur, '>')) json_out(['ok' => true, 'message' => "You're up to date. You are running version $cur.", 'log' => []]);
            $log[] = "Internet connection OK. $cur -> {$m['version']}";

            // Backup folder + protection
            if (!is_dir("$ROOT/backup")) mkdir("$ROOT/backup", 0777, true);
            @file_put_contents("$ROOT/backup/.htaccess", "Require all denied\n");
            @file_put_contents("$ROOT/backup/index.html", '');
            if (file_exists($lock) && time() - filemtime($lock) < 1800) throw new Exception('Another update is already in progress. Please wait.');
            file_put_contents($lock, date('c'));
            $haveLock = true;

            $stamp = date('Ymd_His');
            $bdir  = "$ROOT/backup/$stamp";
            mkdir($bdir, 0777, true);

            // 2. BACKUP first: files + database
            if (!zip_folder($ROOT, "$bdir/files.zip", ['backup'])) throw new Exception('The files backup failed.');
            $log[] = 'Files backup OK.';
            backup_database($CFG, "$bdir/database.sql", $log);

            // 3. Download + verify
            http_get($m['url'], "$bdir/update.zip", 300);
            if (!hash_equals(strtolower($m['sha256']), hash_file('sha256', "$bdir/update.zip"))) {
                throw new Exception('The download is corrupted (hash mismatch).');
            }
            $log[] = 'Download complete and verified.';

            // 4. Extract to temp
            $zip = new ZipArchive;
            if ($zip->open("$bdir/update.zip") !== true) throw new Exception('Unable to open the update package.');
            if (!zip_is_safe($zip)) { $zip->close(); throw new Exception('Unsafe update package (insecure file path).'); }
            $tmp = "$bdir/tmp";
            $zip->extractTo($tmp);
            $zip->close();

            $src = $tmp;
            $ent = array_values(array_diff(scandir($tmp), ['.', '..']));
            if (count($ent) === 1 && is_dir("$tmp/{$ent[0]}")) $src = "$tmp/{$ent[0]}";
            if (!file_exists("$src/index.php")) throw new Exception('The update package contents are invalid.');
            $log[] = 'Package extracted. (No changes have been made to the system yet.)';

            // 5. Replace files  (from here on, a failure triggers rollback)
            $applying = true;
            apply_files($src, $ROOT, $added);
            apply_deletions($src, $ROOT, $log);
            if (file_exists("$src/update.php")) copy("$src/update.php", "$ROOT/update.php");   // last: the updater itself
            $log[] = 'Files updated.';

            // 6. Database: idempotent structure script + migrations
            $dbTouched = true;
            $db = db_connect($CFG);
            if (file_exists("$ROOT/posmachin_structure_safe_update.sql")) {
                run_sql_file($db, file_get_contents("$ROOT/posmachin_structure_safe_update.sql"));
                $log[] = 'Database structure updated.';
            }
            if (is_dir("$ROOT/migrations")) {
                $db->query("CREATE TABLE IF NOT EXISTS schema_migrations (name VARCHAR(255) PRIMARY KEY, ran_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
                $files = glob("$ROOT/migrations/*.sql"); sort($files);
                foreach ($files as $f) {
                    $n = $db->real_escape_string(basename($f));
                    if ($db->query("SELECT 1 FROM schema_migrations WHERE name='$n'")->num_rows) continue;
                    run_sql_file($db, file_get_contents($f));
                    $db->query("INSERT INTO schema_migrations (name) VALUES ('$n')");
                    $log[] = 'Migration: ' . basename($f);
                }
            }
            $db->close();

            // 7. New version
            file_put_contents("$ROOT/version.txt", $m['version']);
            $log[] = "Now running version {$m['version']}.";

            // Cleanup: temp + old backups
            rrmdir($tmp); @unlink("$bdir/update.zip");
            $keep = max(1, (int)$CFG['keep_backups']);
            $dirs = array_filter(glob("$ROOT/backup/*", GLOB_ONLYDIR), function ($d) { return preg_match('/^\d{8}_\d{6}$/', basename($d)); });
            sort($dirs);
            while (count($dirs) > $keep) rrmdir(array_shift($dirs));

            file_put_contents("$bdir/update.log", implode("\n", $log));
            @unlink($lock);
            json_out(['ok' => true, 'message' => "Success! The system has been updated to version {$m['version']}.", 'log' => $log]);

        } catch (Throwable $e) {
            $log[] = 'ERROR: ' . $e->getMessage();
            $msg = $e->getMessage() . ' — No changes were made to the system.';
            if ($applying && $bdir) {
                try {
                    rollback($ROOT, $bdir, $CFG, $dbTouched, $added, $log);
                    $msg = $e->getMessage() . ' — The system was restored to the previous version.';
                } catch (Throwable $e2) {
                    $log[] = 'ROLLBACK ERROR: ' . $e2->getMessage();
                    $msg = 'The update AND the rollback failed. Please contact the developer. Your backup is in backup/' . basename($bdir) . '.';
                }
            }
            if ($bdir && is_dir($bdir)) @file_put_contents("$bdir/update.log", implode("\n", $log));
            if ($tmp) rrmdir($tmp);
            if ($haveLock) @unlink($lock);
            json_out(['ok' => false, 'message' => $msg, 'log' => $log]);
        }
    }
    json_out(['ok' => false, 'message' => 'Unknown action.']);
}

$curVersion = current_version($ROOT);
$clientId   = trim((string)($CFG['client_id'] ?? ''));
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>System Update — Sari-Link POS</title>
<link href="assets/css/fonts.css" rel="stylesheet">
<link href="assets/css/fontawesome.min.css" rel="stylesheet">
<link rel="shortcut icon" href="Sari-Link.ico" type="image/x-icon">
<style>
  :root{--c-bg:#eef2f8;--c-surface:#fff;--c-border:#e2e8f2;--c-primary:#2563eb;--c-primary-hv:#1d4ed8;--c-primary-lt:#dbeafe;
        --c-danger:#dc2626;--c-danger-lt:#fee2e2;--c-ok:#15803d;--c-ok-lt:#dcfce7;--c-warn:#b45309;--c-warn-lt:#fef3c7;
        --c-text:#0f172a;--c-muted:#57647c;--c-faint:#8695ab;--c-soft:#f7f9fc;--font:'DM Sans',sans-serif;--disp:'Playfair Display',serif;}
  *,*::before,*::after{margin:0;padding:0;box-sizing:border-box;}
  body{font-family:var(--font);min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px;color:var(--c-text);
       background:radial-gradient(circle at 15% 12%,rgba(59,130,246,.20),transparent 45%),
                  radial-gradient(circle at 85% 88%,rgba(37,99,235,.16),transparent 50%),
                  linear-gradient(160deg,#0b1526 0%,#132743 55%,#1c3a5e 100%);}
  .card{background:var(--c-surface);border-radius:24px;width:540px;max-width:100%;padding:36px 36px 28px;
        box-shadow:0 24px 60px rgba(8,15,30,.35),0 2px 8px rgba(8,15,30,.12);border:1px solid rgba(255,255,255,.06);}

  /* Header */
  .logo{width:60px;height:60px;border-radius:17px;background:linear-gradient(135deg,#eef4ff,#dbe7fb);padding:9px;margin:0 auto 14px;display:block;
        box-shadow:0 6px 16px rgba(37,99,235,.14);}
  .logo img{width:100%;height:100%;object-fit:contain;}
  h1{font-family:var(--disp);font-size:26px;text-align:center;margin-bottom:6px;}
  h1 span{color:var(--c-primary);}
  .sub{font-size:13.5px;color:var(--c-muted);text-align:center;margin-bottom:24px;line-height:1.5;}

  .client{display:inline-flex;align-items:center;gap:7px;margin:10px auto 0;padding:5px 12px;border-radius:99px;background:var(--c-primary-lt);
          color:var(--c-primary-hv);font-size:12px;font-weight:700;}
  .client-wrap{text-align:center;}

  /* Version panel */
  .versions{display:grid;grid-template-columns:1fr auto 1fr;align-items:center;gap:10px;margin-bottom:16px;}
  .vbox{background:var(--c-soft);border:1px solid var(--c-border);border-radius:14px;padding:13px 16px;min-width:0;}
  .vbox small{display:block;font-size:11px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:var(--c-faint);margin-bottom:3px;}
  .vbox b{font-size:19px;font-weight:700;display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
  .vbox.new{background:var(--c-ok-lt);border-color:#bbf7d0;}
  .vbox.new b{color:var(--c-ok);}
  .varrow{color:var(--c-faint);font-size:14px;}
  .versions.single{grid-template-columns:1fr;}
  .versions.single .varrow,.versions.single .vbox.new{display:none;}

  /* Status message */
  .msg{display:none;border-radius:12px;padding:13px 15px;font-size:13.5px;font-weight:600;margin-bottom:14px;line-height:1.5;
       gap:11px;align-items:flex-start;}
  .msg.show{display:flex;}
  .msg i{margin-top:2px;font-size:15px;flex-shrink:0;}
  .msg .txt{flex:1;min-width:0;}
  .msg.info{background:var(--c-primary-lt);color:var(--c-primary-hv);}
  .msg.ok{background:var(--c-ok-lt);color:var(--c-ok);}
  .msg.err{background:var(--c-danger-lt);color:var(--c-danger);}
  .msg.warn{background:var(--c-warn-lt);color:var(--c-warn);}
  .notes{white-space:pre-wrap;font-weight:500;margin-top:8px;font-size:12.5px;line-height:1.6;color:var(--c-text);
         background:rgba(255,255,255,.65);border-radius:8px;padding:9px 11px;}
  .notes b{display:block;font-size:11px;letter-spacing:.06em;text-transform:uppercase;color:var(--c-muted);margin-bottom:3px;}

  /* Progress bar (indeterminate) */
  .progress{display:none;height:6px;border-radius:99px;background:var(--c-primary-lt);overflow:hidden;margin-bottom:14px;}
  .progress.show{display:block;}
  .progress::after{content:'';display:block;height:100%;width:38%;border-radius:99px;
        background:linear-gradient(90deg,var(--c-primary),#60a5fa);animation:slide 1.2s ease-in-out infinite;}
  @keyframes slide{0%{margin-left:-40%}100%{margin-left:102%}}

  /* Buttons */
  .btn{width:100%;padding:14px;border:none;border-radius:12px;font-family:inherit;font-weight:700;font-size:14.5px;cursor:pointer;
       color:#fff;background:linear-gradient(135deg,var(--c-primary),var(--c-primary-hv));display:flex;align-items:center;justify-content:center;gap:9px;
       box-shadow:0 8px 20px rgba(37,99,235,.28);margin-top:10px;transition:transform .12s,box-shadow .12s,opacity .12s;}
  .btn:hover:not(:disabled){transform:translateY(-1px);box-shadow:0 10px 24px rgba(37,99,235,.34);}
  .btn:active:not(:disabled){transform:translateY(0);}
  .btn:disabled{opacity:.55;cursor:not-allowed;}
  .btn.ghost{background:#fff;color:var(--c-muted);border:1.5px solid var(--c-border);box-shadow:none;}
  .btn.ghost:hover:not(:disabled){background:var(--c-soft);color:var(--c-text);box-shadow:none;}
  .btn.go{background:linear-gradient(135deg,#16a34a,#15803d);box-shadow:0 8px 20px rgba(21,128,61,.28);}
  .btn.go:hover:not(:disabled){box-shadow:0 10px 24px rgba(21,128,61,.34);}

  /* Activity log */
  .logwrap{display:none;margin-top:14px;}
  .logwrap.show{display:block;}
  .logwrap h4{font-size:11px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:var(--c-faint);margin-bottom:6px;}
  pre.log{background:#0f172a;color:#cbd5e1;border-radius:12px;padding:12px 14px;font-family:Consolas,'Courier New',monospace;font-size:12px;line-height:1.7;
          max-height:190px;overflow:auto;white-space:pre-wrap;}

  /* Footer info */
  .safe{margin-top:20px;padding-top:16px;border-top:1px solid var(--c-border);display:grid;gap:8px;}
  .safe div{display:flex;gap:10px;align-items:flex-start;font-size:12px;color:var(--c-muted);line-height:1.5;}
  .safe i{color:var(--c-primary);margin-top:2px;width:14px;text-align:center;flex-shrink:0;}

  @media (max-width:520px){
    .card{padding:28px 20px 22px;border-radius:20px;}
    .versions{grid-template-columns:1fr;}
    .varrow{display:none;}
  }
</style>
</head>
<body>
<div class="card">
  <div class="logo"><img src="assets/img/logo-mark.png" alt="Sari-Link"></div>
  <h1>System <span>Update</span></h1>
  <div class="sub">Keep your POS up to date with the latest features and fixes.<br>Please make sure this PC is connected to the internet.
    <?php if ($clientId !== ''): ?><div class="client-wrap"><span class="client"><i class="fas fa-store"></i> Client: <?= htmlspecialchars($clientId) ?></span></div><?php endif; ?>
  </div>

  <div class="versions single" id="versions">
    <div class="vbox"><small>Current Version</small><b id="curVer"><?= htmlspecialchars($curVersion) ?></b></div>
    <i class="fas fa-arrow-right varrow"></i>
    <div class="vbox new"><small>Latest Version</small><b id="newVer">—</b></div>
  </div>

  <div class="msg" id="msg"><i class="fas fa-circle-info" id="msgIcon"></i><div class="txt" id="msgTxt"></div></div>
  <div class="progress" id="progress"></div>

  <button class="btn" id="btnCheck"><i class="fas fa-magnifying-glass"></i> Check for Updates</button>
  <button class="btn go" id="btnUpdate" style="display:none"><i class="fas fa-cloud-arrow-down"></i> Update Now</button>
<button class="btn" id="btnBack" onclick="window.location.href='index.php';" >Back</button>


  <div class="logwrap" id="logwrap"><h4>Update Activity Log</h4><pre class="log" id="log"></pre></div>

  <div class="safe">
    <div><i class="fas fa-shield-halved"></i><span>Your files and database are backed up automatically before every update.</span></div>
    <div><i class="fas fa-rotate-left"></i><span>If anything goes wrong, the system is automatically restored to the previous version.</span></div>
  </div>
</div>

<script>
const CSRF = <?= json_encode($CSRF) ?>;
const $ = id => document.getElementById(id);
const ICONS = { info:'fa-circle-info', ok:'fa-circle-check', err:'fa-circle-exclamation', warn:'fa-triangle-exclamation' };

const msg = (text, cls, notes) => {
  const m = $('msg'), t = $('msgTxt');
  m.className = 'msg show ' + cls;
  $('msgIcon').className = 'fas ' + (ICONS[cls] || ICONS.info);
  t.textContent = text;
  if (notes) {
    const n = document.createElement('div'); n.className = 'notes';
    const h = document.createElement('b'); h.textContent = 'Release Notes';
    n.appendChild(h); n.appendChild(document.createTextNode(notes));
    t.appendChild(n);
  }
};
const busy = on => $('progress').classList.toggle('show', on);

async function post(action) {
  const fd = new FormData(); fd.append('action', action); fd.append('csrf', CSRF);
  const r = await fetch('update.php', { method: 'POST', body: fd });
  return r.json();
}

$('btnCheck').onclick = async () => {
  $('btnCheck').disabled = true; $('btnUpdate').style.display = 'none';
  $('versions').classList.add('single');
  msg('Checking for updates…', 'info'); busy(true);
  try {
    const d = await post('check');
    if (!d.ok) msg(d.message, 'err');
    else if (d.available) {
      $('newVer').textContent = d.latest;
      $('versions').classList.remove('single');
      msg('A new version is available: ' + d.latest, 'ok', d.notes);
      $('btnUpdate').style.display = 'flex';
    } else msg("You're up to date. This is the latest version.", 'ok');
  } catch (e) { msg('Something went wrong: ' + e, 'err'); }
  busy(false);
  $('btnCheck').disabled = false;
};

$('btnUpdate').onclick = async () => {
  if (!confirm('Please make sure you have an internet connection and that NO sales are being processed right now.\n\nDo you want to continue with the update?')) return;
  $('btnUpdate').disabled = true; $('btnCheck').disabled = true; $('btnBack').disabled = true;
  msg('Updating… Do not close this page or turn off the PC. This may take a few minutes.', 'warn'); busy(true);
  window.onbeforeunload = () => 'An update is still in progress!';
  try {
    const d = await post('run');
    msg(d.message, d.ok ? 'ok' : 'err');
    if (d.log && d.log.length) { $('logwrap').classList.add('show'); $('log').textContent = d.log.join('\n'); }
    if (d.ok) { $('btnUpdate').style.display = 'none'; setTimeout(() => location.reload(), 2500); }
  } catch (e) { msg('Connection lost: ' + e + ' — Please refresh the page and check the current version.', 'err'); }
  busy(false);
  window.onbeforeunload = null;
  $('btnUpdate').disabled = false; $('btnCheck').disabled = false; $('btnBack').disabled = false;
};
</script>
</body>
</html>