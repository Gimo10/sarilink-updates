<?php
include 'db.php';

// Sanitize search term
$searchTerm = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';

if (empty($searchTerm)) {
    echo '<div class="empty-state"><i class="fas fa-search"></i><h3>Search for a Product</h3><p>Enter a product name above to see its sales performance.</p></div>';
    exit;
}

// Date filter handling from GET parameters
$filter = isset($_GET['filter']) ? $_GET['filter'] : 'all';
$startDate = isset($_GET['start_date']) ? $_GET['start_date'] : '';
$endDate = isset($_GET['end_date']) ? $_GET['end_date'] : '';

$dateFilter = '';
switch ($filter) {
    case 'today':
        $dateFilter = "AND DATE(s.sale_date) = CURDATE()";
        break;
    case 'week':
        $dateFilter = "AND s.sale_date >= DATE_SUB(NOW(), INTERVAL 1 WEEK)";
        break;
    case 'month':
        $dateFilter = "AND s.sale_date >= DATE_SUB(NOW(), INTERVAL 1 MONTH)";
        break;
    case 'year':
        $dateFilter = "AND s.sale_date >= DATE_SUB(NOW(), INTERVAL 1 YEAR)";
        break;
    case 'custom':
        if (!empty($startDate) && !empty($endDate)) {
            $dateFilter = "AND DATE(s.sale_date) BETWEEN '$startDate' AND '$endDate'";
        }
        break;
}

// Fetch product sales data
$query = "
    SELECT 
        COALESCE(s.product_name, p.name) AS product_name,
        SUM(s.quantity) AS total_quantity,
        COUNT(*) AS transaction_count,
        SUM(s.total_price) AS total_revenue
    FROM sales s
    LEFT JOIN products p ON s.product_id = p.id
    WHERE (s.product_name LIKE '%$searchTerm%' OR p.name LIKE '%$searchTerm%')
    " . $dateFilter . "
    GROUP BY COALESCE(s.product_name, p.name)
    HAVING product_name IS NOT NULL
    ORDER BY total_revenue DESC
";

$result = $conn->query($query);

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $productName = htmlspecialchars($row['product_name']);
        $totalQuantity = number_format($row['total_quantity']);
        $transactionCount = number_format($row['transaction_count']);
        $totalRevenue = number_format($row['total_revenue'], 2);

        echo <<<HTML
        <div class="report-card">
            <h3>{$productName}</h3>
            <div class="report-stats">
                <div class="report-stat-item">
                    <div class="stat-icon total-sales-icon"><i class="fas fa-peso-sign"></i></div>
                    <div class="stat-info">
                        <div class="stat-value">₱{$totalRevenue}</div>
                        <div class="stat-label">Total Revenue</div>
                    </div>
                </div>
                <div class="report-stat-item">
                    <div class="stat-icon total-transactions-icon"><i class="fas fa-box"></i></div>
                    <div class="stat-info">
                        <div class="stat-value">{$totalQuantity}</div>
                        <div class="stat-label">Units Sold</div>
                    </div>
                </div>
                <div class="report-stat-item">
                    <div class="stat-icon avg-transaction-icon"><i class="fas fa-receipt"></i></div>
                    <div class="stat-info">
                        <div class="stat-value">{$transactionCount}</div>
                        <div class="stat-label">Transactions</div>
                    </div>
                </div>
            </div>
        </div>
HTML;
    }
} else {
    echo '<div class="empty-state"><i class="fas fa-box-open"></i><h3>No Results Found</h3><p>We couldn\'t find any sales data for a product matching "' . htmlspecialchars($searchTerm) . '".</p></div>';
}

$conn->close();
?>