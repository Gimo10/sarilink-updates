<?php
include 'db.php';

// Check if form was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate month input
    if (empty($_POST['month'])) {
        // Redirect with error if no month selected
        header('Location: dashboard.php?delete_error=1&message=' . urlencode('No month selected'));
        exit;
    }
    
    // Parse the year-month value (format: YYYY-MM)
    $yearMonth = explode('-', $_POST['month']);
    
    if (count($yearMonth) !== 2 || !is_numeric($yearMonth[0]) || !is_numeric($yearMonth[1])) {
        header('Location: dashboard.php?delete_error=1&message=' . urlencode('Invalid month format'));
        exit;
    }
    
    $year = (int)$yearMonth[0];
    $month = (int)$yearMonth[1];
    
    // Get month name for display in success message
    $monthName = date('F Y', mktime(0, 0, 0, $month, 1, $year));
    
    // Count records to be deleted
    $countQuery = $conn->query("
        SELECT COUNT(*) as count 
        FROM sales 
        WHERE YEAR(sale_date) = $year AND MONTH(sale_date) = $month
    ");
    
    if (!$countQuery) {
        header('Location: dashboard.php?delete_error=1&message=' . urlencode('Database error: ' . $conn->error));
        exit;
    }
    
    $countResult = $countQuery->fetch_assoc();
    $recordCount = $countResult['count'];
    
    if ($recordCount == 0) {
        header('Location: dashboard.php?delete_error=1&message=' . urlencode('No records found for the selected month'));
        exit;
    }
    
    // Execute deletion
    $deleteQuery = $conn->query("
        DELETE FROM sales 
        WHERE YEAR(sale_date) = $year AND MONTH(sale_date) = $month
    ");
    
    if ($deleteQuery) {
        // Success - redirect with success message
        header('Location: dashboard.php?delete_success=1&count=' . $recordCount . '&month=' . urlencode($monthName));
        exit;
    } else {
        // Error - redirect with error message
        header('Location: dashboard.php?delete_error=1&message=' . urlencode('Error deleting records: ' . $conn->error));
        exit;
    }
} else {
    // If accessed directly without POST, redirect to dashboard
    header('Location: dashboard.php');
    exit;
}
?>