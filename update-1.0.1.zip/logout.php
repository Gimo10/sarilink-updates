<?php
session_start();
unset($_SESSION['dashboard_verified']);
session_destroy();
header('Location: login.php');
exit;
